import type { SubscriptionPlan, ScanCheckCategory, UserPlanFeatures } from "@/types";

// ---------------------------------------------------------------------------
// Plan Definitions
// ---------------------------------------------------------------------------

export interface PricingPlan {
  /** Internal identifier. */
  id: SubscriptionPlan;
  /** Display name shown to users. */
  name: string;
  /** Short tagline / description. */
  description: string;
  /** Price in cents (to avoid floating-point issues). */
  priceCents: number;
  /** Human-readable price label, e.g. "$2". */
  priceLabel: string;
  /** Billing interval. */
  interval: "day" | "month" | "year";
  /** Whether this is the recommended plan. */
  featured: boolean;
  /** Feature set for this plan. */
  features: UserPlanFeatures;
  /** Marketing bullet points (displayed on pricing page). */
  highlights: string[];
  /** Stripe Price ID (populated from env, null for manual). */
  stripePriceId: string | null;
}

// ---------------------------------------------------------------------------
// Plan Configuration
// ---------------------------------------------------------------------------

const DAILY_CATEGORIES: ScanCheckCategory[] = [
  "security",
  "performance",
  "ssl",
];

const MONTHLY_CATEGORIES: ScanCheckCategory[] = [
  "security",
  "performance",
  "seo",
  "ssl",
  "mobile",
  "analytics",
];

const YEARLY_CATEGORIES: ScanCheckCategory[] = [
  "security",
  "performance",
  "seo",
  "accessibility",
  "mobile",
  "content",
  "analytics",
  "ssl",
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "daily",
    name: "Daily",
    description: "Pay-per-scan — ideal for quick spot checks.",
    priceCents: 200,
    priceLabel: "$2",
    interval: "day",
    featured: false,
    features: {
      maxStores: 1,
      maxScansPerDay: 5,
      scanCategories: DAILY_CATEGORIES,
      aiAnalysisEnabled: false,
      notificationsEnabled: true,
      apiAccessEnabled: false,
      customBranding: false,
      teamMembers: 1,
      dataRetentionDays: 7,
      prioritySupport: false,
      webhooksEnabled: false,
      exportEnabled: false,
      historicalComparison: false,
    },
    highlights: [
      "1 store monitored",
      "5 scans per day",
      "Core security & performance checks",
      "Email notifications",
      "7-day data retention",
    ],
    // stripePriceId: server-side only — set via STRIPE_DAILY_PRICE_ID env var
    stripePriceId: null,
  },
  {
    id: "monthly",
    name: "Monthly",
    description: "Full monitoring suite with AI insights.",
    priceCents: 4500,
    priceLabel: "$45",
    interval: "month",
    featured: true,
    features: {
      maxStores: 5,
      maxScansPerDay: 50,
      scanCategories: MONTHLY_CATEGORIES,
      aiAnalysisEnabled: true,
      notificationsEnabled: true,
      apiAccessEnabled: true,
      customBranding: false,
      teamMembers: 3,
      dataRetentionDays: 90,
      prioritySupport: false,
      webhooksEnabled: true,
      exportEnabled: true,
      historicalComparison: true,
    },
    highlights: [
      "Up to 5 stores",
      "50 scans per day",
      "AI-powered analysis",
      "Historical comparison",
      "90-day data retention",
      "API access & webhooks",
      "CSV/PDF export",
      "Up to 3 team members",
    ],
    // stripePriceId: server-side only — set via STRIPE_MONTHLY_PRICE_ID env var
    stripePriceId: null,
  },
  {
    id: "yearly",
    name: "Yearly",
    description: "Enterprise-grade protection with priority support.",
    priceCents: 50_000,
    priceLabel: "$500",
    interval: "year",
    featured: false,
    features: {
      maxStores: 50,
      maxScansPerDay: 500,
      scanCategories: YEARLY_CATEGORIES,
      aiAnalysisEnabled: true,
      notificationsEnabled: true,
      apiAccessEnabled: true,
      customBranding: true,
      teamMembers: 25,
      dataRetentionDays: 365,
      prioritySupport: true,
      webhooksEnabled: true,
      exportEnabled: true,
      historicalComparison: true,
    },
    highlights: [
      "Up to 50 stores",
      "500 scans per day",
      "Everything in Monthly",
      "All 8 scan categories",
      "Custom branding",
      "Priority support",
      "365-day data retention",
      "Up to 25 team members",
      "White-label reports",
    ],
    // stripePriceId: server-side only — set via STRIPE_YEARLY_PRICE_ID env var
    stripePriceId: null,
  },
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Get a plan by its ID. Returns undefined if not found. */
export function getPlanById(planId: SubscriptionPlan): PricingPlan | undefined {
  return PRICING_PLANS.find((p) => p.id === planId);
}

/** Get the featured / recommended plan. */
export function getFeaturedPlan(): PricingPlan {
  return PRICING_PLANS.find((p) => p.featured) ?? PRICING_PLANS[0]!;
}

/** Calculate the effective daily cost for a plan (for comparison). */
export function dailyCost(plan: PricingPlan): number {
  switch (plan.interval) {
    case "day":
      return plan.priceCents / 100;
    case "month":
      return plan.priceCents / 100 / 30;
    case "year":
      return plan.priceCents / 100 / 365;
  }
}

/** Calculate yearly savings compared to daily billing. */
export function yearlySavings(plan: PricingPlan): number {
  if (plan.interval === "day") return 0;
  const dailyPlan = getPlanById("daily");
  if (!dailyPlan) return 0;

  const dailyCostPerYear = (dailyPlan.priceCents / 100) * 365;
  const planCostPerYear =
    plan.interval === "year"
      ? plan.priceCents / 100
      : (plan.priceCents / 100) * 12;

  return Math.max(0, Math.round(dailyCostPerYear - planCostPerYear));
}
