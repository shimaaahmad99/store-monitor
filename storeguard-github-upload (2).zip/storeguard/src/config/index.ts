import type { ScanCheckCategory } from "@/types";

// ---------------------------------------------------------------------------
// App Metadata
// ---------------------------------------------------------------------------

export const APP_NAME = import.meta.env.VITE_APP_NAME ?? "StoreGuard";

export const APP_DESCRIPTION =
  "Automated health monitoring & security scanning for e-commerce stores.";

export const APP_URL = import.meta.env.VITE_APP_URL ?? "https://storeguard.dev";

// ---------------------------------------------------------------------------
// API URLs (derived from env vars, never hardcoded)
// ---------------------------------------------------------------------------

export const API_URL =
  import.meta.env.VITE_API_URL ?? `${APP_URL}/api`;

export const WS_URL =
  import.meta.env.VITE_WS_URL ?? `${APP_URL.replace("https", "wss")}`;

// ---------------------------------------------------------------------------
// Feature Flags
// ---------------------------------------------------------------------------

export const FEATURES = {
  /** Allow users to sign up / authenticate. */
  authEnabled: parseEnvBool("NEXT_PUBLIC_FEATURE_AUTH", true),

  /** Enable the AI-powered analysis module. */
  aiAnalysis: parseEnvBool("NEXT_PUBLIC_FEATURE_AI", true),

  /** Enable real-time scan progress via WebSocket. */
  realtimeScan: parseEnvBool("NEXT_PUBLIC_FEATURE_REALTIME", true),

  /** Show the pricing / subscription page. */
  billingEnabled: parseEnvBool("NEXT_PUBLIC_FEATURE_BILLING", true),

  /** Enable the public API for programmatic access. */
  publicApi: parseEnvBool("NEXT_PUBLIC_FEATURE_PUBLIC_API", false),

  /** Enable team / multi-user store management. */
  teamManagement: parseEnvBool("NEXT_PUBLIC_FEATURE_TEAMS", false),

  /** Enable webhook support for notifications. */
  webhooks: parseEnvBool("NEXT_PUBLIC_FEATURE_WEBHOOKS", false),

  /** Show a "beta" badge on new features. */
  betaBadge: parseEnvBool("NEXT_PUBLIC_FEATURE_BETA_BADGE", true),
} as const;

// ---------------------------------------------------------------------------
// Scan Configuration
// ---------------------------------------------------------------------------

export const SCAN_CONFIG = {
  /** Maximum time in ms to wait for a scan to complete. */
  timeoutMs: parseEnvInt("SCAN_TIMEOUT_MS", 30_000),

  /** Default categories included in a scan. */
  defaultCategories: [
    "security",
    "performance",
    "seo",
    "ssl",
    "mobile",
  ] as ScanCheckCategory[],

  /** All available scan categories. */
  allCategories: [
    "security",
    "performance",
    "seo",
    "accessibility",
    "mobile",
    "content",
    "analytics",
    "ssl",
  ] as ScanCheckCategory[],

  /** Maximum number of stores a free user can add. */
  maxFreeStores: parseEnvInt("MAX_FREE_STORES", 1),

  /** Maximum number of scans per day for a free user. */
  maxFreeScansPerDay: parseEnvInt("MAX_FREE_SCANS_PER_DAY", 3),

  /** Delay between concurrent scan requests (ms) for rate-limiting. */
  scanThrottleMs: parseEnvInt("SCAN_THROTTLE_MS", 2_000),
} as const;

// ---------------------------------------------------------------------------
// Notification Configuration
// ---------------------------------------------------------------------------

export const NOTIFICATION_CONFIG = {
  /** Default notification channels. */
  defaultChannels: ["email", "in_app"] as const,

  /** Types of events that trigger notifications. */
  eventTypes: [
    "scan_completed",
    "critical_issue_found",
    "health_score_dropped",
    "subscription_expiring",
    "weekly_summary",
  ] as const,

  /** How many days before subscription expiry to warn. */
  expiryWarningDays: 7,
} as const;

// ---------------------------------------------------------------------------
// UI Constants
// ---------------------------------------------------------------------------

export const UI = {
  /** Default page size for paginated lists. */
  defaultPageSize: 10,

  /** Maximum page size allowed. */
  maxPageSize: 100,

  /** Debounce delay for search inputs (ms). */
  searchDebounceMs: 300,

  /** Animation duration for page transitions (ms). */
  pageTransitionMs: 200,
} as const;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parseEnvBool(key: string, fallback: boolean): boolean {
  const raw = (import.meta.env as Record<string, string | undefined>)[key];
  if (raw === undefined) return fallback;
  return raw === "true" || raw === "1";
}

function parseEnvInt(key: string, fallback: number): number {
  const raw = (import.meta.env as Record<string, string | undefined>)[key];
  if (raw === undefined) return fallback;
  const parsed = Number.parseInt(raw, 10);
  return Number.isNaN(parsed) ? fallback : parsed;
}
