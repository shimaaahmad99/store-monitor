"use client";

import { Link } from "react-router-dom";
import { ArrowRight, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function HeroSection() {
  const scrollToHow = () => {
    const el = document.querySelector("#how-it-works");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative overflow-hidden pt-24 pb-16 sm:pt-32 sm:pb-24">
      {/* Background glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 -translate-x-1/2 h-[600px] w-[900px] rounded-full bg-[#6366f1]/8 blur-[120px]" />
        <div className="absolute right-0 top-1/4 h-[400px] w-[500px] rounded-full bg-[#06b6d4]/5 blur-[100px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left: Text content */}
          <div className="flex flex-col items-start">
            <h1 className="text-4xl font-bold leading-tight tracking-tight text-[#f0f0f5] sm:text-5xl lg:text-6xl">
              Know what&apos;s wrong with your store before your customers do.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-[#8888a0]">
              StoreGuard automatically monitors your online store and gives you a
              clear daily report of technical, SEO, and product issues.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button size="lg" asChild>
                <Link to="/signup">
                  Start Monitoring
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" onClick={scrollToHow}>
                <Play className="h-4 w-4" />
                See How It Works
              </Button>
            </div>
          </div>

          {/* Right: Dashboard mockup */}
          <div className="flex justify-center lg:justify-end">
            <DashboardMockup />
          </div>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  CSS-Only Dashboard Mockup                                                 */
/* -------------------------------------------------------------------------- */

function DashboardMockup() {
  return (
    <div className="w-full max-w-lg rounded-2xl border border-[#1e1e2e] bg-[#111118] p-4 shadow-2xl shadow-black/40">
      {/* Title bar */}
      <div className="mb-4 flex items-center gap-3">
        <div className="flex gap-1.5">
          <span className="h-3 w-3 rounded-full bg-[#ef4444]/60" />
          <span className="h-3 w-3 rounded-full bg-[#eab308]/60" />
          <span className="h-3 w-3 rounded-full bg-[#22c55e]/60" />
        </div>
        <div className="h-5 flex-1 rounded-md bg-[#1e1e2e]" />
      </div>

      {/* Top row: score ring + issue counts */}
      <div className="flex gap-4">
        {/* Score ring */}
        <div className="flex flex-col items-center gap-1">
          <div className="relative flex h-24 w-24 items-center justify-center">
            <svg className="h-24 w-24 -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="#1e1e2e"
                strokeWidth="8"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="#22c55e"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={264}
                strokeDashoffset={40}
              />
            </svg>
            <span className="absolute text-2xl font-bold text-[#f0f0f5]">92</span>
          </div>
          <span className="text-xs text-[#8888a0]">Health Score</span>
        </div>

        {/* Issue summary cards */}
        <div className="flex flex-1 flex-col gap-2">
          <IssueChip color="bg-[#ef4444]" label="2 Critical" />
          <IssueChip color="bg-[#eab308]" label="5 Warnings" />
          <IssueChip color="bg-[#22c55e]" label="34 Passed" />
        </div>
      </div>

      {/* Mini chart area */}
      <div className="mt-4 rounded-lg border border-[#1e1e2e] bg-[#0a0a0f] p-3">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-xs font-medium text-[#8888a0]">
            Health Trend (7 days)
          </span>
          <span className="text-xs text-[#22c55e]">+3%</span>
        </div>
        {/* Fake bar chart */}
        <div className="flex items-end gap-2 h-16">
          {[78, 82, 80, 85, 88, 90, 92].map((val, i) => (
            <div
              key={i}
              className="flex-1 rounded-t-sm"
              style={{
                height: `${(val / 100) * 100}%`,
                background:
                  i === 6
                    ? "linear-gradient(to top, #22c55e, #22c55e80)"
                    : "#1e1e2e",
              }}
            />
          ))}
        </div>
      </div>

      {/* Top issues list */}
      <div className="mt-3 flex flex-col gap-2">
        <span className="text-xs font-medium text-[#8888a0]">Top Issues</span>
        <MiniIssueRow severity="red" label="Missing meta description" page="/products/shoes" />
        <MiniIssueRow severity="red" label="Broken image link" page="/collections/sale" />
        <MiniIssueRow severity="yellow" label="Slow page load (4.2s)" page="/pages/about" />
      </div>
    </div>
  );
}

function IssueChip({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-[#1e1e2e] bg-[#0a0a0f] px-3 py-1.5">
      <span className={cn("h-2 w-2 rounded-full", color)} />
      <span className="text-xs text-[#8888a0]">{label}</span>
    </div>
  );
}

function MiniIssueRow({
  severity,
  label,
  page,
}: {
  severity: "red" | "yellow";
  label: string;
  page: string;
}) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-[#1e1e2e] bg-[#0a0a0f] px-3 py-2">
      <span
        className={cn(
          "h-2 w-2 shrink-0 rounded-full",
          severity === "red" ? "bg-[#ef4444]" : "bg-[#eab308]"
        )}
      />
      <div className="flex min-w-0 flex-1 flex-col">
        <span className="truncate text-xs text-[#f0f0f5]">{label}</span>
        <span className="truncate text-[10px] text-[#55556a]">{page}</span>
      </div>
    </div>
  );
}
