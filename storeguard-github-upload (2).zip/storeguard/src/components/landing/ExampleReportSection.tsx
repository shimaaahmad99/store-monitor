"use client";

import { Link } from "react-router-dom";
import { ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function ExampleReportSection() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-[#f0f0f5] sm:text-4xl">
            See a Sample Report
          </h2>
          <p className="mt-4 text-base text-[#8888a0]">
            This is what your daily StoreGuard report looks like.
          </p>
        </div>

        <div className="mx-auto mt-12 max-w-2xl">
          {/* Report card */}
          <div className="rounded-2xl border border-[#1e1e2e] bg-[#111118] overflow-hidden">
            {/* Header */}
            <div className="flex flex-col gap-3 border-b border-[#1e1e2e] p-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="text-lg font-semibold text-[#f0f0f5]">
                  Store Health Report
                </h3>
                <p className="mt-0.5 text-sm text-[#8888a0]">
                  mystore.com &middot; August 22, 2026
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <span className="text-3xl font-bold text-[#22c55e]">92</span>
                  <span className="text-sm text-[#55556a]">/100</span>
                </div>
                <Badge variant="success">Good</Badge>
              </div>
            </div>

            <div className="p-6">
              {/* Issue counts */}
              <div className="mb-6 grid grid-cols-3 gap-3">
                <CountCard
                  color="text-[#ef4444]"
                  bgColor="bg-[#ef4444]/10"
                  count="2"
                  label="Critical"
                />
                <CountCard
                  color="text-[#eab308]"
                  bgColor="bg-[#eab308]/10"
                  count="5"
                  label="Warnings"
                />
                <CountCard
                  color="text-[#22c55e]"
                  bgColor="bg-[#22c55e]/10"
                  count="34"
                  label="Passed"
                />
              </div>

              {/* Top Problems */}
              <div className="mb-6">
                <h4 className="mb-3 text-sm font-medium text-[#f0f0f5]">
                  Top Problems
                </h4>
                <div className="flex flex-col gap-2">
                  <ReportIssueRow
                    severity="red"
                    label="Missing meta description on product page"
                    page="/products/premium-headphones"
                  />
                  <ReportIssueRow
                    severity="red"
                    label="Broken image resource returning 404"
                    page="/collections/summer-sale"
                  />
                  <ReportIssueRow
                    severity="yellow"
                    label="Page load time exceeds 4 seconds"
                    page="/pages/about-us"
                  />
                </div>
              </div>

              {/* Recommendations */}
              <div>
                <h4 className="mb-3 text-sm font-medium text-[#f0f0f5]">
                  Recommendations
                </h4>
                <div className="flex flex-col gap-2.5">
                  <RecommendationItem text="Add a meta description to /products/premium-headphones (150-160 characters)." />
                  <RecommendationItem text="Replace the broken image in /collections/summer-sale with a valid URL." />
                  <RecommendationItem text="Optimize images on /pages/about-us to reduce load time below 3 seconds." />
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="mt-8 text-center">
            <Button asChild>
              <Link to="/signup">
                View Full Demo
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */

function CountCard({
  color,
  bgColor,
  count,
  label,
}: {
  color: string;
  bgColor: string;
  count: string;
  label: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center gap-1 rounded-xl border border-[#1e1e2e] p-4",
        bgColor
      )}
    >
      <span className={cn("text-2xl font-bold", color)}>{count}</span>
      <span className="text-xs text-[#8888a0]">{label}</span>
    </div>
  );
}

function ReportIssueRow({
  severity,
  label,
  page,
}: {
  severity: "red" | "yellow";
  label: string;
  page: string;
}) {
  return (
    <div className="flex items-start gap-3 rounded-lg border border-[#1e1e2e] bg-[#0a0a0f] p-3">
      <span
        className={cn(
          "mt-1.5 h-2 w-2 shrink-0 rounded-full",
          severity === "red" ? "bg-[#ef4444]" : "bg-[#eab308]"
        )}
      />
      <div className="min-w-0 flex-1">
        <p className="text-sm text-[#f0f0f5]">{label}</p>
        <p className="mt-0.5 truncate text-xs text-[#55556a]">{page}</p>
      </div>
    </div>
  );
}

function RecommendationItem({ text }: { text: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#22c55e]/10">
        <Check className="h-3 w-3 text-[#22c55e]" />
      </div>
      <p className="text-sm leading-relaxed text-[#8888a0]">{text}</p>
    </div>
  );
}
