"use client";

import { AlertTriangle, BarChart3, Bot, Clock, FileText, Search } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const benefits = [
  {
    icon: Search,
    title: "Catch Errors First",
    description:
      "Find broken links, missing pages, and 404 errors before your customers do.",
  },
  {
    icon: FileText,
    title: "SEO Monitoring",
    description:
      "Track missing meta descriptions, titles, and headings that hurt your rankings.",
  },
  {
    icon: Clock,
    title: "Daily Reports",
    description:
      "Get a clear health score and actionable report every morning.",
  },
  {
    icon: AlertTriangle,
    title: "Product Availability",
    description:
      "Detect when products go offline or pages stop working.",
  },
  {
    icon: BarChart3,
    title: "Performance Insights",
    description:
      "Identify slow-loading pages and performance bottlenecks.",
  },
  {
    icon: Bot,
    title: "Smart Recommendations",
    description:
      "AI-powered analysis explains issues and tells you exactly what to fix.",
  },
];

export default function TrustSection() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-[#f0f0f5] sm:text-4xl">
            Trusted by store owners who care about quality
          </h2>
          <p className="mt-4 text-base text-[#8888a0]">
            Join hundreds of e-commerce businesses that rely on StoreGuard to keep
            their stores running smoothly.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:gap-6">
          {benefits.map((item) => (
            <Card key={item.title} hover>
              <CardContent className="p-6">
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-[#6366f1]/10">
                  <item.icon className="h-5 w-5 text-[#6366f1]" />
                </div>
                <h3 className="mb-1 text-base font-semibold text-[#f0f0f5]">
                  {item.title}
                </h3>
                <p className="text-sm leading-relaxed text-[#8888a0]">
                  {item.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
