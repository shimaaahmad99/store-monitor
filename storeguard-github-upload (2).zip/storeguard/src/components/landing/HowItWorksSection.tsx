"use client";

import { Globe, ScanLine, ClipboardCheck } from "lucide-react";

const steps = [
  {
    number: 1,
    icon: Globe,
    title: "Add Your Store",
    description:
      "Enter your e-commerce store URL. We support Shopify, WooCommerce, Wix, Squarespace, and more.",
  },
  {
    number: 2,
    icon: ScanLine,
    title: "Automatic Daily Scans",
    description:
      "StoreGuard checks your website every day for technical issues, SEO problems, and product availability.",
  },
  {
    number: 3,
    icon: ClipboardCheck,
    title: "Get Clear Reports",
    description:
      "Receive a health score with prioritized issues and actionable recommendations. Fix what matters most.",
  },
];

export default function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-[#f0f0f5] sm:text-4xl">
            How It Works
          </h2>
          <p className="mt-4 text-base text-[#8888a0]">
            Get started in under 2 minutes. No coding required.
          </p>
        </div>

        <div className="relative mt-16">
          {/* Connecting line (desktop only) */}
          <div className="absolute left-0 right-0 top-16 hidden h-0.5 bg-gradient-to-r from-[#6366f1]/40 via-[#06b6d4]/40 to-[#6366f1]/40 lg:block" />

          <div className="grid gap-10 lg:grid-cols-3 lg:gap-8">
            {steps.map((step) => (
              <div key={step.number} className="relative flex flex-col items-center text-center">
                {/* Step circle */}
                <div className="relative z-10 flex h-14 w-14 items-center justify-center rounded-full bg-[#6366f1] text-xl font-bold text-white shadow-lg shadow-[#6366f1]/25">
                  {step.number}
                </div>
                {/* Icon */}
                <div className="mt-4 flex h-10 w-10 items-center justify-center rounded-lg bg-[#1e1e2e]">
                  <step.icon className="h-5 w-5 text-[#06b6d4]" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-[#f0f0f5]">
                  {step.title}
                </h3>
                <p className="mt-2 max-w-xs text-sm leading-relaxed text-[#8888a0]">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
