"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const faqs = [
  {
    q: "What is StoreGuard?",
    a: "StoreGuard is an automated monitoring tool for e-commerce stores. It performs daily checks on your website and reports technical issues, SEO problems, and product availability.",
  },
  {
    q: "How does the health score work?",
    a: "We analyze your store across multiple categories including availability, SEO, performance, and page structure. Each issue reduces your score based on severity. A perfect 100 means no issues were found.",
  },
  {
    q: "Which e-commerce platforms are supported?",
    a: "StoreGuard works with any website. We have optimized support for Shopify, WooCommerce, Wix, and Squarespace, but any e-commerce site with a public URL can be monitored.",
  },
  {
    q: "How often does StoreGuard scan my store?",
    a: "Depending on your plan, StoreGuard scans your store daily. Higher-tier plans may include more frequent monitoring.",
  },
  {
    q: "Is my data secure?",
    a: "Yes. We use Supabase with Row Level Security to ensure your data is isolated. API keys and credentials are never exposed in the browser.",
  },
  {
    q: "Can I cancel anytime?",
    a: "Yes, you can cancel your subscription at any time. There are no long-term contracts or cancellation fees.",
  },
  {
    q: "Do you offer a free trial?",
    a: "Yes, all plans come with a 7-day free trial so you can evaluate StoreGuard before committing.",
  },
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggle = (i: number) => {
    setOpenIndex((prev) => (prev === i ? null : i));
  };

  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-[#f0f0f5] sm:text-4xl">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="mt-12 flex flex-col gap-3">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i;
            return (
              <div
                key={i}
                className="rounded-xl border border-[#1e1e2e] bg-[#111118] overflow-hidden transition-colors"
              >
                <button
                  onClick={() => toggle(i)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-4 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm font-medium text-[#f0f0f5]">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 shrink-0 text-[#8888a0] transition-transform duration-200",
                      isOpen && "rotate-180"
                    )}
                  />
                </button>
                <div
                  className={cn(
                    "grid transition-all duration-200",
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  )}
                >
                  <div className="overflow-hidden">
                    <p className="px-6 pb-4 text-sm leading-relaxed text-[#8888a0]">
                      {faq.a}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
