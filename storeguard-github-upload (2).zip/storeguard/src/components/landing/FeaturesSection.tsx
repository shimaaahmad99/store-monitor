"use client";

import { Heart, Search, FileText, Clock, BarChart3, GitCompare } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Heart,
    title: "Health Score",
    description:
      "A single score from 0-100 that tells you exactly how healthy your store is at a glance.",
  },
  {
    icon: Search,
    title: "Issue Detection",
    description:
      "Automatically detect broken links, missing pages, HTTP errors, and more.",
  },
  {
    icon: FileText,
    title: "SEO Analysis",
    description:
      "Check meta descriptions, page titles, headings, alt text, and other SEO essentials.",
  },
  {
    icon: Clock,
    title: "Daily Monitoring",
    description:
      "Automated daily scans keep you informed without lifting a finger.",
  },
  {
    icon: BarChart3,
    title: "Smart Reports",
    description:
      "Clear, prioritized reports with actionable recommendations.",
  },
  {
    icon: GitCompare,
    title: "Change Tracking",
    description:
      "See what changed between scans and catch new issues as they appear.",
  },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-[#f0f0f5] sm:text-4xl">
            Everything you need to keep your store healthy
          </h2>
          <p className="mt-4 text-base text-[#8888a0]">
            A comprehensive toolkit that covers every aspect of your e-commerce
            store&apos;s health.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 sm:gap-6">
          {features.map((f) => (
            <Card key={f.title} hover>
              <CardContent className="flex gap-4 p-6">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#6366f1]/10">
                  <f.icon className="h-5 w-5 text-[#6366f1]" />
                </div>
                <div>
                  <h3 className="mb-1 text-base font-semibold text-[#f0f0f5]">
                    {f.title}
                  </h3>
                  <p className="text-sm leading-relaxed text-[#8888a0]">
                    {f.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
