"use client";

import { cn } from "@/lib/utils";

const ranges = [
  {
    min: 90,
    max: 100,
    label: "Excellent",
    color: "text-[#22c55e]",
    bgColor: "bg-[#22c55e]/10",
    borderColor: "border-[#22c55e]/30",
    dotColor: "bg-[#22c55e]",
    description: "Your store is in great shape.",
  },
  {
    min: 75,
    max: 89,
    label: "Good",
    color: "text-[#6366f1]",
    bgColor: "bg-[#6366f1]/10",
    borderColor: "border-[#6366f1]/30",
    dotColor: "bg-[#6366f1]",
    description: "Minor improvements needed.",
  },
  {
    min: 50,
    max: 74,
    label: "Needs Attention",
    color: "text-[#eab308]",
    bgColor: "bg-[#eab308]/10",
    borderColor: "border-[#eab308]/30",
    dotColor: "bg-[#eab308]",
    description: "Several issues should be addressed.",
  },
  {
    min: 0,
    max: 49,
    label: "Critical",
    color: "text-[#ef4444]",
    bgColor: "bg-[#ef4444]/10",
    borderColor: "border-[#ef4444]/30",
    dotColor: "bg-[#ef4444]",
    description: "Immediate action required.",
  },
];

export default function HealthScoreSection() {
  return (
    <section className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-[#f0f0f5] sm:text-4xl">
            Your Store Health Score
          </h2>
          <p className="mt-4 text-base text-[#8888a0]">
            StoreGuard analyzes your store across multiple categories and calculates
            a simple 0-100 health score.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {ranges.map((r) => (
            <div
              key={r.label}
              className={cn(
                "rounded-xl border p-6 transition-colors",
                r.borderColor,
                r.bgColor
              )}
            >
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    "inline-flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold",
                    r.dotColor,
                    r.color,
                    r.min >= 50 && r.max <= 100
                      ? "bg-opacity-20"
                      : ""
                  )}
                  style={{
                    backgroundColor:
                      r.dotColor === "bg-[#22c55e]"
                        ? "rgba(34,197,94,0.15)"
                        : r.dotColor === "bg-[#6366f1]"
                        ? "rgba(99,102,241,0.15)"
                        : r.dotColor === "bg-[#eab308]"
                        ? "rgba(234,179,8,0.15)"
                        : "rgba(239,68,68,0.15)",
                  }}
                >
                  {r.min}
                  {r.max < 100 ? `–${r.max}` : "+"}
                </span>
                <h3 className={cn("text-lg font-semibold", r.color)}>
                  {r.label}
                </h3>
              </div>
              <p className="mt-3 text-sm text-[#8888a0]">{r.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
