"use client";

import { Link } from "react-router-dom";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { PRICING_PLANS } from "@/config/pricing";

const intervalLabels: Record<string, string> = {
  day: "/day",
  month: "/month",
  year: "/year",
};

export default function PricingSection() {
  return (
    <section id="pricing" className="py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-[#f0f0f5] sm:text-4xl">
            Simple, Transparent Pricing
          </h2>
          <p className="mt-4 text-base text-[#8888a0]">
            Choose the plan that fits your store. Upgrade or downgrade anytime.
          </p>
        </div>

        <div className="mx-auto mt-12 grid max-w-5xl gap-6 lg:grid-cols-3">
          {PRICING_PLANS.map((plan) => (
            <Card
              key={plan.id}
              className={cn(
                "relative flex flex-col",
                plan.featured && "border-[#6366f1] shadow-lg shadow-[#6366f1]/10"
              )}
            >
              {/* Badges */}
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex gap-2">
                {plan.featured && (
                  <Badge className="bg-[#6366f1] text-white border-0">
                    Most Popular
                  </Badge>
                )}
                {plan.id === "yearly" && (
                  <Badge className="bg-[#06b6d4] text-white border-0">
                    Best Value
                  </Badge>
                )}
              </div>

              <CardHeader className="pt-8">
                <CardTitle>{plan.name}</CardTitle>
                <p className="text-sm text-[#8888a0]">{plan.description}</p>
              </CardHeader>

              <CardContent className="flex-1">
                {/* Price */}
                <div className="mb-6">
                  <span className="text-4xl font-bold text-[#f0f0f5]">
                    {plan.priceLabel}
                  </span>
                  <span className="ml-1 text-[#8888a0]">
                    {intervalLabels[plan.interval]}
                  </span>
                </div>

                {/* Features */}
                <ul className="flex flex-col gap-3">
                  {plan.highlights.map((h) => (
                    <li key={h} className="flex items-start gap-2">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-[#6366f1]" />
                      <span className="text-sm text-[#8888a0]">{h}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button
                  className="w-full"
                  variant={plan.featured ? "default" : "outline"}
                  asChild
                >
                  <Link to="/signup">Get Started</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <p className="mt-8 text-center text-sm text-[#55556a]">
          All plans include a 7-day free trial. No credit card required.
        </p>
      </div>
    </section>
  );
}
