import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#6366f1] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0a0a0f] disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 cursor-pointer",
  {
    variants: {
      variant: {
        default:
          "bg-[#6366f1] text-white shadow-sm shadow-[#6366f1]/20 hover:bg-[#818cf8] hover:shadow-md hover:shadow-[#6366f1]/30",
        secondary:
          "bg-[#1e1e2e] text-[#f0f0f5] shadow-sm hover:bg-[#2a2a3e]",
        outline:
          "border border-[#1e1e2e] bg-transparent text-[#f0f0f5] shadow-sm hover:bg-[#1e1e2e] hover:text-white",
        destructive:
          "bg-[#ef4444] text-white shadow-sm shadow-[#ef4444]/20 hover:bg-[#dc2626]",
        ghost:
          "text-[#8888a0] hover:bg-[#1e1e2e] hover:text-[#f0f0f5]",
        link:
          "text-[#6366f1] underline-offset-4 hover:underline hover:text-[#818cf8] shadow-none",
      },
      size: {
        sm: "h-8 px-3 text-xs",
        default: "h-10 px-4 py-2",
        lg: "h-12 px-6 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  },
)
Button.displayName = "Button"

export { Button, buttonVariants }
