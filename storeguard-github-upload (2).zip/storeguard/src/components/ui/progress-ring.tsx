import * as React from "react"
import { cn } from "@/lib/utils"

export interface ProgressRingProps {
  /** Progress value from 0 to 100 */
  value: number
  /** Diameter of the ring in pixels */
  size?: number
  /** Stroke width in pixels */
  strokeWidth?: number
  /** Override the auto-calculated color */
  color?: string
  /** Additional class for the wrapper */
  className?: string
  /** Whether to show the score number in the center */
  showValue?: boolean
}

function getScoreColor(value: number): string {
  if (value >= 90) return "#22c55e"
  if (value >= 75) return "#6366f1"
  if (value >= 60) return "#eab308"
  if (value >= 40) return "#f97316"
  return "#ef4444"
}

function getScoreLabel(value: number): string {
  if (value >= 90) return "Excellent"
  if (value >= 75) return "Good"
  if (value >= 60) return "Fair"
  if (value >= 40) return "Poor"
  return "Critical"
}

const ProgressRing = React.forwardRef<SVGSVGElement, ProgressRingProps>(
  (
    {
      value,
      size = 120,
      strokeWidth = 8,
      color,
      className,
      showValue = true,
    },
    ref,
  ) => {
    const radius = (size - strokeWidth) / 2
    const circumference = 2 * Math.PI * radius
    const clampedValue = Math.min(100, Math.max(0, value))
    const strokeDashoffset =
      circumference - (clampedValue / 100) * circumference
    const strokeColor = color ?? getScoreColor(clampedValue)

    return (
      <div
        className={cn("relative inline-flex items-center justify-center", className)}
      >
        <svg
          ref={ref}
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="-rotate-90"
        >
          {/* Track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#1e1e2e"
            strokeWidth={strokeWidth}
          />
          {/* Progress */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={strokeColor}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-700 ease-out"
            style={{
              filter: `drop-shadow(0 0 6px ${strokeColor}40)`,
            }}
          />
        </svg>
        {showValue && (
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span
              className="text-2xl font-bold"
              style={{ color: strokeColor }}
            >
              {Math.round(clampedValue)}
            </span>
            <span className="text-[10px] text-[#55556a]">
              {getScoreLabel(clampedValue)}
            </span>
          </div>
        )}
      </div>
    )
  },
)
ProgressRing.displayName = "ProgressRing"

export { ProgressRing }
