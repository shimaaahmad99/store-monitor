import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-[#6366f1] focus:ring-offset-2 focus:ring-offset-[#0a0a0f]",
  {
    variants: {
      variant: {
        default:
          "border-transparent bg-[#6366f1]/15 text-[#818cf8]",
        secondary:
          "border-transparent bg-[#1e1e2e] text-[#8888a0]",
        destructive:
          "border-transparent bg-[#ef4444]/15 text-[#ef4444]",
        outline:
          "border-[#1e1e2e] text-[#8888a0]",
        success:
          "border-transparent bg-[#22c55e]/15 text-[#22c55e]",
        warning:
          "border-transparent bg-[#eab308]/15 text-[#eab308]",
        info:
          "border-transparent bg-[#3b82f6]/15 text-[#3b82f6]",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {
  dot?: boolean
}

function Badge({ className, variant, dot, children, ...props }: BadgeProps) {
  const dotColors: Record<NonNullable<BadgeProps["variant"]>, string> = {
    default: "bg-[#6366f1]",
    secondary: "bg-[#8888a0]",
    destructive: "bg-[#ef4444]",
    outline: "bg-[#8888a0]",
    success: "bg-[#22c55e]",
    warning: "bg-[#eab308]",
    info: "bg-[#3b82f6]",
  }

  return (
    <span
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    >
      {dot && (
        <span
          className={cn(
            "h-1.5 w-1.5 rounded-full",
            dotColors[variant ?? "default"],
          )}
        />
      )}
      {children}
    </span>
  )
}

export { Badge, badgeVariants }
