import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const skeletonVariants = cva(
  "animate-pulse rounded-[#1e1e2e]",
  {
    variants: {
      variant: {
        default: "h-4 w-full rounded-md bg-[#1e1e2e]",
        circle: "rounded-full bg-[#1e1e2e]",
        text: "h-4 w-3/4 rounded bg-[#1e1e2e]",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
)

export interface SkeletonProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof skeletonVariants> {}

const Skeleton = React.forwardRef<HTMLDivElement, SkeletonProps>(
  ({ className, variant, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(skeletonVariants({ variant }), className)}
      {...props}
    />
  ),
)
Skeleton.displayName = "Skeleton"

export { Skeleton, skeletonVariants }
