import * as React from "react"
import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

export interface EmptyStateProps {
  /** A Lucide icon component to display */
  icon: LucideIcon
  /** Primary heading text */
  title: string
  /** Secondary description text */
  description?: string
  /** Optional action button (ReactNode for full control) */
  action?: React.ReactNode
  /** Additional class for the root element */
  className?: string
}

const EmptyState = React.forwardRef<HTMLDivElement, EmptyStateProps>(
  ({ icon: Icon, title, description, action, className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        "flex flex-col items-center justify-center px-6 py-12 text-center",
        className,
      )}
      {...props}
    >
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#1e1e2e]">
        <Icon className="h-6 w-6 text-[#55556a]" />
      </div>
      <h3 className="text-base font-medium text-[#f0f0f5]">{title}</h3>
      {description && (
        <p className="mt-1.5 max-w-sm text-sm text-[#55556a]">{description}</p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </div>
  ),
)
EmptyState.displayName = "EmptyState"

export { EmptyState }
