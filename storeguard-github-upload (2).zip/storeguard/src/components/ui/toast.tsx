import * as React from "react"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ToastVariant = "default" | "success" | "error" | "warning"

export interface Toast {
  id: string
  title: string
  description?: string
  variant?: ToastVariant
  duration?: number
}

interface ToastState {
  toasts: Toast[]
}

// ---------------------------------------------------------------------------
// Variant Styling
// ---------------------------------------------------------------------------

const variantStyles: Record<ToastVariant, string> = {
  default: "border-[#1e1e2e] bg-[#111118] text-[#f0f0f5]",
  success: "border-[#22c55e]/30 bg-[#22c55e]/10 text-[#22c55e]",
  error: "border-[#ef4444]/30 bg-[#ef4444]/10 text-[#ef4444]",
  warning: "border-[#eab308]/30 bg-[#eab308]/10 text-[#eab308]",
}

const variantIcons: Record<ToastVariant, string> = {
  default: "bg-[#6366f1]",
  success: "bg-[#22c55e]",
  error: "bg-[#ef4444]",
  warning: "bg-[#eab308]",
}

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

type ToastAction =
  | { type: "ADD_TOAST"; toast: Toast }
  | { type: "DISMISS_TOAST"; id: string }
  | { type: "CLEAR_TOASTS" }

let count = 0

function genId(): string {
  count += 1
  return `toast-${count}-${Date.now()}`
}

type ToastContextValue = {
  toasts: Toast[]
  addToast: (toast: Omit<Toast, "id">) => void
  dismissToast: (id: string) => void
  clearToasts: () => void
}

const ToastContext = React.createContext<ToastContextValue | undefined>(
  undefined,
)

function toastReducer(state: ToastState, action: ToastAction): ToastState {
  switch (action.type) {
    case "ADD_TOAST":
      return { toasts: [...state.toasts, action.toast] }
    case "DISMISS_TOAST":
      return {
        toasts: state.toasts.filter((t) => t.id !== action.id),
      }
    case "CLEAR_TOASTS":
      return { toasts: [] }
    default:
      return state
  }
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = React.useReducer(toastReducer, {
    toasts: [],
  })

  const addToast = React.useCallback((toast: Omit<Toast, "id">) => {
    const id = genId()
    const newToast: Toast = { id, ...toast }
    dispatch({ type: "ADD_TOAST", toast: newToast })

    const duration = toast.duration ?? 5000
    if (duration > 0) {
      setTimeout(() => {
        dispatch({ type: "DISMISS_TOAST", id })
      }, duration)
    }
  }, [])

  const dismissToast = React.useCallback((id: string) => {
    dispatch({ type: "DISMISS_TOAST", id })
  }, [])

  const clearToasts = React.useCallback(() => {
    dispatch({ type: "CLEAR_TOASTS" })
  }, [])

  return (
    <ToastContext.Provider
      value={{ toasts: state.toasts, addToast, dismissToast, clearToasts }}
    >
      {children}
    </ToastContext.Provider>
  )
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useToast(): ToastContextValue {
  const context = React.useContext(ToastContext)
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider")
  }
  return context
}

// ---------------------------------------------------------------------------
// Container
// ---------------------------------------------------------------------------

export function ToastContainer() {
  const { toasts, dismissToast } = useToast()

  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 w-full max-w-sm">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          role="alert"
          className={cn(
            "pointer-events-auto flex items-start gap-3 rounded-xl border p-4 shadow-2xl transition-all duration-300 animate-in slide-in-from-bottom-5 fade-in",
            variantStyles[toast.variant ?? "default"],
          )}
        >
          <div
            className={cn(
              "mt-0.5 h-2 w-2 shrink-0 rounded-full",
              variantIcons[toast.variant ?? "default"],
            )}
          />
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium text-[#f0f0f5]">{toast.title}</p>
            {toast.description && (
              <p className="text-xs text-[#8888a0]">{toast.description}</p>
            )}
          </div>
          <button
            onClick={() => dismissToast(toast.id)}
            className="shrink-0 rounded-md p-0.5 text-[#55556a] transition-colors hover:text-[#f0f0f5]"
          >
            <X className="h-3.5 w-3.5" />
            <span className="sr-only">Dismiss</span>
          </button>
        </div>
      ))}
    </div>
  )
}