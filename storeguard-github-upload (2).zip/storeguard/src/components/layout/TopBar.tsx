import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Menu,
  Search,
  Bell,
  ChevronDown,
  User,
  Settings,
  LogOut,
  Store,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { useStores } from "@/hooks/useStores";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

interface TopBarProps {
  onMenuClick: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function TopBar({ onMenuClick }: TopBarProps) {
  const { profile, logout } = useAuth();
  const { stores } = useStores();
  const navigate = useNavigate();

  const [selectedStoreId, setSelectedStoreId] = useState<string | null>(
    stores[0]?.id ?? null,
  );

  const userName = profile?.fullName ?? profile?.email ?? "User";
  const userAvatar = profile?.avatarUrl;
  const currentStore = stores.find((s) => s.id === selectedStoreId);

  const unreadCount = 3; // placeholder

  return (
    <header
      className={cn(
        "sticky top-0 z-30 flex h-16 shrink-0 items-center gap-4 border-b border-[#1e1e2e] bg-[#0a0a0f]/80 px-4 backdrop-blur-md sm:px-6",
      )}
    >
      {/* Mobile menu button */}
      <button
        onClick={onMenuClick}
        className={cn(
          "flex h-9 w-9 items-center justify-center rounded-lg text-[#8888a0] transition-colors hover:bg-[#1a1a28] hover:text-[#f0f0f5] md:hidden",
        )}
        aria-label="Toggle sidebar"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Store selector dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            className={cn(
              "flex items-center gap-2 rounded-lg border border-[#1e1e2e] bg-[#111118] px-3 py-2 text-sm text-[#f0f0f5] transition-colors hover:border-[#2a2a3a]",
              "max-w-[200px] sm:max-w-[260px]",
            )}
          >
            <Store className="h-4 w-4 shrink-0 text-[#06b6d4]" />
            <span className="truncate">
              {currentStore?.name ?? "All Stores"}
            </span>
            <ChevronDown className="ml-auto h-3.5 w-3.5 shrink-0 text-[#55556a]" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-64">
          <DropdownMenuLabel>Select Store</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {stores.map((store) => (
            <DropdownMenuItem
              key={store.id}
              onClick={() => setSelectedStoreId(store.id)}
              className={cn(
                store.id === selectedStoreId && "bg-[#1a1a3a] text-white",
              )}
            >
              <Store className="mr-2 h-4 w-4 text-[#06b6d4]" />
              <div className="flex flex-col gap-0.5">
                <span className="text-sm font-medium">{store.name}</span>
                <span className="truncate text-xs text-[#55556a]">
                  {store.url}
                </span>
              </div>
            </DropdownMenuItem>
          ))}
          {stores.length === 0 && (
            <div className="px-2 py-3 text-center text-sm text-[#55556a]">
              No stores yet
            </div>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Search input — hidden on small screens */}
      <div className="hidden flex-1 md:block">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#55556a]" />
          <input
            type="text"
            placeholder="Search scans, issues, stores..."
            readOnly
            className={cn(
              "h-9 w-full rounded-lg border border-[#1e1e2e] bg-[#111118] pl-9 pr-4 text-sm text-[#f0f0f5] placeholder:text-[#55556a]",
              "cursor-default transition-colors focus:border-[#6366f1]/50 focus:outline-none focus:ring-1 focus:ring-[#6366f1]/30",
            )}
          />
        </div>
      </div>

      {/* Right section */}
      <div className="ml-auto flex items-center gap-2">
        {/* Notification bell */}
        <button
          onClick={() => navigate("/dashboard/notifications")}
          className={cn(
            "relative flex h-9 w-9 items-center justify-center rounded-lg text-[#8888a0] transition-colors hover:bg-[#1a1a28] hover:text-[#f0f0f5]",
          )}
          aria-label="Notifications"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span
              className={cn(
                "absolute -right-0.5 -top-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[#6366f1] px-1 text-[10px] font-bold leading-none text-white",
              )}
            >
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          )}
        </button>

        {/* User avatar dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className={cn(
                "flex items-center gap-2 rounded-lg p-1 transition-colors hover:bg-[#1a1a28]",
              )}
              aria-label="User menu"
            >
              <Avatar className="h-8 w-8">
                {userAvatar && <AvatarImage src={userAvatar} alt={userName} />}
                <AvatarFallback name={userName} />
              </Avatar>
              <ChevronDown className="hidden h-3.5 w-3.5 text-[#55556a] sm:block" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col gap-1">
                <p className="text-sm font-medium text-[#f0f0f5]">
                  {userName}
                </p>
                <p className="text-xs text-[#55556a]">{profile?.email}</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/dashboard/settings")}>
              <User className="mr-2 h-4 w-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/dashboard/settings")}>
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={logout}
              className="text-[#ef4444] focus:text-[#ef4444]"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
