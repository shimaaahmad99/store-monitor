import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { useStores } from "@/hooks/useStores";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { Shield } from "lucide-react";

// ---------------------------------------------------------------------------
// Full-page loading skeleton
// ---------------------------------------------------------------------------

function LoadingScreen() {
  return (
    <div
      className={cn(
        "flex min-h-screen flex-col items-center justify-center gap-6 bg-[#0a0a0f]",
      )}
    >
      <div className="flex items-center gap-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#6366f1]/10">
          <Shield className="h-5 w-5 animate-pulse text-[#6366f1]" />
        </div>
        <Skeleton className="h-6 w-28" />
      </div>
      <div className="flex flex-col items-center gap-3">
        <Skeleton className="h-4 w-48" />
        <Skeleton className="h-4 w-36" />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

interface ProtectedRouteProps {
  children?: React.ReactNode;
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, loading: authLoading } = useAuth();
  const { stores, loading: storesLoading } = useStores();

  // Still checking auth
  if (authLoading) {
    return <LoadingScreen />;
  }

  // Not authenticated → redirect to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Authenticated but stores still loading — keep showing loader
  if (storesLoading) {
    return <LoadingScreen />;
  }

  // If children are provided, render them directly
  if (children) {
    return <>{children}</>;
  }

  // Authenticated but no stores → redirect to onboarding
  if (stores.length === 0) {
    return <Navigate to="/onboarding" replace />;
  }

  // All good — render child routes
  return <Outlet />;
}
