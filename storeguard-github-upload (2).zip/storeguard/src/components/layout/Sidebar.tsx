import { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Shield,
  LayoutDashboard,
  Store,
  ScanSearch,
  AlertTriangle,
  FileText,
  Bell,
  CreditCard,
  Settings,
  LogOut,
  ChevronLeft,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

// ---------------------------------------------------------------------------
// Navigation items
// ---------------------------------------------------------------------------

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  { label: "Overview", href: "/dashboard", icon: LayoutDashboard },
  { label: "Stores", href: "/dashboard/stores", icon: Store },
  { label: "Scans", href: "/dashboard/scans", icon: ScanSearch },
  { label: "Issues", href: "/dashboard/issues", icon: AlertTriangle },
  { label: "Reports", href: "/dashboard/reports", icon: FileText },
  { label: "Notifications", href: "/dashboard/notifications", icon: Bell },
  { label: "Billing", href: "/dashboard/billing", icon: CreditCard },
  { label: "Settings", href: "/dashboard/settings", icon: Settings },
];

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const { profile, logout } = useAuth();
  const location = useLocation();
  const [isVisible, setIsVisible] = useState(false);

  // Animation: slight delay for smooth open/close
  useEffect(() => {
    if (isOpen) {
      // Allow DOM paint, then show
      const id = requestAnimationFrame(() => setIsVisible(true));
      return () => cancelAnimationFrame(id);
    } else {
      setIsVisible(false);
    }
  }, [isOpen]);

  // Close sidebar on route change (mobile)
  useEffect(() => {
    onClose();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  const isActive = (href: string) => {
    if (href === "/dashboard") {
      return location.pathname === "/dashboard";
    }
    return location.pathname.startsWith(href);
  };

  const userName = profile?.fullName ?? profile?.email ?? "User";
  const userAvatar = profile?.avatarUrl;

  return (
    <>
      {/* ---- Mobile backdrop ---- */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity duration-300 md:hidden",
          isOpen ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        aria-hidden="true"
        onClick={onClose}
      />

      {/* ---- Sidebar panel ---- */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-50 flex h-full w-64 flex-col border-r border-[#1e1e2e] bg-[#0d0d14] transition-transform duration-300 ease-in-out md:static md:z-0 md:translate-x-0",
          isOpen || isVisible ? "translate-x-0" : "-translate-x-full",
        )}
      >
        {/* Logo */}
        <div className="flex h-16 shrink-0 items-center justify-between px-5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#6366f1]/10">
              <Shield className="h-4.5 w-4.5 text-[#6366f1]" />
            </div>
            <span className="text-lg font-bold tracking-tight text-[#f0f0f5]">
              StoreGuard
            </span>
          </div>

          {/* Close button — mobile only */}
          <button
            onClick={onClose}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-lg text-[#8888a0] transition-colors hover:bg-[#1a1a28] hover:text-[#f0f0f5] md:hidden",
            )}
            aria-label="Close sidebar"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>

        {/* Navigation links */}
        <ScrollArea className="flex-1 px-3 py-2">
          <nav className="flex flex-col gap-1" aria-label="Main navigation">
            {NAV_ITEMS.map((item) => {
              const active = isActive(item.href);
              const Icon = item.icon;

              return (
                <NavLink
                  key={item.href}
                  to={item.href}
                  onClick={onClose}
                  className={cn(
                    "group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    active
                      ? "text-white bg-[#1a1a3a] border-r-2 border-[#6366f1]"
                      : "text-[#8888a0] hover:text-[#f0f0f5] hover:bg-[#1a1a28]",
                  )}
                >
                  <Icon
                    className={cn(
                      "h-[18px] w-[18px] shrink-0",
                      active ? "text-[#6366f1]" : "text-[#55556a] group-hover:text-[#8888a0]",
                    )}
                  />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>
        </ScrollArea>

        {/* Bottom: user info + logout */}
        <div className="shrink-0">
          <Separator className="bg-[#1e1e2e]" />
          <div className="flex items-center gap-3 px-4 py-3">
            <Avatar className="h-8 w-8">
              {userAvatar && <AvatarImage src={userAvatar} alt={userName} />}
              <AvatarFallback name={userName} />
            </Avatar>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-[#f0f0f5]">
                {userName}
              </p>
              <p className="truncate text-xs text-[#55556a]">
                {profile?.email}
              </p>
            </div>
            <button
              onClick={logout}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-[#55556a] transition-colors hover:bg-[#1a1a28] hover:text-[#f0f0f5]"
              aria-label="Log out"
              title="Log out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
