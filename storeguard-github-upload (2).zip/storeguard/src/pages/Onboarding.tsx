import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Globe,
  Store,
  Layers,
  ScanLine,
  ArrowLeft,
  ArrowRight,
  Loader2,
  Check,
  Shield,
  Search,
  BarChart3,
  Link2,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { useStores } from "@/hooks/useStores";
import { useScans } from "@/hooks/useScans";
import { cn, isValidHttpsUrl } from "@/lib/utils";
import type { StorePlatform, ScanCheckCategory } from "@/types";

// ============================================================================
// Constants
// ============================================================================

const TOTAL_STEPS = 4;

const PLATFORMS: {
  id: StorePlatform | "other";
  name: string;
  label: string;
}[] = [
  { id: "shopify", name: "Shopify", label: "S" },
  { id: "woocommerce", name: "WooCommerce", label: "W" },
  { id: "wix", name: "Wix", label: "Wi" },
  { id: "squarespace", name: "Squarespace", label: "Sq" },
  { id: "custom", name: "Custom", label: "C" },
  { id: "other", name: "Other", label: "?" },
];

const MONITORING_OPTIONS: {
  key: ScanCheckCategory;
  label: string;
  description: string;
  icon: React.ElementType;
}[] = [
  {
    key: "security",
    label: "Technical health",
    description: "SSL, security headers, TLS configuration",
    icon: Shield,
  },
  {
    key: "seo",
    label: "SEO",
    description: "Meta tags, headings, Open Graph, structured data",
    icon: Search,
  },
  {
    key: "content",
    label: "Products",
    description: "Product pages, images, content quality",
    icon: BarChart3,
  },
  {
    key: "performance",
    label: "Broken links",
    description: "Detect broken internal and external links",
    icon: Link2,
  },
  {
    key: "performance",
    label: "Performance",
    description: "Page speed, LCP, CLS, page size, caching",
    icon: Zap,
  },
];

const SCAN_STEPS = [
  "Preparing scan...",
  "Checking website...",
  "Analyzing pages...",
  "Checking SEO...",
  "Analyzing issues...",
  "Generating report...",
];

// ============================================================================
// Helpers
// ============================================================================

function extractDomainFromUrl(url: string): string {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, "").replace(/\..+$/, "");
  } catch {
    return "";
  }
}

function isValidUrl(url: string): boolean {
  if (!url.startsWith("https://")) return false;
  if (url.includes("localhost")) return false;
  if (url.includes("127.0.0.1")) return false;
  if (url.includes("192.168.") || url.includes("10.")) return false;
  return isValidHttpsUrl(url);
}

// ============================================================================
// Step Indicator
// ============================================================================

function StepIndicator({ currentStep }: { currentStep: number }) {
  return (
    <div className="flex items-center justify-center gap-0">
      {Array.from({ length: TOTAL_STEPS }, (_, i) => i + 1).map(
        (step, idx) => {
          const isCompleted = step < currentStep;
          const isCurrent = step === currentStep;
          const isLast = idx === TOTAL_STEPS - 1;

          return (
            <div key={step} className="flex items-center">
              <div
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full text-xs font-semibold transition-all duration-300",
                  isCompleted &&
                    "bg-[#22c55e] text-white",
                  isCurrent &&
                    "bg-[#6366f1] text-white shadow-lg shadow-[#6366f1]/30",
                  !isCompleted &&
                    !isCurrent &&
                    "border-2 border-[#1e1e2e] bg-[#0d0d14] text-[#55556a]",
                )}
              >
                {isCompleted ? (
                  <Check className="h-4 w-4" />
                ) : (
                  step
                )}
              </div>
              {!isLast && (
                <div
                  className={cn(
                    "h-0.5 w-12 sm:w-16 transition-colors duration-300",
                    step < currentStep ? "bg-[#22c55e]" : "bg-[#1e1e2e]",
                  )}
                />
              )}
            </div>
          );
        },
      )}
    </div>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Onboarding() {
  const navigate = useNavigate();
  const { createStore } = useStores();
  const { triggerScan } = useScans();

  const [step, setStep] = useState(1);
  const [url, setUrl] = useState("");
  const [urlError, setUrlError] = useState("");
  const [storeName, setStoreName] = useState("");
  const [platform, setPlatform] = useState<StorePlatform | "other">("shopify");
  const [monitorAll, setMonitorAll] = useState(true);
  const [selectedChecks, setSelectedChecks] = useState<Set<string>>(
    new Set(MONITORING_OPTIONS.map((o) => o.key)),
  );
  const [scanning, setScanning] = useState(false);
  const [scanStep, setScanStep] = useState(0);

  // -----------------------------------------------------------------------
  // Step 1: URL validation
  // -----------------------------------------------------------------------
  const handleNextFromStep1 = () => {
    const trimmed = url.trim();
    if (!trimmed) {
      setUrlError("Please enter your store URL.");
      return;
    }
    if (!isValidUrl(trimmed)) {
      setUrlError(
        "Please enter a valid HTTPS URL. Localhost and private IPs are not allowed.",
      );
      return;
    }
    setUrlError("");
    setUrl(trimmed);

    // Auto-fill store name from domain
    const domain = extractDomainFromUrl(trimmed);
    if (domain && !storeName) {
      setStoreName(
        domain
          .charAt(0)
          .toUpperCase()
          .concat(domain.slice(1)),
      );
    }

    setStep(2);
  };

  // -----------------------------------------------------------------------
  // Step 2: Store name
  // -----------------------------------------------------------------------
  const handleNextFromStep2 = () => {
    if (!storeName.trim()) return;
    setStep(3);
  };

  // -----------------------------------------------------------------------
  // Step 3: Platform
  // -----------------------------------------------------------------------
  const handleNextFromStep3 = () => {
    setStep(4);
  };

  // -----------------------------------------------------------------------
  // Step 4: Monitoring options
  // -----------------------------------------------------------------------
  const toggleCheck = (key: string) => {
    setSelectedChecks((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const handleToggleAll = () => {
    if (monitorAll) {
      setSelectedChecks(new Set());
    } else {
      setSelectedChecks(new Set(MONITORING_OPTIONS.map((o) => o.key)));
    }
    setMonitorAll((prev) => !prev);
  };

  // -----------------------------------------------------------------------
  // Final step: Run scan
  // -----------------------------------------------------------------------
  const handleStartScan = async () => {
    setScanning(true);
    setScanStep(0);

    // Simulate scan progress steps
    for (let i = 0; i < SCAN_STEPS.length - 1; i++) {
      await new Promise((resolve) => setTimeout(resolve, 800));
      setScanStep(i + 1);
    }

    // Create store
    const storePlatform =
      platform === "other" ? ("custom" as StorePlatform) : platform;
    await createStore({
      name: storeName.trim(),
      url: url.trim(),
      platform: storePlatform,
    });

    // Trigger actual scan
    await triggerScan(url.trim());

    // Final step
    await new Promise((resolve) => setTimeout(resolve, 500));
    setScanStep(SCAN_STEPS.length - 1);

    // Redirect to dashboard after a moment
    await new Promise((resolve) => setTimeout(resolve, 800));
    navigate("/dashboard");
  };

  // -----------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0a0a0f] px-4 py-12">
      <div className="w-full max-w-lg space-y-8">
        {/* Progress Indicator */}
        <StepIndicator currentStep={step} />

        {/* Scanning State */}
        {scanning ? (
          <Card className="text-center">
            <CardContent className="space-y-6 p-8">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#6366f1]/10">
                <ScanLine className="h-8 w-8 animate-pulse text-[#6366f1]" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-[#f0f0f5]">
                  Scanning your store...
                </h2>
                <p className="mt-2 text-sm text-[#8888a0]">
                  {SCAN_STEPS[scanStep] ?? SCAN_STEPS[SCAN_STEPS.length - 1]!}
                </p>
              </div>
              <div className="space-y-2">
                {SCAN_STEPS.map((s, idx) => (
                  <div
                    key={s}
                    className={cn(
                      "flex items-center gap-3 text-sm transition-all duration-300",
                      idx <= scanStep
                        ? "text-[#f0f0f5]"
                        : "text-[#55556a]",
                    )}
                  >
                    {idx < scanStep ? (
                      <Check className="h-4 w-4 text-[#22c55e]" />
                    ) : idx === scanStep ? (
                      <Loader2 className="h-4 w-4 animate-spin text-[#6366f1]" />
                    ) : (
                      <div className="h-4 w-4 rounded-full border border-[#1e1e2e]" />
                    )}
                    <span>{s}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Step 1: URL Input */}
            {step === 1 && (
              <Card>
                <CardContent className="space-y-6 p-8">
                  <div className="text-center">
                    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#6366f1]/10">
                      <Globe className="h-6 w-6 text-[#6366f1]" />
                    </div>
                    <h2 className="text-xl font-bold text-[#f0f0f5]">
                      What is your store URL?
                    </h2>
                    <p className="mt-1 text-sm text-[#8888a0]">
                      Enter the URL of the online store you want to monitor.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="onboarding-url">Store URL</Label>
                    <Input
                      id="onboarding-url"
                      leftIcon={
                        <Globe className="h-4 w-4" />
                      }
                      value={url}
                      onChange={(e) => {
                        setUrl(e.target.value);
                        if (urlError) setUrlError("");
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleNextFromStep1();
                      }}
                      placeholder="https://your-store.com"
                      error={!!urlError}
                    />
                    {urlError && (
                      <p className="text-xs text-[#ef4444]">{urlError}</p>
                    )}
                  </div>
                  <Button
                    className="w-full gap-2"
                    onClick={handleNextFromStep1}
                  >
                    Next
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Step 2: Store Name */}
            {step === 2 && (
              <Card>
                <CardContent className="space-y-6 p-8">
                  <div className="text-center">
                    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#6366f1]/10">
                      <Store className="h-6 w-6 text-[#6366f1]" />
                    </div>
                    <h2 className="text-xl font-bold text-[#f0f0f5]">
                      What's your store name?
                    </h2>
                    <p className="mt-1 text-sm text-[#8888a0]">
                      We'll use this to identify your store in the dashboard.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="onboarding-name">Store Name</Label>
                    <Input
                      id="onboarding-name"
                      leftIcon={
                        <Store className="h-4 w-4" />
                      }
                      value={storeName}
                      onChange={(e) => setStoreName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleNextFromStep2();
                      }}
                      placeholder="My Store"
                    />
                  </div>
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1 gap-2"
                      onClick={() => setStep(1)}
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Back
                    </Button>
                    <Button
                      className="flex-1 gap-2"
                      onClick={handleNextFromStep2}
                      disabled={!storeName.trim()}
                    >
                      Next
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 3: Platform Selection */}
            {step === 3 && (
              <Card>
                <CardContent className="space-y-6 p-8">
                  <div className="text-center">
                    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#6366f1]/10">
                      <Layers className="h-6 w-6 text-[#6366f1]" />
                    </div>
                    <h2 className="text-xl font-bold text-[#f0f0f5]">
                      What platform do you use?
                    </h2>
                    <p className="mt-1 text-sm text-[#8888a0]">
                      Select your e-commerce platform for optimized scanning.
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                    {PLATFORMS.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setPlatform(p.id)}
                        className={cn(
                          "flex flex-col items-center gap-2 rounded-lg border p-4 transition-all duration-200",
                          platform === p.id
                            ? "border-[#6366f1] bg-[#6366f1]/10 text-[#f0f0f5]"
                            : "border-[#1e1e2e] bg-[#0d0d14] text-[#8888a0] hover:border-[#2a2a3e] hover:text-[#f0f0f5]",
                        )}
                      >
                        <span
                          className={cn(
                            "flex h-10 w-10 items-center justify-center rounded-lg text-sm font-bold",
                            platform === p.id
                              ? "bg-[#6366f1] text-white"
                              : "bg-[#1e1e2e]",
                          )}
                        >
                          {p.label}
                        </span>
                        <span className="text-xs font-medium">
                          {p.name}
                        </span>
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1 gap-2"
                      onClick={() => setStep(2)}
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Back
                    </Button>
                    <Button
                      className="flex-1 gap-2"
                      onClick={handleNextFromStep3}
                    >
                      Next
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 4: Monitoring Options */}
            {step === 4 && (
              <Card>
                <CardContent className="space-y-6 p-8">
                  <div className="text-center">
                    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#6366f1]/10">
                      <ScanLine className="h-6 w-6 text-[#6366f1]" />
                    </div>
                    <h2 className="text-xl font-bold text-[#f0f0f5]">
                      What do you want to monitor?
                    </h2>
                    <p className="mt-1 text-sm text-[#8888a0]">
                      Choose the health checks for your store.
                    </p>
                  </div>

                  {/* Monitor Everything toggle */}
                  <div className="flex items-center justify-between rounded-lg border border-[#1e1e2e] bg-[#0d0d14] px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-[#f0f0f5]">
                        Monitor Everything
                      </p>
                      <p className="text-xs text-[#55556a]">
                        Enable all available checks.
                      </p>
                    </div>
                    <Switch
                      checked={monitorAll}
                      onCheckedChange={handleToggleAll}
                    />
                  </div>

                  {/* Individual options */}
                  <div className="space-y-2">
                    {MONITORING_OPTIONS.map((opt) => {
                      const Icon = opt.icon;
                      const isSelected = selectedChecks.has(opt.key);
                      return (
                        <button
                          key={`${opt.key}-${opt.label}`}
                          type="button"
                          onClick={() => toggleCheck(opt.key)}
                          className={cn(
                            "flex w-full items-center gap-3 rounded-lg border px-4 py-3 text-left transition-all duration-200",
                            isSelected
                              ? "border-[#6366f1]/50 bg-[#6366f1]/5"
                              : "border-[#1e1e2e] bg-[#0d0d14] hover:border-[#2a2a3e]",
                          )}
                        >
                          <div
                            className={cn(
                              "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                              isSelected
                                ? "bg-[#6366f1]/10"
                                : "bg-[#1e1e2e]",
                            )}
                          >
                            <Icon
                              className={cn(
                                "h-4 w-4",
                                isSelected
                                  ? "text-[#6366f1]"
                                  : "text-[#55556a]",
                              )}
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p
                              className={cn(
                                "text-sm font-medium",
                                isSelected
                                  ? "text-[#f0f0f5]"
                                  : "text-[#8888a0]",
                              )}
                            >
                              {opt.label}
                            </p>
                            <p className="text-xs text-[#55556a]">
                              {opt.description}
                            </p>
                          </div>
                          <div
                            className={cn(
                              "flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors",
                              isSelected
                                ? "border-[#6366f1] bg-[#6366f1] text-white"
                                : "border-[#1e1e2e]",
                            )}
                          >
                            {isSelected && (
                              <Check className="h-3 w-3" />
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1 gap-2"
                      onClick={() => setStep(3)}
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Back
                    </Button>
                    <Button
                      className="flex-1 gap-2"
                      onClick={handleStartScan}
                      disabled={selectedChecks.size === 0}
                    >
                      <ScanLine className="h-4 w-4" />
                      Start First Scan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}
