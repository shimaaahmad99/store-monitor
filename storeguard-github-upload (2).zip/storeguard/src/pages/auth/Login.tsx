"use client";

import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import { useAuth } from "@/context/AuthContext";
import AuthLayout from "@/layouts/AuthLayout";

export default function Login() {
  const { login, isDemoMode } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim()) {
      setError("Please enter your email address.");
      return;
    }

    if (!password) {
      setError("Please enter your password.");
      return;
    }

    setLoading(true);
    const { error: authError } = await login(email, password);
    setLoading(false);

    if (authError) {
      setError(authError);
      return;
    }

    navigate("/dashboard");
  };

  return (
    <AuthLayout>
      <Card className="border-0 bg-transparent shadow-none">
        <CardHeader className="p-0 pb-6">
          <CardTitle className="text-2xl font-bold text-[#f0f0f5]">
            Welcome back
          </CardTitle>
          <CardDescription className="text-[#8888a0]">
            Sign in to your account
          </CardDescription>
        </CardHeader>

        {isDemoMode && (
          <div className="mb-4 rounded-lg border border-[#6366f1]/20 bg-[#6366f1]/5 px-4 py-3">
            <p className="text-sm text-[#8888a0]">
              <Shield className="mr-1.5 inline-block h-4 w-4 text-[#6366f1]" />
              Demo mode is active. Authentication is disabled.
            </p>
          </div>
        )}

        {error && (
          <div className="mb-4 rounded-lg border border-red-500/20 bg-red-500/5 px-4 py-3">
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4 p-0">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#f0f0f5]">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
                disabled={loading}
                className="border-[#1e1e2e] bg-[#0a0a0f] text-[#f0f0f5] placeholder:text-[#55556a] focus-visible:ring-[#6366f1]"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-[#f0f0f5]">
                  Password
                </Label>
                <Link
                  to="/forgot-password"
                  className="text-xs text-[#6366f1] transition-colors hover:text-[#818cf8]"
                >
                  Forgot password?
                </Link>
              </div>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
                disabled={loading}
                className="border-[#1e1e2e] bg-[#0a0a0f] text-[#f0f0f5] placeholder:text-[#55556a] focus-visible:ring-[#6366f1]"
              />
            </div>
          </CardContent>

          <CardFooter className="flex-col gap-4 p-0 pt-6">
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#6366f1] text-white hover:bg-[#5558e6]"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg
                    className="h-4 w-4 animate-spin"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                    />
                  </svg>
                  Signing in...
                </span>
              ) : (
                "Sign In"
              )}
            </Button>

            <p className="text-center text-sm text-[#8888a0]">
              Don&apos;t have an account?{" "}
              <Link
                to="/signup"
                className="font-medium text-[#6366f1] transition-colors hover:text-[#818cf8]"
              >
                Sign up
              </Link>
            </p>
          </CardFooter>
        </form>
      </Card>
    </AuthLayout>
  );
}
