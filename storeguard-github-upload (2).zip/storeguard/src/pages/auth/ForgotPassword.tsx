"use client";

import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import { useAuth } from "@/context/AuthContext";
import AuthLayout from "@/layouts/AuthLayout";

export default function ForgotPassword() {
  const { resetPassword } = useAuth();

  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim()) {
      setError("Please enter your email address.");
      return;
    }

    setLoading(true);
    const { error: authError } = await resetPassword(email);
    setLoading(false);

    if (authError) {
      setError(authError);
      return;
    }

    setSuccess(true);
  };

  return (
    <AuthLayout>
      <Card className="border-0 bg-transparent shadow-none">
        <CardHeader className="p-0 pb-6">
          <CardTitle className="text-2xl font-bold text-[#f0f0f5]">
            Reset your password
          </CardTitle>
          <CardDescription className="text-[#8888a0]">
            Enter your email and we&apos;ll send you a reset link
          </CardDescription>
        </CardHeader>

        {success ? (
          <>
            <CardContent className="p-0">
              <div className="rounded-lg border border-green-500/20 bg-green-500/5 px-4 py-3">
                <p className="text-sm text-green-400">
                  Check your email for a reset link. If you don&apos;t see it,
                  check your spam folder.
                </p>
              </div>
            </CardContent>
            <CardFooter className="p-0 pt-6">
              <Link
                to="/login"
                className="text-sm font-medium text-[#6366f1] transition-colors hover:text-[#818cf8]"
              >
                Back to sign in
              </Link>
            </CardFooter>
          </>
        ) : (
          <>
            {error && (
              <div className="mb-4 rounded-lg border border-red-500/20 bg-red-500/5 px-4 py-3">
                <p className="text-sm text-red-400">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4 p-0">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-[#f0f0f5]">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                    required
                    disabled={loading}
                    className="border-[#1e1e2e] bg-[#0a0a0f] text-[#f0f0f5] placeholder:text-[#55556a] focus-visible:ring-[#6366f1]"
                  />
                </div>
              </CardContent>

              <CardFooter className="flex-col gap-4 p-0 pt-6">
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#6366f1] text-white hover:bg-[#5558e6]"
                >
                  {loading ? (
                    <span className="flex items-center gap-2">
                      <svg
                        className="h-4 w-4 animate-spin"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                        />
                      </svg>
                      Sending...
                    </span>
                  ) : (
                    "Send Reset Link"
                  )}
                </Button>

                <p className="text-center text-sm text-[#8888a0]">
                  Remember your password?{" "}
                  <Link
                    to="/login"
                    className="font-medium text-[#6366f1] transition-colors hover:text-[#818cf8]"
                  >
                    Sign in
                  </Link>
                </p>
              </CardFooter>
            </form>
          </>
        )}
      </Card>
    </AuthLayout>
  );
}
