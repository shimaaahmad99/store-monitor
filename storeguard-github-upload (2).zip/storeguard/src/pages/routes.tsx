import { lazy, Suspense, type ReactNode } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

import DashboardLayout from '@/layouts/DashboardLayout';
import ProtectedRoute from '@/components/layout/ProtectedRoute';
import { Skeleton } from '@/components/ui/skeleton';

// Code-split imports for smaller initial bundle
const Landing = lazy(() => import('@/pages/Landing'));
const Login = lazy(() => import('@/pages/auth/Login'));
const Signup = lazy(() => import('@/pages/auth/Signup'));
const ForgotPassword = lazy(() => import('@/pages/auth/ForgotPassword'));
const ResetPassword = lazy(() => import('@/pages/auth/ResetPassword'));
const Onboarding = lazy(() => import('@/pages/Onboarding'));
const Overview = lazy(() => import('@/pages/dashboard/Overview'));
const Stores = lazy(() => import('@/pages/dashboard/Stores'));
const Scans = lazy(() => import('@/pages/dashboard/Scans'));
const Issues = lazy(() => import('@/pages/dashboard/Issues'));
const Reports = lazy(() => import('@/pages/dashboard/Reports'));
const Notifications = lazy(() => import('@/pages/dashboard/Notifications'));
const Billing = lazy(() => import('@/pages/dashboard/Billing'));
const Settings = lazy(() => import('@/pages/dashboard/Settings'));

function PageLoader() {
  return (
    <div className="flex h-64 items-center justify-center">
      <div className="flex flex-col items-center gap-3">
        <Skeleton className="h-8 w-8 rounded-full" />
        <Skeleton className="h-3 w-24" />
      </div>
    </div>
  );
}

function LazyPage({ children }: { children: ReactNode }) {
  return <Suspense fallback={<PageLoader />}>{children}</Suspense>;
}

function RedirectIfAuthenticated({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#0a0a0f]">
        <div className="flex flex-col items-center gap-4">
          <Skeleton className="h-12 w-12 rounded-full" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route
        path="/"
        element={
          <RedirectIfAuthenticated>
            <LazyPage><Landing /></LazyPage>
          </RedirectIfAuthenticated>
        }
      />
      <Route
        path="/login"
        element={
          <RedirectIfAuthenticated>
            <LazyPage><Login /></LazyPage>
          </RedirectIfAuthenticated>
        }
      />
      <Route
        path="/signup"
        element={
          <RedirectIfAuthenticated>
            <LazyPage><Signup /></LazyPage>
          </RedirectIfAuthenticated>
        }
      />
      <Route
        path="/forgot-password"
        element={
          <RedirectIfAuthenticated>
            <LazyPage><ForgotPassword /></LazyPage>
          </RedirectIfAuthenticated>
        }
      />
      <Route
        path="/reset-password"
        element={
          <RedirectIfAuthenticated>
            <LazyPage><ResetPassword /></LazyPage>
          </RedirectIfAuthenticated>
        }
      />

      {/* Onboarding (authenticated, no store yet) */}
      <Route
        path="/onboarding"
        element={
          <ProtectedRoute>
            <LazyPage><Onboarding /></LazyPage>
          </ProtectedRoute>
        }
      />

      {/* Protected dashboard routes */}
      <Route
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<LazyPage><Overview /></LazyPage>} />
        <Route path="/dashboard/stores" element={<LazyPage><Stores /></LazyPage>} />
        <Route path="/dashboard/scans" element={<LazyPage><Scans /></LazyPage>} />
        <Route path="/dashboard/issues" element={<LazyPage><Issues /></LazyPage>} />
        <Route path="/dashboard/reports" element={<LazyPage><Reports /></LazyPage>} />
        <Route path="/dashboard/notifications" element={<LazyPage><Notifications /></LazyPage>} />
        <Route path="/dashboard/billing" element={<LazyPage><Billing /></LazyPage>} />
        <Route path="/dashboard/settings" element={<LazyPage><Settings /></LazyPage>} />
      </Route>

      {/* Catch all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
