import { useState } from "react";
import {
  User,
  Lock,
  Bell,
  Monitor,
  Save,
  CheckCircle2,
  Shield,
  Smartphone,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

// ============================================================================
// Feedback Toast
// ============================================================================

function SaveFeedback({
  success,
  message,
}: {
   success: boolean;
  message: string;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-lg px-3 py-2 text-sm",
        success
          ? "bg-[#22c55e]/10 text-[#22c55e]"
          : "bg-[#ef4444]/10 text-[#ef4444]",
      )}
    >
      {success ? (
        <CheckCircle2 className="h-4 w-4" />
      ) : (
        <span className="font-medium">!</span>
      )}
      {message}
    </div>
  );
}

// ============================================================================
// Profile Tab
// ============================================================================

function ProfileTab() {
  const { profile, updateProfile } = useAuth();
  const [name, setName] = useState(profile?.fullName ?? "");
  const [feedback, setFeedback] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  const handleSave = async () => {
    const { error } = await updateProfile({ fullName: name });
    if (error) {
      setFeedback({ success: false, message: error });
    } else {
      setFeedback({ success: true, message: "Profile updated successfully." });
    }
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-[#8888a0]" />
            Profile Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="settings-name">Name</Label>
            <Input
              id="settings-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="settings-email">Email</Label>
            <Input
              id="settings-email"
              value={profile?.email ?? ""}
              disabled
              className="opacity-50"
            />
            <p className="text-xs text-[#55556a]">
              Email cannot be changed. Contact support if needed.
            </p>
          </div>
          {feedback && <SaveFeedback {...feedback} />}
          <Button onClick={handleSave} className="gap-2">
            <Save className="h-4 w-4" />
            Save Changes
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================================
// Security Tab
// ============================================================================

function SecurityTab() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [feedback, setFeedback] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  const handleChangePassword = () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      setFeedback({
        success: false,
        message: "All password fields are required.",
      });
      setTimeout(() => setFeedback(null), 3000);
      return;
    }
    if (newPassword !== confirmPassword) {
      setFeedback({
        success: false,
        message: "New passwords do not match.",
      });
      setTimeout(() => setFeedback(null), 3000);
      return;
    }
    if (newPassword.length < 8) {
      setFeedback({
        success: false,
        message: "Password must be at least 8 characters.",
      });
      setTimeout(() => setFeedback(null), 3000);
      return;
    }
    // In demo mode, just show success
    setFeedback({
      success: true,
      message: "Password updated successfully.",
    });
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Change Password */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-[#8888a0]" />
            Change Password
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="current-password">Current Password</Label>
            <Input
              id="current-password"
              type="password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Enter current password"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="new-password">New Password</Label>
            <Input
              id="new-password"
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Enter new password"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirm-password">Confirm New Password</Label>
            <Input
              id="confirm-password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm new password"
            />
          </div>
          {feedback && <SaveFeedback {...feedback} />}
          <Button onClick={handleChangePassword} className="gap-2">
            <Save className="h-4 w-4" />
            Update Password
          </Button>
        </CardContent>
      </Card>

      {/* Two-Factor Auth */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-[#8888a0]" />
            Two-Factor Authentication
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-4">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Enable 2FA
              </p>
              <p className="text-xs text-[#55556a]">
                Add an extra layer of security to your account.
              </p>
            </div>
            <Badge variant="secondary">Coming Soon</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Active Sessions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5 text-[#8888a0]" />
            Active Sessions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#6366f1]/10">
                  <Smartphone className="h-4 w-4 text-[#6366f1]" />
                </div>
                <div>
                  <p className="text-sm font-medium text-[#f0f0f5]">
                    Current Session
                  </p>
                  <p className="text-xs text-[#55556a]">
                    Chrome on macOS - Active now
                  </p>
                </div>
              </div>
              <Badge variant="success">Active</Badge>
            </div>
          </div>
          <p className="mt-3 text-xs text-[#55556a]">
            Session management is available in production mode.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================================
// Notifications Tab
// ============================================================================

function NotificationsTab() {
  const { profile } = useAuth();
  const [dailyReports, setDailyReports] = useState(true);
  const [criticalAlerts, setCriticalAlerts] = useState(true);
  const [weeklySummaries, setWeeklySummaries] = useState(false);
  const [reportEmail, setReportEmail] = useState(profile?.email ?? "");
  const [feedback, setFeedback] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  const handleSave = () => {
    setFeedback({
      success: true,
      message: "Notification preferences saved.",
    });
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-[#8888a0]" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Daily Reports
              </p>
              <p className="text-xs text-[#55556a]">
                Receive a daily email summary of your store health.
              </p>
            </div>
            <Switch
              checked={dailyReports}
              onCheckedChange={setDailyReports}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Critical Issue Alerts
              </p>
              <p className="text-xs text-[#55556a]">
                Get notified immediately when critical issues are found.
              </p>
            </div>
            <Switch
              checked={criticalAlerts}
              onCheckedChange={setCriticalAlerts}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Weekly Summaries
              </p>
              <p className="text-xs text-[#55556a]">
                Get a weekly digest of your store health trends.
              </p>
            </div>
            <Switch
              checked={weeklySummaries}
              onCheckedChange={setWeeklySummaries}
            />
          </div>
          <Separator />
          <div className="space-y-2">
            <Label htmlFor="report-email">
              Email Address for Reports
            </Label>
            <Input
              id="report-email"
              type="email"
              value={reportEmail}
              onChange={(e) => setReportEmail(e.target.value)}
              placeholder="reports@example.com"
            />
          </div>
          {feedback && <SaveFeedback {...feedback} />}
          <Button onClick={handleSave} className="gap-2">
            <Save className="h-4 w-4" />
            Save Preferences
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================================
// Monitoring Tab
// ============================================================================

function MonitoringTab() {
  const [frequency, setFrequency] = useState("daily");
  const [seoChecks, setSeoChecks] = useState(true);
  const [technicalChecks, setTechnicalChecks] = useState(true);
  const [productChecks, setProductChecks] = useState(true);
  const [performanceChecks, setPerformanceChecks] = useState(true);
  const [feedback, setFeedback] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  const handleSave = () => {
    setFeedback({
      success: true,
      message: "Monitoring settings saved.",
    });
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Monitor className="h-5 w-5 text-[#8888a0]" />
            Monitoring Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Scan Frequency</Label>
            <Select value={frequency} onValueChange={setFrequency}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="12h">Every 12 hours</SelectItem>
                <SelectItem value="6h">Every 6 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Include SEO Checks
              </p>
              <p className="text-xs text-[#55556a]">
                Meta tags, headings, Open Graph, structured data.
              </p>
            </div>
            <Switch checked={seoChecks} onCheckedChange={setSeoChecks} />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Include Technical Checks
              </p>
              <p className="text-xs text-[#55556a]">
                SSL, security headers, TLS, CSP, HSTS.
              </p>
            </div>
            <Switch
              checked={technicalChecks}
              onCheckedChange={setTechnicalChecks}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Include Product Checks
              </p>
              <p className="text-xs text-[#55556a]">
                Broken links, product pages, image optimization.
              </p>
            </div>
            <Switch
              checked={productChecks}
              onCheckedChange={setProductChecks}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#f0f0f5]">
                Include Performance Checks
              </p>
              <p className="text-xs text-[#55556a]">
                Page speed, LCP, CLS, page size, caching.
              </p>
            </div>
            <Switch
              checked={performanceChecks}
              onCheckedChange={setPerformanceChecks}
            />
          </div>
          {feedback && <SaveFeedback {...feedback} />}
          <Button onClick={handleSave} className="gap-2">
            <Save className="h-4 w-4" />
            Save Monitoring Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Settings() {
  return (
    <div className="mx-auto max-w-3xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      <div>
        <h1 className="text-2xl font-bold text-[#f0f0f5]">Settings</h1>
        <p className="text-sm text-[#8888a0]">
          Manage your account and application preferences
        </p>
      </div>

      <Tabs defaultValue="profile">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="profile" className="flex-1 gap-1.5 sm:flex-auto">
            <User className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Profile</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex-1 gap-1.5 sm:flex-auto">
            <Lock className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex-1 gap-1.5 sm:flex-auto">
            <Bell className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="monitoring" className="flex-1 gap-1.5 sm:flex-auto">
            <Monitor className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Monitoring</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <ProfileTab />
        </TabsContent>
        <TabsContent value="security">
          <SecurityTab />
        </TabsContent>
        <TabsContent value="notifications">
          <NotificationsTab />
        </TabsContent>
        <TabsContent value="monitoring">
          <MonitoringTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
