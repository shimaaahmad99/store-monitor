import { useState, useCallback } from "react";
import { Link } from "react-router-dom";
import {
  Plus,
  Store as StoreIcon,
  Trash2,
  Play,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { ProgressRing } from "@/components/ui/progress-ring";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";

import { useStores } from "@/hooks/useStores";
import { useIssues } from "@/hooks/useIssues";
import { useScans } from "@/hooks/useScans";
import { cn, formatDate } from "@/lib/utils";
import type { Store, StorePlatform } from "@/types";

// ============================================================================
// Constants
// ============================================================================

const PLATFORM_LABELS: Record<StorePlatform, string> = {
  shopify: "Shopify",
  woocommerce: "WooCommerce",
  magento: "Magento",
  bigcommerce: "BigCommerce",
  squarespace: "Squarespace",
  wix: "Wix",
  custom: "Custom",
};

function extractDomain(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}

// ============================================================================
// Sub-components
// ============================================================================

function StoresSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-8 w-32" />
        <Skeleton className="h-10 w-32 rounded-lg" />
      </div>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-[280px] w-full rounded-xl" />
        ))}
      </div>
    </div>
  );
}

function StoreCard({
  store,
  issueCounts,
  onScan,
  onDelete,
}: {
  store: Store;
  issueCounts: { critical: number; warnings: number };
  onScan: () => void;
  onDelete: () => void;
}) {
  return (
    <Card hover className="flex flex-col">
      <CardContent className="flex flex-1 flex-col p-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="truncate text-base font-semibold text-[#f0f0f5]">
                {store.name}
              </h3>
              <Badge variant={store.isActive ? "success" : "secondary"} dot>
                {store.isActive ? "Active" : "Inactive"}
              </Badge>
            </div>
            <p className="mt-0.5 truncate font-mono text-xs text-[#55556a]">
              {extractDomain(store.url)}
            </p>
          </div>
          <Badge variant="secondary">
            {PLATFORM_LABELS[store.platform]}
          </Badge>
        </div>

        {/* Health Score + Issue Counts */}
        <div className="mt-5 flex items-center gap-5">
          <div className="flex flex-col items-center">
            <ProgressRing
              value={store.healthScore ?? 0}
              size={72}
              strokeWidth={6}
            />
          </div>
          <div className="flex-1 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#8888a0]">Critical</span>
              <span
                className={cn(
                  "font-semibold",
                  issueCounts.critical > 0 ? "text-[#ef4444]" : "text-[#22c55e]",
                )}
              >
                {issueCounts.critical}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#8888a0]">Warnings</span>
              <span
                className={cn(
                  "font-semibold",
                  issueCounts.warnings > 0 ? "text-[#eab308]" : "text-[#22c55e]",
                )}
              >
                {issueCounts.warnings}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#8888a0]">Last Scan</span>
              <span className="text-[#8888a0]">
                {store.lastScanAt
                  ? formatDate(store.lastScanAt, {
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })
                  : "Never"}
              </span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-5 flex items-center gap-2 border-t border-[#1e1e2e] pt-4">
          <Link to={`/dashboard/scans?store=${store.id}`} className="flex-1">
            <Button variant="outline" size="sm" className="w-full">
              View Details
            </Button>
          </Link>
          <Button
            variant="default"
            size="sm"
            onClick={onScan}
            className="flex-1"
          >
            <Play className="h-3.5 w-3.5" />
            Scan Now
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={onDelete}
            className="h-8 w-8 text-[#55556a] hover:text-[#ef4444]"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Stores() {
  const { stores, loading, createStore, deleteStore } = useStores();
  const { issues: allIssues } = useIssues();
  const { triggerScan } = useScans();

  const [showAddDialog, setShowAddDialog] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Store | null>(null);
  const [newStoreName, setNewStoreName] = useState("");
  const [newStoreUrl, setNewStoreUrl] = useState("");
  const [newStorePlatform, setNewStorePlatform] =
    useState<StorePlatform>("shopify");


  // -----------------------------------------------------------------------
  // Issue counts per store
  // -----------------------------------------------------------------------
  const issueCountsMap = allIssues.reduce<
    Record<string, { critical: number; warnings: number }>
  >((acc, issue) => {
    if (issue.status === "resolved" || issue.status === "dismissed") return acc;
    if (!acc[issue.storeId]) acc[issue.storeId] = { critical: 0, warnings: 0 };
    if (issue.severity === "critical") acc[issue.storeId]!.critical++;
    if (issue.severity === "warning") acc[issue.storeId]!.warnings++;
    return acc;
  }, {});

  // -----------------------------------------------------------------------
  // Handlers
  // -----------------------------------------------------------------------
  const handleAddStore = useCallback(async () => {
    if (!newStoreName.trim() || !newStoreUrl.trim()) return;
    let url = newStoreUrl.trim();
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = `https://${url}`;
    }
    await createStore({
      name: newStoreName.trim(),
      url,
      platform: newStorePlatform,
    });
    setNewStoreName("");
    setNewStoreUrl("");
    setShowAddDialog(false);
  }, [newStoreName, newStoreUrl, newStorePlatform, createStore]);

  const handleDeleteStore = useCallback(async () => {
    if (!deleteTarget) return;
    await deleteStore(deleteTarget.id);
    setDeleteTarget(null);
  }, [deleteTarget, deleteStore]);

  const handleScan = useCallback(
    async (store: Store) => {
      await triggerScan(store.url);
    },
    [triggerScan],
  );

  // -----------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------
  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <StoresSkeleton />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#f0f0f5]">Stores</h1>
          <p className="text-sm text-[#8888a0]">
            Manage and monitor your connected stores
          </p>
        </div>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4" />
          Add Store
        </Button>
      </div>

      {/* Store Grid */}
      {stores.length === 0 ? (
        <EmptyState
          icon={StoreIcon}
          title="Add your first store"
          description="Connect your online store to start monitoring its health, security, performance, and more."
          action={
            <Button onClick={() => setShowAddDialog(true)}>
              <Plus className="h-4 w-4" />
              Add Store
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {stores.map((store) => (
            <StoreCard
              key={store.id}
              store={store}
              issueCounts={
                issueCountsMap[store.id] ?? { critical: 0, warnings: 0 }
              }
              onScan={() => handleScan(store)}
              onDelete={() => setDeleteTarget(store)}
            />
          ))}
        </div>
      )}

      {/* Add Store Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Store</DialogTitle>
            <DialogDescription>
              Enter your store details to start monitoring.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-[#f0f0f5]">
                Store Name
              </label>
              <Input
                placeholder="My Store"
                value={newStoreName}
                onChange={(e) => setNewStoreName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-[#f0f0f5]">
                Store URL
              </label>
              <Input
                placeholder="https://mystore.com"
                value={newStoreUrl}
                onChange={(e) => setNewStoreUrl(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-[#f0f0f5]">
                Platform
              </label>
              <Select
                value={newStorePlatform}
                onValueChange={(v) => setNewStorePlatform(v as StorePlatform)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PLATFORM_LABELS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowAddDialog(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddStore}
              disabled={!newStoreName.trim() || !newStoreUrl.trim()}
            >
              Add Store
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteTarget !== null}
        onOpenChange={() => setDeleteTarget(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Store</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{" "}
              <span className="font-medium text-[#f0f0f5]">
                {deleteTarget?.name}
              </span>
              ? This action cannot be undone. All scan history and issues for
              this store will be permanently removed.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteTarget(null)}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteStore}>
              Delete Store
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
