import { useState, useEffect, useMemo, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import {
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { ProgressRing } from "@/components/ui/progress-ring";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { useStores } from "@/hooks/useStores";
import { useScans } from "@/hooks/useScans";
import { cn, formatDate, getScoreColor } from "@/lib/utils";
import type { Scan, ScanCheck, ScanCheckCategory } from "@/types";

// ============================================================================
// Helpers
// ============================================================================

function formatDuration(start: Date | null, end: Date | null): string {
  if (!start || !end) return "-";
  const ms = end.getTime() - start.getTime();
  if (ms < 1000) return `${ms}ms`;
  const sec = Math.floor(ms / 1000);
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  return `${min}m ${sec % 60}s`;
}

function getStatusBadge(status: string) {
  switch (status) {
    case "completed":
      return "success" as const;
    case "failed":
      return "destructive" as const;
    case "running":
      return "info" as const;
    default:
      return "warning" as const;
  }
}

function getCheckStatusIcon(status: string) {
  switch (status) {
    case "passed":
      return <CheckCircle2 className="h-4 w-4 text-[#22c55e]" />;
    case "failed":
      return <XCircle className="h-4 w-4 text-[#ef4444]" />;
    case "warning":
      return <AlertTriangle className="h-4 w-4 text-[#eab308]" />;
    default:
      return <Clock className="h-4 w-4 text-[#55556a]" />;
  }
}

const CATEGORY_LABELS: Record<ScanCheckCategory, string> = {
  security: "Security",
  performance: "Performance",
  seo: "SEO",
  accessibility: "Accessibility",
  mobile: "Mobile",
  content: "Content",
  analytics: "Analytics",
  ssl: "SSL",
};

// ============================================================================
// Sub-components
// ============================================================================

function ScansSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-8 w-32" />
      </div>
      <div className="flex gap-3">
        <Skeleton className="h-10 w-48 rounded-lg" />
        <Skeleton className="h-10 w-36 rounded-lg" />
      </div>
      {[...Array(5)].map((_, i) => (
        <Skeleton key={i} className="h-16 w-full rounded-xl" />
      ))}
    </div>
  );
}

function ScanListItem({
  scan,
  storeName,
  selected,
  onClick,
}: {
  scan: Scan;
  storeName?: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "flex cursor-pointer items-center justify-between rounded-xl border p-4 transition-colors",
        selected
          ? "border-[#6366f1] bg-[#6366f1]/5"
          : "border-[#1e1e2e] bg-[#111118] hover:border-[#2a2a3e] hover:bg-[#15151f]",
      )}
    >
      <div className="flex items-center gap-4">
        {selected ? (
          <ChevronDown className="h-4 w-4 text-[#6366f1]" />
        ) : (
          <ChevronRight className="h-4 w-4 text-[#55556a]" />
        )}
        <div>
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium text-[#f0f0f5]">
              {storeName ?? "Unknown Store"}
            </p>
            <Badge variant={getStatusBadge(scan.status)}>
              {scan.status}
            </Badge>
          </div>
          <p className="mt-0.5 text-xs text-[#55556a]">
            {formatDate(scan.createdAt, {
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}{" "}
            &middot; Duration: {formatDuration(scan.startedAt, scan.completedAt)}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="hidden items-center gap-3 text-xs text-[#8888a0] sm:flex">
          <span>
            {scan.passedChecks}/{scan.totalChecks} passed
          </span>
          <span className="text-[#ef4444]">{scan.failedChecks} failed</span>
          <span className="text-[#eab308]">{scan.warningChecks} warn</span>
        </div>
        {scan.healthScore !== null && (
          <span
            className={cn("text-lg font-bold", getScoreColor(scan.healthScore))}
          >
            {scan.healthScore}
          </span>
        )}
      </div>
    </div>
  );
}

function ScanDetailPanel({
  scan,
  checks,
  storeName,
}: {
  scan: Scan;
  checks: ScanCheck[];
  storeName?: string;
}) {
  const grouped = useMemo(() => {
    const map = new Map<ScanCheckCategory, ScanCheck[]>();
    for (const check of checks) {
      const list = map.get(check.category) ?? [];
      list.push(check);
      map.set(check.category, list);
    }
    return map;
  }, [checks]);

  return (
    <Card className="mt-4">
      <CardContent className="p-6">
        <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center">
          <ProgressRing
            value={scan.healthScore ?? 0}
            size={100}
            strokeWidth={7}
          />
          <div className="flex-1">
            <h3 className="text-base font-semibold text-[#f0f0f5]">
              {storeName ?? "Scan Details"}
            </h3>
            <p className="mt-0.5 text-sm text-[#8888a0]">
              {formatDate(scan.createdAt, {
                month: "long",
                day: "numeric",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })}
            </p>
            <div className="mt-3 flex flex-wrap gap-4 text-sm">
              <span className="text-[#8888a0]">
                Duration: {formatDuration(scan.startedAt, scan.completedAt)}
              </span>
              <span className="text-[#22c55e]">
                {scan.passedChecks} passed
              </span>
              <span className="text-[#ef4444]">
                {scan.failedChecks} failed
              </span>
              <span className="text-[#eab308]">
                {scan.warningChecks} warnings
              </span>
            </div>
          </div>
        </div>

        {scan.errorMessage && (
          <div className="mt-4 rounded-lg border border-[#ef4444]/30 bg-[#ef4444]/5 p-4">
            <p className="text-sm font-medium text-[#ef4444]">Scan Failed</p>
            <p className="mt-1 text-xs text-[#8888a0]">{scan.errorMessage}</p>
          </div>
        )}

        {checks.length > 0 && (
          <div className="mt-6 space-y-6">
            {Array.from(grouped.entries()).map(([category, categoryChecks]) => {
              const passed = categoryChecks.filter(
                (c) => c.status === "passed",
              ).length;
              return (
                <div key={category}>
                  <div className="mb-3 flex items-center justify-between">
                    <h4 className="text-sm font-semibold text-[#f0f0f5]">
                      {CATEGORY_LABELS[category]}
                    </h4>
                    <span className="text-xs text-[#8888a0]">
                      {passed}/{categoryChecks.length} passed
                    </span>
                  </div>
                  <div className="space-y-2">
                    {categoryChecks.map((check) => (
                      <div
                        key={check.id}
                        className="flex items-start gap-3 rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-3"
                      >
                        <div className="mt-0.5">{getCheckStatusIcon(check.status)}</div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-[#f0f0f5]">{check.name}</p>
                          <p className="mt-0.5 text-xs text-[#8888a0]">{check.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Scans() {
  const [searchParams] = useSearchParams();
  const { stores } = useStores();
  const {
    scans,
    currentScan: checks,
    loading,
    fetchScanById,
  } = useScans();

  const [selectedScanId, setSelectedScanId] = useState<string | null>(
    searchParams.get("id"),
  );
  const [filterStore, setFilterStore] = useState<string>(
    searchParams.get("store") ?? "all",
  );
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [visibleCount, setVisibleCount] = useState(10);

  const storeMap = useMemo(() => {
    const map = new Map<string, string>();
    for (const s of stores) map.set(s.id, s.name);
    return map;
  }, [stores]);

  useEffect(() => {
    const id = searchParams.get("id");
    if (id) {
      setSelectedScanId(id);
      fetchScanById(id);
    }
  }, [searchParams, fetchScanById]);

  const handleSelectScan = useCallback(
    (scanId: string) => {
      setSelectedScanId((prev) => (prev === scanId ? null : scanId));
      if (selectedScanId !== scanId) {
        fetchScanById(scanId);
      }
    },
    [selectedScanId, fetchScanById],
  );

  const filteredScans = useMemo(() => {
    let result = [...scans].sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );
    if (filterStore !== "all") {
      result = result.filter((s) => s.storeId === filterStore);
    }
    if (filterStatus !== "all") {
      result = result.filter((s) => s.status === filterStatus);
    }
    return result;
  }, [scans, filterStore, filterStatus]);

  const visibleScans = filteredScans.slice(0, visibleCount);
  const hasMore = visibleCount < filteredScans.length;

  // -----------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------
  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <ScansSkeleton />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      <div>
        <h1 className="text-2xl font-bold text-[#f0f0f5]">Scan History</h1>
        <p className="text-sm text-[#8888a0]">View and analyze all past scans</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <Select value={filterStore} onValueChange={setFilterStore}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="All Stores" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stores</SelectItem>
            {stores.map((s) => (
              <SelectItem key={s.id} value={s.id}>
                {s.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-40">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="running">Running</SelectItem>
            <SelectItem value="queued">Queued</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredScans.length === 0 ? (
        <EmptyState
          icon={Clock}
          title="No scans found"
          description={
            filterStore !== "all" || filterStatus !== "all"
              ? "No scans match the selected filters. Try adjusting your filter criteria."
              : 'No scans have been run yet. Go to your store and click Scan Now to get started.'
          }
        />
      ) : (
        <div className="space-y-2">
          {visibleScans.map((scan) => (
            <div key={scan.id}>
              <ScanListItem
                scan={scan}
                storeName={storeMap.get(scan.storeId)}
                selected={selectedScanId === scan.id}
                onClick={() => handleSelectScan(scan.id)}
              />
              {selectedScanId === scan.id && (
                <ScanDetailPanel
                  scan={scan}
                  checks={checks}
                  storeName={storeMap.get(scan.storeId)}
                />
              )}
            </div>
          ))}

          {hasMore && (
            <div className="pt-2 text-center">
              <Button
                variant="outline"
                onClick={() => setVisibleCount((prev) => prev + 10)}
              >
                Load More ({filteredScans.length - visibleCount} remaining)
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
