import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  FileText,
  Download,
  Calendar,
  ChevronDown,
  ChevronRight,
  ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ProgressRing } from "@/components/ui/progress-ring";
import { useStores } from "@/hooks/useStores";
import { useScans } from "@/hooks/useScans";
import { useIssues } from "@/hooks/useIssues";
import { cn, getScoreGrade, formatRelativeTime } from "@/lib/utils";
import type { CategorySummary } from "@/types";
import { demoChecks } from "@/data/demo";

// ============================================================================
// Helpers
// ============================================================================

function getSeverityDotColor(severity: string): string {
  switch (severity) {
    case "critical":
      return "bg-[#ef4444]";
    case "warning":
      return "bg-[#eab308]";
    default:
      return "bg-[#22c55e]";
  }
}

function getStatusInfo(
  score: number,
): { label: string; variant: "success" | "warning" | "destructive" } {
  if (score >= 75) return { label: "Good", variant: "success" };
  if (score >= 50) return { label: "Needs Attention", variant: "warning" };
  return { label: "Critical", variant: "destructive" };
}

function getPriorityVariant(
  priority: string,
): "destructive" | "warning" | "info" {
  if (priority === "high") return "destructive";
  if (priority === "medium") return "warning";
  return "info";
}

const CATEGORY_LABELS: Record<string, string> = {
  security: "Security",
  performance: "Performance",
  seo: "SEO",
  ssl: "SSL",
  mobile: "Mobile",
  accessibility: "Accessibility",
  content: "Content",
  analytics: "Analytics",
};

// ============================================================================
// Report Skeleton
// ============================================================================

function ReportSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-4 w-72" />
      </div>
      <Skeleton className="h-[200px] w-full rounded-xl" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-[80px] w-full rounded-xl" />
        ))}
      </div>
      <Skeleton className="h-[300px] w-full rounded-xl" />
    </div>
  );
}

// ============================================================================
// Category Bar
// ============================================================================

function CategoryBar({
  category,
  summary,
}: {
  category: string;
  summary: CategorySummary;
}) {
  if (summary.total === 0) return null;
  return (
    <div className="rounded-lg border border-[#1e1e2e] bg-[#0d0d14] px-4 py-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-sm font-medium text-[#f0f0f5]">
          {CATEGORY_LABELS[category] ?? category}
        </span>
        <span className="text-xs text-[#55556a]">
          {summary.passed}/{summary.total} passed
        </span>
      </div>
      <div className="flex h-2 overflow-hidden rounded-full bg-[#1e1e2e]">
        <div
          className="bg-[#22c55e] transition-all duration-500"
          style={{ width: `${(summary.passed / summary.total) * 100}%` }}
        />
        <div
          className="bg-[#eab308] transition-all duration-500"
          style={{ width: `${(summary.warnings / summary.total) * 100}%` }}
        />
        <div
          className="bg-[#ef4444] transition-all duration-500"
          style={{ width: `${(summary.failed / summary.total) * 100}%` }}
        />
      </div>
      <div className="mt-2 flex gap-4 text-xs text-[#55556a]">
        <span className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-[#22c55e]" />
          Passed: {summary.passed}
        </span>
        <span className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-[#eab308]" />
          Warnings: {summary.warnings}
        </span>
        <span className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-[#ef4444]" />
          Failed: {summary.failed}
        </span>
      </div>
    </div>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Reports() {
  const { stores, loading: storesLoading } = useStores();
  const { scans, loading: scansLoading } = useScans();
  const { issues: allIssues, loading: issuesLoading } = useIssues();

  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split("T")[0]!,
  );
  const [expandedRec, setExpandedRec] = useState<number | null>(null);

  const loading = storesLoading || scansLoading || issuesLoading;

  // -----------------------------------------------------------------------
  // Derive report data from latest scan + issues
  // -----------------------------------------------------------------------

  const reportData = useMemo(() => {
    if (stores.length === 0) return null;

    const primaryStore = stores[0]!;
    const latestScan = scans
      .filter((s) => s.storeId === primaryStore.id && s.status === "completed")
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];

    if (!latestScan) return null;

    const score = latestScan.healthScore ?? 0;
    const status = getStatusInfo(score);

    const storeIssues = allIssues
      .filter(
        (i) =>
          i.storeId === primaryStore.id &&
          (i.status === "open" || i.status === "in_progress"),
      )
      .sort((a, b) => {
        const order = { critical: 0, warning: 1, minor: 2 };
        return (order[a.severity] ?? 2) - (order[b.severity] ?? 2);
      });

    const criticalCount = storeIssues.filter((i) => i.severity === "critical").length;
    const warningCount = storeIssues.filter((i) => i.severity === "warning").length;
    const passedCount = latestScan.passedChecks;

    const topProblems = storeIssues.slice(0, 5);

    const recommendations = storeIssues
      .filter((i) => i.recommendation)
      .slice(0, 5)
      .map((i, idx) => ({
        number: idx + 1,
        title: i.recommendation!,
        priority:
          i.severity === "critical"
            ? "high"
            : i.severity === "warning"
              ? "medium"
              : "low",
        fullExplanation: i.description,
      }));

    while (recommendations.length < 5) {
      recommendations.push({
        number: recommendations.length + 1,
        title: "Continue monitoring your store for new issues.",
        priority: "low",
        fullExplanation:
          "Regular scans help catch issues early before they impact customers.",
      });
    }

    const scanChecks = demoChecks.filter((c) => c.scanId === latestScan.id);
    const categorySummary: Record<string, CategorySummary> =
      scanChecks.length > 0
        ? (() => {
            const map: Record<string, CategorySummary> = {};
            for (const check of scanChecks) {
              if (!map[check.category]) {
                map[check.category] = {
                  total: 0,
                  passed: 0,
                  warnings: 0,
                  failed: 0,
                };
              }
              const cs = map[check.category]!;
              cs.total++;
              if (check.status === "passed") cs.passed++;
              else if (check.status === "warning") cs.warnings++;
              else if (check.status === "failed") cs.failed++;
            }
            return map;
          })()
        : {
            security: { total: 3, passed: 1, warnings: 1, failed: 1 },
            performance: { total: 3, passed: 1, warnings: 1, failed: 1 },
            seo: { total: 3, passed: 2, warnings: 1, failed: 0 },
            ssl: { total: 2, passed: 2, warnings: 0, failed: 0 },
            mobile: { total: 2, passed: 1, warnings: 1, failed: 0 },
            accessibility: { total: 2, passed: 1, warnings: 1, failed: 0 },
            content: { total: 2, passed: 1, warnings: 1, failed: 0 },
            analytics: { total: 1, passed: 1, warnings: 0, failed: 0 },
          };

    return {
      store: primaryStore,
      scan: latestScan,
      score,
      status,
      criticalCount,
      warningCount,
      passedCount,
      topProblems,
      recommendations,
      categorySummary,
    };
  }, [stores, scans, allIssues]);

  // -----------------------------------------------------------------------
  // Loading
  // -----------------------------------------------------------------------
  if (loading) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <ReportSkeleton />
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // No data
  // -----------------------------------------------------------------------
  if (!reportData) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#1e1e2e]">
            <FileText className="h-6 w-6 text-[#55556a]" />
          </div>
          <h3 className="text-base font-medium text-[#f0f0f5]">
            No report data available
          </h3>
          <p className="mt-1.5 max-w-sm text-sm text-[#55556a]">
            Run a scan on your store to generate a daily report.
          </p>
          <Link to="/dashboard/scans">
            <Button className="mt-5">Run a Scan</Button>
          </Link>
        </div>
      </div>
    );
  }

  const {
    store,
    scan,
    score,
    status,
    criticalCount,
    warningCount,
    passedCount,
    topProblems,
    recommendations,
    categorySummary,
  } = reportData;

  return (
    <div className="mx-auto max-w-4xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#f0f0f5]">Daily Report</h1>
          <p className="text-sm text-[#8888a0]">
            Comprehensive health analysis for your store
          </p>
        </div>
        <div className="relative">
          <Calendar className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#55556a]" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="h-10 rounded-lg border border-[#1e1e2e] bg-[#0d0d14] pl-10 pr-3 text-sm text-[#f0f0f5] shadow-sm focus:outline-none focus:ring-2 focus:ring-[#6366f1] focus:ring-offset-2 focus:ring-offset-[#0a0a0f]"
          />
        </div>
      </div>

      {/* Main Report Card */}
      <Card>
        <CardContent className="space-y-8 p-6">
          {/* Store Info */}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-lg font-semibold text-[#f0f0f5]">
                {store.name}
              </h2>
              <a
                href={store.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-[#6366f1] hover:text-[#818cf8]"
              >
                {store.url}
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
            <p className="text-xs text-[#55556a]">
              Last scanned{" "}
              {formatRelativeTime(scan.completedAt ?? scan.createdAt)}
            </p>
          </div>

          {/* Health Score + Status */}
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start sm:gap-8">
            <div className="flex flex-col items-center">
              <ProgressRing value={score} size={140} strokeWidth={10} />
              <div className="mt-2 flex items-center gap-2">
                <span className="text-sm font-bold text-[#f0f0f5]">
                  Grade: {getScoreGrade(score)}
                </span>
                <Badge variant={status.variant}>{status.label}</Badge>
              </div>
            </div>

            {/* Issue Summary Row */}
            <div className="grid flex-1 grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-4 text-center">
                <p className="text-2xl font-bold text-[#ef4444]">
                  {criticalCount}
                </p>
                <p className="text-xs text-[#8888a0]">Critical</p>
              </div>
              <div className="rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-4 text-center">
                <p className="text-2xl font-bold text-[#eab308]">
                  {warningCount}
                </p>
                <p className="text-xs text-[#8888a0]">Warnings</p>
              </div>
              <div className="rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-4 text-center">
                <p className="text-2xl font-bold text-[#22c55e]">
                  {passedCount}
                </p>
                <p className="text-xs text-[#8888a0]">Passed</p>
              </div>
            </div>
          </div>

          {/* Top Problems */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-[#8888a0]">
              Top Problems
            </h3>
            {topProblems.length === 0 ? (
              <p className="text-sm text-[#55556a]">
                No problems found. Your store is in great shape!
              </p>
            ) : (
              <div className="space-y-2">
                {topProblems.map((issue, idx) => (
                  <div
                    key={issue.id}
                    className="flex items-start gap-3 rounded-lg border border-[#1e1e2e] bg-[#0d0d14] px-4 py-3"
                  >
                    <span className="mt-0.5 text-xs font-bold text-[#55556a]">
                      {idx + 1}
                    </span>
                    <span
                      className={cn(
                        "mt-1.5 h-2 w-2 shrink-0 rounded-full",
                        getSeverityDotColor(issue.severity),
                      )}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-[#f0f0f5]">
                        {issue.title}
                      </p>
                      <div className="mt-1 flex items-center gap-2">
                        <Badge variant="secondary" className="text-[10px]">
                          {issue.category}
                        </Badge>
                        <a
                          href={store.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-0.5 text-xs text-[#55556a] hover:text-[#6366f1]"
                        >
                          {store.url}
                          <ExternalLink className="h-2.5 w-2.5" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recommendations */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-[#8888a0]">
              Recommendations
            </h3>
            <div className="space-y-2">
              {recommendations.map((rec) => (
                <div
                  key={rec.number}
                  className="rounded-lg border border-[#1e1e2e] bg-[#0d0d14]"
                >
                  <button
                    type="button"
                    onClick={() =>
                      setExpandedRec(
                        expandedRec === rec.number ? null : rec.number,
                      )
                    }
                    className="flex w-full items-center gap-3 px-4 py-3 text-left"
                  >
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#6366f1]/10 text-xs font-bold text-[#6366f1]">
                      {rec.number}
                    </span>
                    <p className="flex-1 text-sm text-[#f0f0f5]">
                      {rec.title}
                    </p>
                    <Badge
                      variant={getPriorityVariant(rec.priority)}
                      className="text-[10px]"
                    >
                      {rec.priority}
                    </Badge>
                    {expandedRec === rec.number ? (
                      <ChevronDown className="h-4 w-4 shrink-0 text-[#55556a]" />
                    ) : (
                      <ChevronRight className="h-4 w-4 shrink-0 text-[#55556a]" />
                    )}
                  </button>
                  {expandedRec === rec.number && (
                    <div className="border-t border-[#1e1e2e] px-4 py-3">
                      <p className="text-sm leading-relaxed text-[#8888a0]">
                        {rec.fullExplanation}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Scan Details - Category Breakdown */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-[#8888a0]">
              Scan Details
            </h3>
            <div className="space-y-3">
              {Object.entries(categorySummary).map(([cat, summary]) => (
                <CategoryBar
                  key={cat}
                  category={cat}
                  summary={summary}
                />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <Link to="/dashboard/scans">
          <Button variant="outline">View Full Report</Button>
        </Link>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Export Report
        </Button>
      </div>
    </div>
  );
}
