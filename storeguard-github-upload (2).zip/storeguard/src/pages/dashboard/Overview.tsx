import { useMemo } from "react";
import { Link } from "react-router-dom";
import {
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRight,
  Shield,
  Zap,
  Globe,
  Smartphone,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { ProgressRing } from "@/components/ui/progress-ring";
import { useAuth } from "@/context/AuthContext";
import { useStores } from "@/hooks/useStores";
import { useScans } from "@/hooks/useScans";
import { useIssues } from "@/hooks/useIssues";
import {
  cn,
  formatDate,
  getScoreColor,
  getScoreLabel,
} from "@/lib/utils";
import type { Issue, Scan } from "@/types";

// ============================================================================
// Helpers
// ============================================================================

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function getSeverityBorder(severity: string): string {
  switch (severity) {
    case "critical":
      return "border-l-[#ef4444]";
    case "warning":
      return "border-l-[#eab308]";
    default:
      return "border-l-[#3b82f6]";
  }
}

function getSeverityBadgeVariant(
  severity: string,
): "destructive" | "warning" | "info" {
  switch (severity) {
    case "critical":
      return "destructive";
    case "warning":
      return "warning";
    default:
      return "info";
  }
}

function relativeTime(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMinutes = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);
  if (diffMinutes < 1) return "just now";
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDate(date);
}

// ============================================================================
// Sub-components
// ============================================================================

function OverviewSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-4 w-72" />
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        <div className="lg:col-span-1">
          <Skeleton className="h-[220px] w-full rounded-xl" />
        </div>
        <div className="grid grid-cols-2 gap-4 lg:col-span-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-[100px] w-full rounded-xl" />
          ))}
        </div>
      </div>
      <Skeleton className="h-[400px] w-full rounded-xl" />
    </div>
  );
}

function StatCard({
  icon: Icon,
  iconBg,
  iconColor,
  value,
  label,
  trend,
  trendColor,
}: {
  icon: React.ElementType;
  iconBg: string;
  iconColor: string;
  value: number | string;
  label: string;
  trend?: string;
  trendColor?: string;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div
          className="flex h-10 w-10 items-center justify-center rounded-lg"
          style={{ backgroundColor: iconBg }}
        >
          <Icon className="h-5 w-5" style={{ color: iconColor }} />
        </div>
        {trend && (
          <span
            className={cn("text-xs font-medium", trendColor ?? "text-[#22c55e]")}
          >
            {trend}
          </span>
        )}
      </div>
      <div className="mt-3">
        <p className="text-2xl font-bold text-[#f0f0f5]">{value}</p>
        <p className="text-xs text-[#8888a0]">{label}</p>
      </div>
    </Card>
  );
}

function IssueRow({ issue }: { issue: Issue }) {
  return (
    <div
      className={cn(
        "flex items-center gap-4 border-l-2 px-4 py-3 transition-colors hover:bg-[#15151f]",
        getSeverityBorder(issue.severity),
      )}
    >
      <Badge variant={getSeverityBadgeVariant(issue.severity)} dot>
        {issue.severity === "critical"
          ? "Critical"
          : issue.severity === "warning"
            ? "Warning"
            : "Minor"}
      </Badge>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-[#f0f0f5]">
          {issue.title}
        </p>
        <p className="text-xs text-[#55556a]">
          {issue.category} &middot; {relativeTime(issue.createdAt)}
        </p>
      </div>
    </div>
  );
}

function ScanRow({
  scan,
  storeName,
}: {
  scan: Scan;
  storeName?: string;
}) {
  const score = scan.healthScore;
  return (
    <Link
      to={`/dashboard/scans?id=${scan.id}`}
      className="flex items-center justify-between border-b border-[#1e1e2e] px-4 py-3 transition-colors last:border-0 hover:bg-[#15151f]"
    >
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-[#f0f0f5]">
          {storeName ?? "Unknown Store"}
        </p>
        <p className="text-xs text-[#55556a]">{relativeTime(scan.createdAt)}</p>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <p
            className={cn(
              "text-sm font-semibold",
              score !== null ? getScoreColor(score) : "text-[#55556a]",
            )}
          >
            {score !== null ? `${score}/100` : "N/A"}
          </p>
          <p className="text-xs text-[#55556a]">
            {scan.failedChecks} issues
          </p>
        </div>
        <Badge
          variant={
            scan.status === "completed"
              ? "success"
              : scan.status === "failed"
                ? "destructive"
                : "warning"
          }
        >
          {scan.status}
        </Badge>
      </div>
    </Link>
  );
}

function RecommendationCard({
  icon: Icon,
  title,
  description,
  priority,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
}) {
  const priorityVariant =
    priority === "high"
      ? ("destructive" as const)
      : priority === "medium"
        ? ("warning" as const)
        : ("info" as const);
  return (
    <div className="flex gap-3 rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-4">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#6366f1]/10">
        <Icon className="h-4 w-4 text-[#6366f1]" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="text-sm font-medium text-[#f0f0f5]">{title}</p>
          <Badge variant={priorityVariant} className="text-[10px]">
            {priority}
          </Badge>
        </div>
        <p className="mt-1 text-xs leading-relaxed text-[#8888a0]">
          {description}
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// Custom Tooltip for Chart
// ============================================================================

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
}) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-lg border border-[#1e1e2e] bg-[#111118] px-3 py-2 shadow-lg">
      <p className="text-xs text-[#8888a0]">{label}</p>
      <p className="text-sm font-semibold text-[#f0f0f5]">
        Score: {payload[0]!.value}
      </p>
    </div>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Overview() {
  const { isDemoMode } = useAuth();
  const { stores, loading: storesLoading } = useStores();
  const { scans, loading: scansLoading } = useScans();
  const { issues: allIssues, loading: issuesLoading } = useIssues();

  const loading = storesLoading || scansLoading || issuesLoading;

  // -----------------------------------------------------------------------
  // Compute dashboard metrics
  // -----------------------------------------------------------------------
  const metrics = useMemo(() => {
    const primaryStore = stores[0];
    const healthScore = primaryStore?.healthScore ?? null;

    // Score trend: compare latest scan vs previous for primary store
    let scoreTrend: number | null = null;
    if (primaryStore) {
      const storeScans = scans
        .filter(
          (s) =>
            s.storeId === primaryStore.id &&
            s.status === "completed" &&
            s.healthScore !== null,
        )
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      if (storeScans.length >= 2) {
        scoreTrend = storeScans[0]!.healthScore! - storeScans[1]!.healthScore!;
      }
    }

    // Issue counts
    const openIssues = allIssues.filter(
      (i) => i.status === "open" || i.status === "in_progress",
    );
    const criticalCount = openIssues.filter(
      (i) => i.severity === "critical",
    ).length;
    const warningCount = openIssues.filter(
      (i) => i.severity === "warning",
    ).length;

    // Passed checks (from latest completed scan across all stores)
    const latestCompletedScan = scans
      .filter((s) => s.status === "completed")
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];
    const passedChecks = latestCompletedScan?.passedChecks ?? 0;

    // Last scan time
    const lastScanTime = latestCompletedScan?.completedAt ?? null;

    // Top priority issues
    const priorityIssues = openIssues
      .sort((a, b) => {
        const order = { critical: 0, warning: 1, minor: 2 };
        return (order[a.severity] ?? 2) - (order[b.severity] ?? 2);
      })
      .slice(0, 5);

    // Recent scans (latest 5)
    const recentScans = scans
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, 5);

    // Build a store-name lookup
    const storeMap = new Map<string, string>();
    for (const s of stores) storeMap.set(s.id, s.name);

    // Health trend data (30 days)
    const completedScans = scans
      .filter(
        (s) => s.status === "completed" && s.healthScore !== null,
      )
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());

    const trendData = completedScans.map((s) => ({
      date: formatDate(s.createdAt, { month: "short", day: "numeric" }),
      score: s.healthScore!,
    }));

    return {
      primaryStore,
      healthScore,
      scoreTrend,
      criticalCount,
      warningCount,
      passedChecks,
      lastScanTime,
      priorityIssues,
      recentScans,
      storeMap,
      trendData,
    };
  }, [stores, scans, allIssues]);

  // -----------------------------------------------------------------------
  // Empty state
  // -----------------------------------------------------------------------
  if (!loading && stores.length === 0) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <EmptyState
          icon={Shield}
          title="No stores yet"
          description="Add your first store to start monitoring its health, security, and performance."
          action={
            <Link to="/dashboard/stores">
              <Button>Add Your First Store</Button>
            </Link>
          }
        />
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // Loading state
  // -----------------------------------------------------------------------
  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <OverviewSkeleton />
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------
  return (
    <div className="mx-auto max-w-7xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl font-bold text-[#f0f0f5]">{getGreeting()}</h1>
        <p className="text-sm text-[#8888a0]">
          Here's your store health overview
        </p>
      </div>

      {/* Top Row: Health Card + Stat Cards */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        {/* Store Health Card */}
        <Card className="flex flex-col items-center justify-center p-6 lg:col-span-1">
          <p className="mb-3 text-xs font-medium uppercase tracking-wider text-[#8888a0]">
            Store Health
          </p>
          <ProgressRing
            value={metrics.healthScore ?? 0}
            size={140}
            strokeWidth={10}
          />
          <p
            className={cn(
              "mt-2 text-sm font-semibold",
              getScoreColor(metrics.healthScore ?? 0),
            )}
          >
            {getScoreLabel(metrics.healthScore ?? 0)}
          </p>
          {metrics.scoreTrend !== null && (
            <p
              className={cn(
                "mt-1 text-xs font-medium",
                metrics.scoreTrend >= 0 ? "text-[#22c55e]" : "text-[#ef4444]",
              )}
            >
              {metrics.scoreTrend >= 0 ? "+" : ""}
              {metrics.scoreTrend} from last scan
            </p>
          )}
          {metrics.primaryStore && (
            <p className="mt-2 text-xs text-[#55556a]">
              {metrics.primaryStore.name}
            </p>
          )}
        </Card>

        {/* Stat Cards Grid */}
        <div className="grid grid-cols-2 gap-4 lg:col-span-4">
          <StatCard
            icon={AlertOctagon}
            iconBg="rgba(239, 68, 68, 0.1)"
            iconColor="#ef4444"
            value={metrics.criticalCount}
            label="Critical Issues"
            trend={isDemoMode ? "+1 since yesterday" : undefined}
            trendColor="text-[#ef4444]"
          />
          <StatCard
            icon={AlertTriangle}
            iconBg="rgba(234, 179, 8, 0.1)"
            iconColor="#eab308"
            value={metrics.warningCount}
            label="Warnings"
          />
          <StatCard
            icon={CheckCircle2}
            iconBg="rgba(34, 197, 94, 0.1)"
            iconColor="#22c55e"
            value={metrics.passedChecks}
            label="Passed Checks"
          />
          <StatCard
            icon={Clock}
            iconBg="rgba(59, 130, 246, 0.1)"
            iconColor="#3b82f6"
            value={
              metrics.lastScanTime
                ? relativeTime(metrics.lastScanTime)
                : "Never"
            }
            label="Last Scan"
          />
        </div>
      </div>

      {/* Middle Row: Issues + Scans */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Priority Issues */}
        <Card>
          <CardHeader className="flex-row items-center justify-between pb-2">
            <CardTitle>Priority Issues</CardTitle>
            <Link to="/dashboard/issues">
              <button className="flex items-center gap-1 text-xs text-[#6366f1] hover:text-[#818cf8]">
                View All <ArrowRight className="h-3 w-3" />
              </button>
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {metrics.priorityIssues.length === 0 ? (
              <div className="px-4 py-8 text-center text-sm text-[#55556a]">
                No open issues. Great job!
              </div>
            ) : (
              <div className="max-h-96 overflow-y-auto">
                {metrics.priorityIssues.map((issue) => (
                  <IssueRow key={issue.id} issue={issue} />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Scans */}
        <Card>
          <CardHeader className="flex-row items-center justify-between pb-2">
            <CardTitle>Recent Scans</CardTitle>
            <Link to="/dashboard/scans">
              <button className="flex items-center gap-1 text-xs text-[#6366f1] hover:text-[#818cf8]">
                View All <ArrowRight className="h-3 w-3" />
              </button>
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {metrics.recentScans.length === 0 ? (
              <div className="px-4 py-8 text-center text-sm text-[#55556a]">
                No scans yet. Run your first scan.
              </div>
            ) : (
              <div className="max-h-96 overflow-y-auto">
                {metrics.recentScans.map((scan) => (
                  <ScanRow
                    key={scan.id}
                    scan={scan}
                    storeName={metrics.storeMap.get(scan.storeId)}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Health Trend Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Health Trend (30 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          {metrics.trendData.length === 0 ? (
            <div className="flex h-[260px] items-center justify-center text-sm text-[#55556a]">
              Not enough scan data to display trends. Run more scans to see the
              chart.
            </div>
          ) : (
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={metrics.trendData}>
                  <defs>
                    <linearGradient
                      id="scoreGradient"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                      <stop
                        offset="95%"
                        stopColor="#6366f1"
                        stopOpacity={0}
                      />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" />
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#55556a", fontSize: 12 }}
                    axisLine={{ stroke: "#1e1e2e" }}
                    tickLine={false}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fill: "#55556a", fontSize: 12 }}
                    axisLine={{ stroke: "#1e1e2e" }}
                    tickLine={false}
                  />
                  <Tooltip content={<ChartTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="#6366f1"
                    strokeWidth={2}
                    fill="url(#scoreGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader className="flex-row items-center justify-between pb-2">
          <CardTitle>Recommendations</CardTitle>
          <Link to="/dashboard/issues">
            <button className="flex items-center gap-1 text-xs text-[#6366f1] hover:text-[#818cf8]">
              View All Recommendations <ArrowRight className="h-3 w-3" />
            </button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <RecommendationCard
              icon={Shield}
              title="Add Content Security Policy"
              description="Implement a CSP header to protect against XSS attacks and data injection vulnerabilities."
              priority="high"
            />
            <RecommendationCard
              icon={Zap}
              title="Improve Page Load Speed"
              description="Optimize LCP by compressing images, implementing CDN caching, and reducing render-blocking resources."
              priority="high"
            />
            <RecommendationCard
              icon={Globe}
              title="Fix Missing SEO Tags"
              description="Add meta descriptions and Open Graph tags to improve search engine visibility and social sharing."
              priority="medium"
            />
            <RecommendationCard
              icon={Smartphone}
              title="Improve Mobile Experience"
              description="Increase touch target sizes to at least 44px and fix content overflow issues on mobile devices."
              priority="medium"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
