import { useState } from "react";
import {
  CreditCard,
  Check,
  ChevronDown,
  ChevronUp,
  Loader2,
  AlertTriangle,
  Crown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useSubscription } from "@/hooks/useSubscription";
import { PRICING_PLANS, getPlanById } from "@/config/pricing";
import { cn, formatDate, formatCurrency } from "@/lib/utils";
import type { SubscriptionPlan } from "@/types";

// ============================================================================
// Helpers
// ============================================================================

function getPaymentStatusVariant(
  status: string,
): "success" | "warning" | "destructive" | "secondary" {
  switch (status) {
    case "completed":
      return "success";
    case "pending":
      return "warning";
    case "failed":
      return "destructive";
    default:
      return "secondary";
  }
}

function getPlanBadgeVariant(
  plan: SubscriptionPlan,
): "info" | "success" | "warning" {
  switch (plan) {
    case "daily":
      return "warning";
    case "monthly":
      return "success";
    case "yearly":
      return "info";
  }
}

function getSubscriptionStatusBadge(
  status: string,
  cancelAtPeriodEnd: boolean,
): { label: string; variant: "success" | "warning" | "destructive" | "secondary" } {
  if (cancelAtPeriodEnd) {
    return { label: "Cancelling", variant: "warning" };
  }
  switch (status) {
    case "active":
      return { label: "Active", variant: "success" };
    case "paused":
      return { label: "Paused", variant: "warning" };
    case "cancelled":
      return { label: "Cancelled", variant: "destructive" };
    case "expired":
      return { label: "Expired", variant: "secondary" };
    default:
      return { label: status, variant: "secondary" };
  }
}

// ============================================================================
// Skeleton
// ============================================================================

function BillingSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-8 w-48" />
      <Skeleton className="h-[200px] w-full rounded-xl" />
      <Skeleton className="h-[300px] w-full rounded-xl" />
      <Skeleton className="h-[200px] w-full rounded-xl" />
    </div>
  );
}

// ============================================================================
// Plan Comparison Card
// ============================================================================

function PlanComparisonCard({
  plan,
  isCurrent,
  onSelect,
}: {
  plan: (typeof PRICING_PLANS)[number];
  isCurrent: boolean;
  onSelect: () => void;
}) {
  return (
    <Card
      className={cn(
        "relative flex flex-col",
        isCurrent && "border-[#6366f1] ring-1 ring-[#6366f1]/30",
        plan.featured && !isCurrent && "border-[#6366f1]/30",
      )}
    >
      {plan.featured && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <Badge>Recommended</Badge>
        </div>
      )}
      <CardHeader className="pb-2 text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          {plan.name}
          {plan.featured && <Crown className="h-4 w-4 text-[#6366f1]" />}
        </CardTitle>
        <div className="mt-2">
          <span className="text-3xl font-bold text-[#f0f0f5]">
            {plan.priceLabel}
          </span>
          <span className="text-sm text-[#55556a]">
            /{plan.interval}
          </span>
        </div>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-4">
        <p className="text-center text-xs text-[#8888a0]">
          {plan.description}
        </p>
        <ul className="flex-1 space-y-2">
          {plan.highlights.map((h) => (
            <li
              key={h}
              className="flex items-start gap-2 text-sm text-[#8888a0]"
            >
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#22c55e]" />
              {h}
            </li>
          ))}
        </ul>
        {isCurrent ? (
          <Button variant="secondary" className="w-full" disabled>
            Current Plan
          </Button>
        ) : (
          <Button
            variant="outline"
            className="w-full"
            onClick={onSelect}
          >
            Change Plan
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Billing() {
  const {
    subscription,
    payments,
    loading,
    isActive,
    daysRemaining,
    currentPlan,
    pricingPlan,
  } = useSubscription();

  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  const [planDialogOpen, setPlanDialogOpen] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] =
    useState<SubscriptionPlan | null>(null);
  const [paymentId, setPaymentId] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [verifyStatus, setVerifyStatus] = useState<
    "idle" | "success" | "error"
  >("idle");
  const [verifyError, setVerifyError] = useState("");

  // -----------------------------------------------------------------------
  // Loading
  // -----------------------------------------------------------------------
  if (loading) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <BillingSkeleton />
      </div>
    );
  }

  // -----------------------------------------------------------------------
  // Plan dialog
  // -----------------------------------------------------------------------
  const handleSelectPlan = (planId: SubscriptionPlan) => {
    setSelectedPlan(planId);
    setPlanDialogOpen(true);
    setVerifyStatus("idle");
    setVerifyError("");
    setPaymentId("");
  };

  const handleVerifyPayment = async () => {
    if (!paymentId.trim() || !selectedPlan) return;
    setVerifying(true);
    setVerifyStatus("idle");
    setVerifyError("");

    try {
      // In demo, just simulate success
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setVerifyStatus("success");
    } catch {
      setVerifyStatus("error");
      setVerifyError("Verification failed. Please check your payment ID.");
    } finally {
      setVerifying(false);
    }
  };

  const selectedPlanData = selectedPlan
    ? getPlanById(selectedPlan)
    : null;

  const subStatus = subscription
    ? getSubscriptionStatusBadge(
        subscription.status,
        subscription.cancelAtPeriodEnd,
      )
    : { label: "None", variant: "secondary" as const };

  return (
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#f0f0f5]">
          Billing & Subscription
        </h1>
        <p className="text-sm text-[#8888a0]">
          Manage your subscription plan and payment history
        </p>
      </div>

      {/* Current Plan Section */}
      {subscription && pricingPlan && (
        <Card>
          <CardHeader>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <CardTitle className="flex items-center gap-3">
                Current Plan
                <Badge variant={getPlanBadgeVariant(currentPlan)}>
                  {pricingPlan.name}
                </Badge>
                <Badge variant={subStatus.variant}>{subStatus.label}</Badge>
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <div>
                <p className="text-xs text-[#55556a]">Price</p>
                <p className="text-sm font-semibold text-[#f0f0f5]">
                  {pricingPlan.priceLabel}/{pricingPlan.interval}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#55556a]">Start Date</p>
                <p className="text-sm font-semibold text-[#f0f0f5]">
                  {formatDate(subscription.currentPeriodStart)}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#55556a]">Renewal Date</p>
                <p className="text-sm font-semibold text-[#f0f0f5]">
                  {formatDate(subscription.currentPeriodEnd)}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#55556a]">Days Remaining</p>
                <p
                  className={cn(
                    "text-sm font-semibold",
                    daysRemaining <= 5
                      ? "text-[#ef4444]"
                      : daysRemaining <= 14
                        ? "text-[#eab308]"
                        : "text-[#22c55e]",
                  )}
                >
                  {daysRemaining} days
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedPlan(null);
                  setPlanDialogOpen(true);
                }}
              >
                Change Plan
              </Button>
              {isActive && (
                <Button
                  variant="destructive"
                  onClick={() => setCancelDialogOpen(true)}
                >
                  Cancel Subscription
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Plan Comparison */}
      <div>
        <h2 className="mb-4 text-lg font-semibold text-[#f0f0f5]">
          Available Plans
        </h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {PRICING_PLANS.map((plan) => (
            <PlanComparisonCard
              key={plan.id}
              plan={plan}
              isCurrent={currentPlan === plan.id}
              onSelect={() => handleSelectPlan(plan.id)}
            />
          ))}
        </div>
      </div>

      {/* Payment History */}
      <Card>
        <CardHeader
          className="flex cursor-pointer flex-row items-center justify-between"
          onClick={() => setShowPaymentHistory((prev) => !prev)}
        >
          <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5 text-[#8888a0]" />
            Payment History
          </CardTitle>
          {showPaymentHistory ? (
            <ChevronUp className="h-5 w-5 text-[#55556a]" />
          ) : (
            <ChevronDown className="h-5 w-5 text-[#55556a]" />
          )}
        </CardHeader>
        {showPaymentHistory && (
          <CardContent className="p-0">
            {payments.length === 0 ? (
              <div className="px-4 py-8 text-center text-sm text-[#55556a]">
                No payment history yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-[#1e1e2e]">
                      <th className="px-4 py-3 text-xs font-medium uppercase tracking-wider text-[#55556a]">
                        Date
                      </th>
                      <th className="px-4 py-3 text-xs font-medium uppercase tracking-wider text-[#55556a]">
                        Plan
                      </th>
                      <th className="px-4 py-3 text-xs font-medium uppercase tracking-wider text-[#55556a]">
                        Amount
                      </th>
                      <th className="px-4 py-3 text-xs font-medium uppercase tracking-wider text-[#55556a]">
                        Status
                      </th>
                      <th className="px-4 py-3 text-xs font-medium uppercase tracking-wider text-[#55556a]">
                        Payment ID
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map((payment) => (
                      <tr
                        key={payment.id}
                        className="border-b border-[#1e1e2e] last:border-0 hover:bg-[#15151f]"
                      >
                        <td className="whitespace-nowrap px-4 py-3 text-[#f0f0f5]">
                          {formatDate(payment.createdAt)}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 text-[#f0f0f5]">
                          {payment.description}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 font-medium text-[#f0f0f5]">
                          {formatCurrency(payment.amount)}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <Badge
                            variant={getPaymentStatusVariant(payment.status)}
                          >
                            {payment.status}
                          </Badge>
                        </td>
                        <td className="max-w-[140px] truncate px-4 py-3 text-xs text-[#55556a]">
                          {payment.providerPaymentId ?? "--"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        )}
      </Card>

      {/* ================================================================== */}
      {/* Plan Change Dialog */}
      {/* ================================================================== */}
      <Dialog open={planDialogOpen} onOpenChange={setPlanDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Your Plan</DialogTitle>
            <DialogDescription>
              {selectedPlanData
                ? `Switch to the ${selectedPlanData.name} plan (${selectedPlanData.priceLabel}/${selectedPlanData.interval})`
                : "Select a new plan below."}
            </DialogDescription>
          </DialogHeader>

          {/* Plan selector (when no plan pre-selected) */}
          {!selectedPlanData && (
            <div className="space-y-2">
              {PRICING_PLANS.map((plan) => (
                <button
                  key={plan.id}
                  type="button"
                  onClick={() => {
                    setSelectedPlan(plan.id);
                    setVerifyStatus("idle");
                    setVerifyError("");
                  }}
                  className={cn(
                    "flex w-full items-center justify-between rounded-lg border border-[#1e1e2e] px-4 py-3 transition-colors hover:bg-[#15151f]",
                    currentPlan === plan.id &&
                      "border-[#6366f1]/30 bg-[#6366f1]/5",
                  )}
                >
                  <div className="text-left">
                    <p className="text-sm font-medium text-[#f0f0f5]">
                      {plan.name} Plan
                    </p>
                    <p className="text-xs text-[#55556a]">
                      {plan.description}
                    </p>
                  </div>
                  <span className="text-sm font-semibold text-[#f0f0f5]">
                    {plan.priceLabel}/{plan.interval}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Payment instructions for selected plan */}
          {selectedPlanData && (
            <div className="space-y-4">
              <div className="rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-4">
                <h4 className="mb-2 text-sm font-medium text-[#f0f0f5]">
                  Payment Instructions
                </h4>
                <p className="text-sm text-[#8888a0]">
                  Send {formatCurrency(selectedPlanData.priceCents / 100)} to
                  the StoreGuard wallet address. After payment, enter your
                  transaction ID below to verify.
                </p>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium text-[#f0f0f5]">
                  Payment / Transaction ID
                </label>
                <Input
                  placeholder="Enter your payment ID"
                  value={paymentId}
                  onChange={(e) => setPaymentId(e.target.value)}
                  error={verifyStatus === "error"}
                />
                {verifyError && (
                  <p className="mt-1.5 text-xs text-[#ef4444]">
                    {verifyError}
                  </p>
                )}
                {verifyStatus === "success" && (
                  <p className="mt-1.5 text-xs text-[#22c55e]">
                    Payment verified successfully! Plan will be updated shortly.
                  </p>
                )}
              </div>

              {verifyStatus !== "success" && (
                <Button
                  className="w-full"
                  onClick={handleVerifyPayment}
                  disabled={!paymentId.trim() || verifying}
                >
                  {verifying && (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  )}
                  Verify Payment
                </Button>
              )}

              <Button
                variant="ghost"
                size="sm"
                className="w-full"
                onClick={() => {
                  setSelectedPlan(null);
                  setVerifyStatus("idle");
                }}
              >
                Back to plan selection
              </Button>
            </div>
          )}

          <DialogFooter />
        </DialogContent>
      </Dialog>

      {/* ================================================================== */}
      {/* Cancel Subscription Dialog */}
      {/* ================================================================== */}
      <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-[#eab308]" />
              Cancel Subscription
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel your subscription? You will
              continue to have access until the end of your current billing
              period ({daysRemaining} days remaining).
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-lg border border-[#eab308]/20 bg-[#eab308]/5 p-4">
            <p className="text-sm text-[#eab308]">
              After cancellation, your stores will no longer be monitored and
              your scan history will be retained for 30 days.
            </p>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setCancelDialogOpen(false)}
            >
              Keep Subscription
            </Button>
            <Button
              variant="destructive"
              onClick={() => setCancelDialogOpen(false)}
            >
              Yes, Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
