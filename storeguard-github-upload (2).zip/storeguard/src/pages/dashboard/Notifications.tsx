import { useState, useMemo } from "react";
import {
  Bell,
  BellOff,
  AlertTriangle,
  Info,
  CheckCircle2,
  AlertOctagon,
  CheckCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { cn, formatRelativeTime } from "@/lib/utils";
import { demoNotifications } from "@/data/demo";
import type { Notification } from "@/types";

// ============================================================================
// Helpers
// ============================================================================

type FilterTab = "all" | "unread" | "alerts" | "reports";

function getNotificationIcon(type: string) {
  switch (type) {
    case "critical_issue_found":
      return AlertOctagon;
    case "scan_completed":
      return CheckCircle2;
    case "subscription_expiring":
      return AlertTriangle;
    case "weekly_summary":
      return Info;
    default:
      return Bell;
  }
}

function getNotificationIconColor(type: string): string {
  switch (type) {
    case "critical_issue_found":
      return "text-[#ef4444]";
    case "scan_completed":
      return "text-[#22c55e]";
    case "subscription_expiring":
      return "text-[#eab308]";
    case "health_score_dropped":
      return "text-[#eab308]";
    default:
      return "text-[#3b82f6]";
  }
}

function getNotificationIconBg(type: string): string {
  switch (type) {
    case "critical_issue_found":
      return "bg-[#ef4444]/10";
    case "scan_completed":
      return "bg-[#22c55e]/10";
    case "subscription_expiring":
      return "bg-[#eab308]/10";
    case "health_score_dropped":
      return "bg-[#eab308]/10";
    default:
      return "bg-[#3b82f6]/10";
  }
}

const FILTER_TABS: { key: FilterTab; label: string }[] = [
  { key: "all", label: "All" },
  { key: "unread", label: "Unread" },
  { key: "alerts", label: "Alerts" },
  { key: "reports", label: "Reports" },
];

// ============================================================================
// Notification Card
// ============================================================================

function NotificationCard({
  notification,
  onMarkRead,
}: {
  notification: Notification;
  onMarkRead: (id: string) => void;
}) {
  const Icon = getNotificationIcon(notification.type);
  const iconColor = getNotificationIconColor(notification.type);
  const iconBg = getNotificationIconBg(notification.type);

  return (
    <button
      type="button"
      onClick={() => !notification.isRead && onMarkRead(notification.id)}
      className={cn(
        "flex w-full items-start gap-4 border-b border-[#1e1e2e] px-4 py-4 text-left transition-colors last:border-0",
        !notification.isRead
          ? "bg-[#6366f1]/[0.03] hover:bg-[#6366f1]/[0.06]"
          : "hover:bg-[#15151f]",
      )}
    >
      {/* Unread indicator */}
      <div className="relative">
        {!notification.isRead && (
          <span className="absolute -left-1.5 top-1.5 h-2 w-2 rounded-full bg-[#3b82f6]" />
        )}
        <div
          className={cn(
            "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",
            iconBg,
          )}
        >
          <Icon className={cn("h-4 w-4", iconColor)} />
        </div>
      </div>

      <div className="min-w-0 flex-1">
        <p
          className={cn(
            "text-sm",
            notification.isRead
              ? "font-medium text-[#8888a0]"
              : "font-semibold text-[#f0f0f5]",
          )}
        >
          {notification.title}
        </p>
        <p className="mt-1 text-sm text-[#8888a0]">{notification.message}</p>
      </div>

      <span className="shrink-0 text-xs text-[#55556a]">
        {formatRelativeTime(notification.createdAt)}
      </span>
    </button>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Notifications() {
  const [notifications, setNotifications] =
    useState<Notification[]>(demoNotifications);
  const [activeTab, setActiveTab] = useState<FilterTab>("all");

  // -----------------------------------------------------------------------
  // Filter notifications
  // -----------------------------------------------------------------------
  const filteredNotifications = useMemo(() => {
    switch (activeTab) {
      case "unread":
        return notifications.filter((n) => !n.isRead);
      case "alerts":
        return notifications.filter(
          (n) =>
            n.type === "critical_issue_found" ||
            n.type === "subscription_expiring" ||
            n.type === "health_score_dropped",
        );
      case "reports":
        return notifications.filter(
          (n) =>
            n.type === "scan_completed" || n.type === "weekly_summary",
        );
      default:
        return notifications;
    }
  }, [notifications, activeTab]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  // -----------------------------------------------------------------------
  // Actions
  // -----------------------------------------------------------------------
  const handleMarkRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)),
    );
  };

  const handleMarkAllRead = () => {
    setNotifications((prev) =>
      prev.map((n) => ({ ...n, isRead: true })),
    );
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#f0f0f5]">Notifications</h1>
          <p className="text-sm text-[#8888a0]">
            {unreadCount > 0
              ? `${unreadCount} unread notification${unreadCount !== 1 ? "s" : ""}`
              : "All caught up"}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-[#8888a0]"
            onClick={handleMarkAllRead}
          >
            <CheckCheck className="h-4 w-4" />
            Mark All Read
          </Button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1 rounded-lg bg-[#0d0d14] p-1">
        {FILTER_TABS.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              "rounded-md px-3 py-1.5 text-sm font-medium transition-all duration-200",
              activeTab === tab.key
                ? "bg-[#6366f1] text-white shadow-sm"
                : "text-[#8888a0] hover:text-[#f0f0f5]",
            )}
          >
            {tab.label}
            {tab.key === "unread" && unreadCount > 0 && (
              <span className="ml-1.5 inline-flex h-5 min-w-[20px] items-center justify-center rounded-full bg-[#3b82f6] px-1.5 text-[10px] font-bold text-white">
                {unreadCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Notification List */}
      <div className="overflow-hidden rounded-xl border border-[#1e1e2e] bg-[#111118]">
        {filteredNotifications.length === 0 ? (
          <EmptyState
            icon={BellOff}
            title="No notifications"
            description={
              activeTab === "unread"
                ? "You've read all your notifications."
                : "No notifications match this filter."
            }
          />
        ) : (
          <div className="max-h-[600px] overflow-y-auto">
            {filteredNotifications.map((notification) => (
              <NotificationCard
                key={notification.id}
                notification={notification}
                onMarkRead={handleMarkRead}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
