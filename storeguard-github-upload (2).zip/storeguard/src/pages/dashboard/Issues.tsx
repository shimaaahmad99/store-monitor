import { useState, useMemo, useCallback } from "react";
import {
  Search,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Check,
  EyeOff,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { useStores } from "@/hooks/useStores";
import { useIssues } from "@/hooks/useIssues";
import { cn, formatDate } from "@/lib/utils";
import type {
  Issue,
  IssueSeverity,
  IssueStatus,
  ScanCheckCategory,
} from "@/types";

// ============================================================================
// Constants
// ============================================================================

const SEVERITY_TABS: Array<{ value: IssueSeverity | "all"; label: string }> = [
  { value: "all", label: "All" },
  { value: "critical", label: "Critical" },
  { value: "warning", label: "Warning" },
  { value: "minor", label: "Minor" },
];

const STATUS_OPTIONS: Array<{ value: IssueStatus | "all"; label: string }> = [
  { value: "all", label: "All" },
  { value: "open", label: "Open" },
  { value: "in_progress", label: "In Progress" },
  { value: "resolved", label: "Resolved" },
  { value: "dismissed", label: "Ignored" },
];

const CATEGORY_OPTIONS: Array<{
  value: ScanCheckCategory | "all";
  label: string;
}> = [
  { value: "all", label: "All Categories" },
  { value: "security", label: "Security" },
  { value: "performance", label: "Performance" },
  { value: "seo", label: "SEO" },
  { value: "accessibility", label: "Accessibility" },
  { value: "mobile", label: "Mobile" },
  { value: "content", label: "Content" },
  { value: "analytics", label: "Analytics" },
  { value: "ssl", label: "SSL" },
];

// ============================================================================
// Helpers
// ============================================================================

function getSeverityBorder(severity: IssueSeverity): string {
  switch (severity) {
    case "critical":
      return "border-l-[#ef4444]";
    case "warning":
      return "border-l-[#eab308]";
    case "minor":
      return "border-l-[#3b82f6]";
  }
}

function getSeverityBadgeVariant(
  severity: IssueSeverity,
): "destructive" | "warning" | "info" {
  switch (severity) {
    case "critical":
      return "destructive";
    case "warning":
      return "warning";
    case "minor":
      return "info";
  }
}

function getStatusBadgeVariant(
  status: IssueStatus,
): "destructive" | "warning" | "success" | "secondary" {
  switch (status) {
    case "open":
      return "destructive";
    case "in_progress":
      return "warning";
    case "resolved":
      return "success";
    case "dismissed":
      return "secondary";
  }
}

function getStatusLabel(status: IssueStatus): string {
  switch (status) {
    case "open":
      return "Open";
    case "in_progress":
      return "In Progress";
    case "resolved":
      return "Resolved";
    case "dismissed":
      return "Ignored";
  }
}

function extractDomain(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}

// ============================================================================
// Sub-components
// ============================================================================

function IssuesSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-8 w-32" />
        <Skeleton className="h-6 w-48" />
      </div>
      <div className="space-y-3">
        <Skeleton className="h-10 w-full rounded-lg" />
        <Skeleton className="h-10 w-64 rounded-lg" />
      </div>
      {[...Array(4)].map((_, i) => (
        <Skeleton key={i} className="h-[140px] w-full rounded-xl" />
      ))}
    </div>
  );
}

function IssueCard({
  issue,
  storeUrl,
  onResolve,
  onIgnore,
  onReopen,
}: {
  issue: Issue;
  storeUrl?: string;
  onResolve: () => void;
  onIgnore: () => void;
  onReopen: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const isOpen = issue.status === "open" || issue.status === "in_progress";

  return (
    <Card className={cn("border-l-2", getSeverityBorder(issue.severity))}>
      <CardContent className="p-4 sm:p-5">
        {/* Top Row: Badges + Time */}
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant={getSeverityBadgeVariant(issue.severity)} dot>
            {issue.severity === "critical"
              ? "Critical"
              : issue.severity === "warning"
                ? "Warning"
                : "Minor"}
          </Badge>
          <Badge variant={getStatusBadgeVariant(issue.status)}>
            {getStatusLabel(issue.status)}
          </Badge>
          <Badge variant="outline">{issue.category}</Badge>
          <span className="ml-auto text-xs text-[#55556a]">
            {formatDate(issue.createdAt, { month: "short", day: "numeric" })}
          </span>
        </div>

        {/* Title */}
        <h3 className="mt-3 text-sm font-semibold text-[#f0f0f5]">
          {issue.title}
        </h3>

        {/* Description (max 2 lines) */}
        <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-[#8888a0]">
          {issue.description}
        </p>

        {/* URL (if available) */}
        {storeUrl && (
          <p className="mt-2 truncate font-mono text-xs text-[#55556a]">
            {extractDomain(storeUrl)}
          </p>
        )}

        {/* Expandable Recommendation */}
        {issue.recommendation && (
          <div className="mt-3">
            <button
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1 text-xs text-[#6366f1] hover:text-[#818cf8]"
            >
              {expanded ? (
                <ChevronUp className="h-3 w-3" />
              ) : (
                <ChevronDown className="h-3 w-3" />
              )}
              {expanded ? "Hide" : "Show"} Recommendation
            </button>
            {expanded && (
              <div className="mt-2 rounded-lg border border-[#1e1e2e] bg-[#0d0d14] p-3">
                <p className="text-xs leading-relaxed text-[#8888a0]">
                  {issue.recommendation}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <Separator className="my-3" />
        <div className="flex items-center gap-2">
          {isOpen ? (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={onResolve}
                className="text-[#22c55e] hover:bg-[#22c55e]/10 hover:text-[#22c55e]"
              >
                <Check className="h-3.5 w-3.5" />
                Resolve
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={onIgnore}
                className="text-[#8888a0]"
              >
                <EyeOff className="h-3.5 w-3.5" />
                Ignore
              </Button>
            </>
          ) : (
            <Button variant="outline" size="sm" onClick={onReopen}>
              <RotateCcw className="h-3.5 w-3.5" />
              Reopen
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Main Component
// ============================================================================

export default function Issues() {
  const { stores } = useStores();
  const {
    issues,
    allIssues,
    loading,
    filters,
    updateIssueStatus,
    filterIssues,
  } = useIssues();

  const [searchInput, setSearchInput] = useState("");

  // Store URL lookup
  const storeUrlMap = useMemo(() => {
    const map = new Map<string, string>();
    for (const s of stores) map.set(s.id, s.url);
    return map;
  }, [stores]);

  // Counts
  const counts = useMemo(() => {
    const open = allIssues.filter(
      (i) => i.status === "open" || i.status === "in_progress",
    );
    return {
      total: allIssues.length,
      open: open.length,
      critical: allIssues.filter((i) => i.severity === "critical").length,
    };
  }, [allIssues]);

  // Search handler
  const handleSearch = useCallback(
    (value: string) => {
      setSearchInput(value);
      filterIssues({ search: value });
    },
    [filterIssues],
  );

  // Severity tab change
  const handleSeverityChange = useCallback(
    (value: string) => {
      filterIssues({ severity: value as IssueSeverity | "all" });
    },
    [filterIssues],
  );

  // Status change
  const handleStatusChange = useCallback(
    (value: string) => {
      filterIssues({ status: value as IssueStatus | "all" });
    },
    [filterIssues],
  );

  // Category change
  const handleCategoryChange = useCallback(
    (value: string) => {
      filterIssues({ category: value as ScanCheckCategory | "all" });
    },
    [filterIssues],
  );

  // Issue actions
  const handleResolve = useCallback(
    (issueId: string) => {
      updateIssueStatus(issueId, "resolved");
    },
    [updateIssueStatus],
  );

  const handleIgnore = useCallback(
    (issueId: string) => {
      updateIssueStatus(issueId, "dismissed");
    },
    [updateIssueStatus],
  );

  const handleReopen = useCallback(
    (issueId: string) => {
      updateIssueStatus(issueId, "open");
    },
    [updateIssueStatus],
  );

  // -----------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------
  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <IssuesSkeleton />
      </div>
    );
  }

  const hasActiveFilters =
    searchInput ||
    filters.severity !== "all" ||
    filters.status !== "all" ||
    filters.category !== "all";

  return (
    <div className="mx-auto max-w-7xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#f0f0f5]">Issues</h1>
          <p className="text-sm text-[#8888a0]">
            {counts.open} open issue{counts.open !== 1 ? "s" : ""} of{" "}
            {counts.total} total ({counts.critical} critical)
          </p>
        </div>
      </div>

      {/* Search */}
      <Input
        placeholder="Search issues by title or description..."
        value={searchInput}
        onChange={(e) => handleSearch(e.target.value)}
        leftIcon={<Search className="h-4 w-4" />}
      />

      {/* Filter Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        {/* Severity Tabs */}
        <Tabs defaultValue="all" onValueChange={handleSeverityChange}>
          <TabsList>
            {SEVERITY_TABS.map((tab) => (
              <TabsTrigger key={tab.value} value={tab.value}>
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        <div className="flex gap-3">
          {/* Status Filter */}
          <Select
            value={(filters.status as string) ?? "all"}
            onValueChange={handleStatusChange}
          >
            <SelectTrigger className="w-full sm:w-36">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {STATUS_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Category Filter */}
          <Select
            value={(filters.category as string) ?? "all"}
            onValueChange={handleCategoryChange}
          >
            <SelectTrigger className="w-full sm:w-44">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {CATEGORY_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Issues List */}
      {issues.length === 0 ? (
        <EmptyState
          icon={AlertCircle}
          title="No issues found"
          description={
            hasActiveFilters
              ? "No issues match the current filters. Try adjusting your search or filter criteria."
              : "No issues have been detected. All checks are passing."
          }
        />
      ) : (
        <div className="space-y-3">
          {issues.map((issue) => (
            <IssueCard
              key={issue.id}
              issue={issue}
              storeUrl={storeUrlMap.get(issue.storeId)}
              onResolve={() => handleResolve(issue.id)}
              onIgnore={() => handleIgnore(issue.id)}
              onReopen={() => handleReopen(issue.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
