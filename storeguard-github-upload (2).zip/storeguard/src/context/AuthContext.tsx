"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from "react";
import { supabase, isSupabaseConfigured } from "@/services/supabase";
import type { Profile } from "@/types";

type User = {
  id: string;
  email: string | null;
  user_metadata?: Record<string, unknown>;
};

interface AuthState {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  isDemoMode: boolean;
}

interface AuthContextValue extends AuthState {
  signup: (email: string, password: string) => Promise<{ error: string | null }>;
  login: (email: string, password: string) => Promise<{ error: string | null }>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: string | null }>;
  updateProfile: (data: Partial<Profile>) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// ---------------------------------------------------------------------------
// Demo User
// ---------------------------------------------------------------------------

const DEMO_USER: User = {
  id: "demo",
  email: "demo@storeguard.com",
  user_metadata: { full_name: "Demo User" },
};

const DEMO_PROFILE: Profile = {
  id: "demo-profile",
  userId: "demo",
  fullName: "Demo User",
  avatarUrl: null,
  email: "demo@storeguard.com",
  phone: null,
  company: "Demo Store Co.",
  role: "owner",
  createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
  updatedAt: new Date(),
};

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDemoMode, setIsDemoMode] = useState(false);

  // -----------------------------------------------------------------------
  // Determine demo mode on mount
  // -----------------------------------------------------------------------
  useEffect(() => {
    const configured = isSupabaseConfigured();

    if (!configured) {
      // No Supabase configured → operate in demo mode
      setIsDemoMode(true);
      setUser(DEMO_USER);
      setProfile(DEMO_PROFILE);
      setLoading(false);
      return;
    }

    // Supabase is configured — listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        if (session?.user) {
          const authUser: User = {
            id: session.user.id,
            email: session.user.email ?? null,
            user_metadata: session.user.user_metadata,
          };
          setUser(authUser);

          // Fetch profile from the profiles table
          try {
            const { data: profileRow } = await supabase
              .from("profiles")
              .select("*")
              .eq("user_id", session.user.id)
              .single();

            if (profileRow) {
              setProfile({
                id: profileRow.id,
                userId: profileRow.user_id,
                fullName: profileRow.full_name,
                avatarUrl: profileRow.avatar_url,
                email: profileRow.email,
                phone: profileRow.phone,
                company: profileRow.company,
                role: profileRow.role,
                createdAt: new Date(profileRow.created_at),
                updatedAt: new Date(profileRow.updated_at),
              });
            } else {
              setProfile(null);
            }
          } catch {
            setProfile(null);
          }
        } else {
          setUser(null);
          setProfile(null);
        }
        setLoading(false);
      },
    );

    // Get the initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        setLoading(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // -----------------------------------------------------------------------
  // Auth actions
  // -----------------------------------------------------------------------

  const signup = useCallback(
    async (email: string, password: string) => {
      if (isDemoMode) {
        return { error: "Sign-up is not available in demo mode." };
      }

      const { error } = await supabase.auth.signUp({ email, password });
      return { error: error?.message ?? null };
    },
    [isDemoMode],
  );

  const login = useCallback(
    async (email: string, password: string) => {
      if (isDemoMode) {
        return { error: "Login is not available in demo mode." };
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      return { error: error?.message ?? null };
    },
    [isDemoMode],
  );

  const logout = useCallback(async () => {
    if (isDemoMode) {
      return;
    }
    await supabase.auth.signOut();
  }, [isDemoMode]);

  const resetPassword = useCallback(
    async (email: string) => {
      if (isDemoMode) {
        return { error: "Password reset is not available in demo mode." };
      }

      const { error } = await supabase.auth.resetPasswordForEmail(email);
      return { error: error?.message ?? null };
    },
    [isDemoMode],
  );

  const updateProfile = useCallback(
    async (data: Partial<Profile>) => {
      if (isDemoMode) {
        // In demo mode, just update the local state
        setProfile((prev) =>
          prev ? { ...prev, ...data, updatedAt: new Date() } : prev,
        );
        return { error: null };
      }

      if (!user) {
        return { error: "No authenticated user." };
      }

      // Map app fields → database columns
      const row: Record<string, unknown> = {};
      if (data.fullName !== undefined) row.full_name = data.fullName;
      if (data.avatarUrl !== undefined) row.avatar_url = data.avatarUrl;
      if (data.phone !== undefined) row.phone = data.phone;
      if (data.company !== undefined) row.company = data.company;
      if (data.role !== undefined) row.role = data.role;
      row.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from("profiles")
        .update(row)
        .eq("user_id", user.id);

      if (error) {
        return { error: error.message };
      }

      // Refresh profile from DB
      const { data: freshRow } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (freshRow) {
        setProfile({
          id: freshRow.id,
          userId: freshRow.user_id,
          fullName: freshRow.full_name,
          avatarUrl: freshRow.avatar_url,
          email: freshRow.email,
          phone: freshRow.phone,
          company: freshRow.company,
          role: freshRow.role,
          createdAt: new Date(freshRow.created_at),
          updatedAt: new Date(freshRow.updated_at),
        });
      }

      return { error: null };
    },
    [isDemoMode, user],
  );

  // -----------------------------------------------------------------------
  // Context value
  // -----------------------------------------------------------------------

  const value: AuthContextValue = {
    user,
    profile,
    loading,
    isDemoMode,
    signup,
    login,
    logout,
    resetPassword,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (ctx === undefined) {
    throw new Error("useAuth must be used within an AuthProvider.");
  }
  return ctx;
}
