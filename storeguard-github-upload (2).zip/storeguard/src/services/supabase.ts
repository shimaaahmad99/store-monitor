import { createClient, type SupabaseClient } from "@supabase/supabase-js";

// ---------------------------------------------------------------------------
// Environment Validation
// ---------------------------------------------------------------------------

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Service role key is server-side only and must NEVER be exposed to the browser.
// In a Vite/Cloudflare Pages setup, this would only be available in server-side
// contexts such as Cloudflare Workers/Functions.
// Note: VITE_ prefix is not used here intentionally — this key must never reach the client.
const SUPABASE_SERVICE_ROLE_KEY: string | undefined = undefined;

/**
 * Check if Supabase is configured. Returns false during development/demo mode
 * when env vars are not set.
 */
export function isSupabaseConfigured(): boolean {
  return !!(SUPABASE_URL && SUPABASE_ANON_KEY);
}

// For demo/development mode, provide a stub client that won't crash
const _supabaseUrl = SUPABASE_URL ?? "https://placeholder.supabase.co";
const _supabaseKey = SUPABASE_ANON_KEY ?? "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.placeholder";

// ---------------------------------------------------------------------------
// Client (browser-safe — uses anon key)
// ---------------------------------------------------------------------------

/**
 * Public Supabase client safe for use in browser.
 * Uses the anon key which respects Row Level Security policies.
 *
 * When Supabase is not configured (demo mode), this client will not function
 * for real operations but allows the app to render without crashes.
 */
export const supabase: SupabaseClient = createClient(
  _supabaseUrl,
  _supabaseKey,
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
    },
  },
);

// ---------------------------------------------------------------------------
// Server-Side Client (admin — bypasses RLS)
// ---------------------------------------------------------------------------

/**
 * Create a Supabase client with the **service role** key.
 *
 * SERVER-SIDE ONLY — this client **bypasses** Row Level Security.
 * Never expose the service role key to the browser.
 */
export function getServerSupabase(): SupabaseClient {
  if (!SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error(
      "Missing SUPABASE_SERVICE_ROLE_KEY. " +
        "This is required for server-side admin operations.",
    );
  }

  return createClient(
    SUPABASE_URL!,
    SUPABASE_SERVICE_ROLE_KEY,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    },
  );
}
