import type {
  ScanResult,
  ScanCheckItem,
  ScanCheckCategory,
  ScanSummary,
  CategorySummary,
} from "@/types";
import { calculateHealthScore } from "@/lib/health-score";
import { SCAN_CONFIG } from "@/config";

// ============================================================================
// Errors
// ============================================================================

export class ScannerError extends Error {
  constructor(
    message: string,
    public readonly code:
      | "INVALID_URL"
      | "BLOCKED_HOST"
      | "TIMEOUT"
      | "FETCH_FAILED"
      | "INTERNAL",
  ) {
    super(message);
    this.name = "ScannerError";
  }
}

// ============================================================================
// SSRF Protection
// ============================================================================

/**
 * IP ranges that MUST NOT be scanned (private / loopback / link-local).
 * Stored as [start, end] pairs of 32-bit unsigned integers.
 */
const BLOCKED_RANGES: [number, number][] = [
  // 0.0.0.0/8
  [0x00000000, 0x0fffffff],
  // 10.0.0.0/8
  [0x0a000000, 0x0affffff],
  // 100.64.0.0/10 (Carrier-grade NAT)
  [0x64400000, 0x647fffff],
  // 127.0.0.0/8
  [0x7f000000, 0x7fffffff],
  // 169.254.0.0/16
  [0xa9fe0000, 0xa9feffff],
  // 172.16.0.0/12
  [0xac100000, 0xac1fffff],
  // 192.0.0.0/24
  [0xc0000000, 0xc00000ff],
  // 192.0.2.0/24
  [0xc0000200, 0xc00002ff],
  // 192.168.0.0/16
  [0xc0a80000, 0xc0a8ffff],
  // 198.18.0.0/15
  [0xc6120000, 0xc613ffff],
  // 198.51.100.0/24
  [0xc6336400, 0xc63364ff],
  // 203.0.113.0/24
  [0xcb007100, 0xcb0071ff],
  // 224.0.0.0/4 (multicast)
  [0xe0000000, 0xefffffff],
  // 240.0.0.0/4
  [0xf0000000, 0xffffffff],
];

/** Hostnames that are always blocked. */
const BLOCKED_HOSTNAMES = new Set([
  "localhost",
  "localhost.localdomain",
  "ip6-localhost",
  "ip6-loopback",
]);

function ipv4ToInt(octets: number[]): number {
  return (
    ((octets[0]! << 24) | (octets[1]! << 16) | (octets[2]! << 8) | octets[3]!) >>>
    0
  );
}

function isBlockedIp(ipStr: string): boolean {
  const octets = ipStr
    .split(".")
    .map((o) => Number.parseInt(o, 10));
  if (octets.length !== 4 || octets.some((o) => Number.isNaN(o) || o < 0 || o > 255)) {
    return true; // unparseable → block
  }
  const ipInt = ipv4ToInt(octets);
  return BLOCKED_RANGES.some(
    ([start, end]) => ipInt >= start && ipInt <= end,
  );
}

// ============================================================================
// URL Validation
// ============================================================================

function validateUrl(url: string): URL {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    throw new ScannerError(
      `"${url}" is not a valid URL.`,
      "INVALID_URL",
    );
  }

  if (parsed.protocol !== "https:") {
    throw new ScannerError(
      "Only HTTPS URLs are allowed for security reasons.",
      "INVALID_URL",
    );
  }

  const hostname = parsed.hostname.toLowerCase();

  if (BLOCKED_HOSTNAMES.has(hostname)) {
    throw new ScannerError(
      `Scanning "${hostname}" is not allowed (private host).`,
      "BLOCKED_HOST",
    );
  }

  // Block raw IP addresses (even if they happen to be public)
  if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname)) {
    if (isBlockedIp(hostname)) {
      throw new ScannerError(
        `IP address "${hostname}" belongs to a private/reserved range.`,
        "BLOCKED_HOST",
      );
    }
  }

  return parsed;
}

// ============================================================================
// Demo Data Generator
// ============================================================================

/** Generate deterministic demo check results based on the URL. */
function generateDemoChecks(url: string, categories: ScanCheckCategory[]): ScanCheckItem[] {
  // Use a simple hash of the URL to create deterministic (but varied) results
  const hash = url.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const checks: ScanCheckItem[] = [];

  // --- Security ---
  if (categories.includes("security")) {
    const secChecks = buildSecurityChecks(hash);
    checks.push(...secChecks);
  }

  // --- SSL ---
  if (categories.includes("ssl")) {
    const sslChecks = buildSSLChecks(hash);
    checks.push(...sslChecks);
  }

  // --- Performance ---
  if (categories.includes("performance")) {
    const perfChecks = buildPerformanceChecks(hash);
    checks.push(...perfChecks);
  }

  // --- SEO ---
  if (categories.includes("seo")) {
    const seoChecks = buildSEOChecks(hash);
    checks.push(...seoChecks);
  }

  // --- Mobile ---
  if (categories.includes("mobile")) {
    const mobileChecks = buildMobileChecks(hash);
    checks.push(...mobileChecks);
  }

  // --- Accessibility ---
  if (categories.includes("accessibility")) {
    const a11yChecks = buildAccessibilityChecks(hash);
    checks.push(...a11yChecks);
  }

  // --- Content ---
  if (categories.includes("content")) {
    const contentChecks = buildContentChecks(hash);
    checks.push(...contentChecks);
  }

  // --- Analytics ---
  if (categories.includes("analytics")) {
    const analyticsChecks = buildAnalyticsChecks(hash);
    checks.push(...analyticsChecks);
  }

  return checks;
}

// --- Per-Category Builders ---

function buildSecurityChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  // Content Security Policy
  checks.push({
    category: "security",
    name: "Content Security Policy",
    description: mod > 30 ? "CSP header is present with reasonable directives." : "Missing or misconfigured Content-Security-Policy header.",
    status: mod > 30 ? "passed" : "failed",
    severity: mod > 30 ? "minor" : "critical",
    details: mod > 30 ? { directive: "default-src 'self'" } : { missing: true },
    recommendation: mod > 30 ? "Consider adding 'upgrade-insecure-requests' to your CSP." : "Add a Content-Security-Policy header with appropriate directives.",
  });

  // X-Frame-Options
  checks.push({
    category: "security",
    name: "X-Frame-Options Header",
    description: "Checks if the X-Frame-Options header is set to prevent clickjacking.",
    status: mod > 20 ? "passed" : "failed",
    severity: mod > 20 ? "minor" : "warning",
    details: { value: mod > 20 ? "DENY" : "missing" },
    recommendation: mod > 20 ? "Your X-Frame-Options is properly configured." : "Set X-Frame-Options to DENY or SAMEORIGIN.",
  });

  // HTTP Strict Transport Security
  checks.push({
    category: "security",
    name: "HTTP Strict Transport Security",
    description: mod > 45 ? "HSTS is enabled with a reasonable max-age." : "HSTS is either missing or has a very short max-age.",
    status: mod > 45 ? "passed" : "warning",
    severity: mod > 45 ? "minor" : "warning",
    details: mod > 45 ? { "max-age": 31536000, includeSubDomains: true } : { missing: true },
    recommendation: "Enable HSTS with at least a 6-month max-age (15768000 seconds).",
  });

  // Form action validation
  checks.push({
    category: "security",
    name: "Form Action Validation",
    description: mod > 55 ? "All form actions point to expected domains." : "Some forms submit to external or unexpected domains.",
    status: mod > 55 ? "passed" : "failed",
    severity: mod > 55 ? "minor" : "critical",
    details: { externalForms: mod > 55 ? 0 : 2 },
    recommendation: "Review and validate all form action URLs to ensure they point to your domain.",
  });

  // Mixed content
  checks.push({
    category: "security",
    name: "Mixed Content Check",
    description: mod > 70 ? "No mixed content (HTTP resources on HTTPS page) detected." : "Mixed content resources detected on the page.",
    status: mod > 70 ? "passed" : "warning",
    severity: mod > 70 ? "minor" : "warning",
    details: mod > 70 ? { mixedResources: 0 } : { mixedResources: 3 },
    recommendation: "Replace all HTTP resource URLs with HTTPS equivalents.",
  });

  return checks;
}

function buildSSLChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  checks.push({
    category: "ssl",
    name: "SSL Certificate Validity",
    description: mod > 10 ? "SSL certificate is valid and not expired." : "SSL certificate is expired or will expire soon.",
    status: mod > 10 ? "passed" : "failed",
    severity: mod > 10 ? "minor" : "critical",
    details: { expiresAt: mod > 10 ? "2026-03-15" : "2024-11-01", issuer: "Let's Encrypt" },
    recommendation: mod > 10 ? "Certificate is in good standing." : "Renew your SSL certificate immediately.",
  });

  checks.push({
    category: "ssl",
    name: "TLS Version",
    description: mod > 25 ? "Server supports TLS 1.2 or higher." : "Server is using an outdated TLS version.",
    status: mod > 25 ? "passed" : "failed",
    severity: mod > 25 ? "minor" : "critical",
    details: { version: mod > 25 ? "TLS 1.3" : "TLS 1.0" },
    recommendation: "Upgrade your server to support TLS 1.2 minimum. Disable TLS 1.0 and 1.1.",
  });

  checks.push({
    category: "ssl",
    name: "Certificate Chain Completeness",
    description: mod > 40 ? "Certificate chain is complete and trusted." : "Certificate chain is incomplete or uses a self-signed certificate.",
    status: mod > 40 ? "passed" : "warning",
    severity: mod > 40 ? "minor" : "warning",
    details: { chainValid: mod > 40 },
    recommendation: mod > 40 ? "" : "Install the full certificate chain from your CA.",
  });

  return checks;
}

function buildPerformanceChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  const lcp = mod > 60 ? 1.8 : 4.2;
  const fid = mod > 50 ? 45 : 220;
  const cls = mod > 70 ? 0.05 : 0.35;

  checks.push({
    category: "performance",
    name: "Largest Contentful Paint (LCP)",
    description: `LCP is ${lcp}s. ${lcp <= 2.5 ? "Within good threshold." : "Exceeds the 2.5s threshold."}`,
    status: lcp <= 2.5 ? "passed" : "failed",
    severity: lcp <= 2.5 ? "minor" : lcp <= 4.0 ? "warning" : "critical",
    details: { value: lcp, threshold: 2.5, unit: "seconds" },
    recommendation: lcp <= 2.5 ? "LCP is performing well." : "Optimize hero images, server response times, and render-blocking resources.",
  });

  checks.push({
    category: "performance",
    name: "First Input Delay (FID)",
    description: `FID is ${fid}ms. ${fid <= 100 ? "Within good threshold." : "Exceeds the 100ms threshold."}`,
    status: fid <= 100 ? "passed" : "warning",
    severity: fid <= 100 ? "minor" : "warning",
    details: { value: fid, threshold: 100, unit: "ms" },
    recommendation: fid <= 100 ? "FID is performing well." : "Reduce main-thread work and break up long tasks.",
  });

  checks.push({
    category: "performance",
    name: "Cumulative Layout Shift (CLS)",
    description: `CLS is ${cls}. ${cls <= 0.1 ? "Within good threshold." : "Exceeds the 0.1 threshold."}`,
    status: cls <= 0.1 ? "passed" : "failed",
    severity: cls <= 0.1 ? "minor" : cls <= 0.25 ? "warning" : "critical",
    details: { value: cls, threshold: 0.1 },
    recommendation: cls <= 0.1 ? "CLS is performing well." : "Add explicit size attributes to images/videos and avoid dynamic content injection above the fold.",
  });

  checks.push({
    category: "performance",
    name: "Page Size",
    description: `Total page size is ${mod > 50 ? "1.8" : "5.4"} MB.`,
    status: mod > 50 ? "passed" : "warning",
    severity: mod > 50 ? "minor" : "warning",
    details: { sizeMb: mod > 50 ? 1.8 : 5.4, thresholdMb: 3 },
    recommendation: mod > 50 ? "Page size is reasonable." : "Compress images, enable text compression, and lazy-load off-screen resources.",
  });

  checks.push({
    category: "performance",
    name: "Render-Blocking Resources",
    description: mod > 35 ? "No critical render-blocking resources detected." : "Render-blocking CSS/JS files are delaying page render.",
    status: mod > 35 ? "passed" : "warning",
    severity: mod > 35 ? "minor" : "warning",
    details: { blockingResources: mod > 35 ? 0 : 3 },
    recommendation: "Inline critical CSS, defer non-essential JS, and use the `preload` hint.",
  });

  return checks;
}

function buildSEOChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  checks.push({
    category: "seo",
    name: "Meta Title Tag",
    description: mod > 15 ? "Page has a descriptive <title> tag (52 characters)." : "Page is missing a <title> tag or it is too short/long.",
    status: mod > 15 ? "passed" : "failed",
    severity: mod > 15 ? "minor" : "warning",
    details: { length: mod > 15 ? 52 : 0, optimal: "30-60 chars" },
    recommendation: mod > 15 ? "Title length is optimal." : "Add a descriptive <title> tag between 30-60 characters.",
  });

  checks.push({
    category: "seo",
    name: "Meta Description",
    description: mod > 25 ? "Page has a meta description (155 characters)." : "Missing meta description tag.",
    status: mod > 25 ? "passed" : "warning",
    severity: mod > 25 ? "minor" : "warning",
    details: { length: mod > 25 ? 155 : 0, optimal: "120-160 chars" },
    recommendation: mod > 25 ? "Meta description is optimal." : "Add a compelling meta description between 120-160 characters.",
  });

  checks.push({
    category: "seo",
    name: "Open Graph Tags",
    description: mod > 40 ? "Essential Open Graph tags are present." : "Missing og:title, og:description, or og:image.",
    status: mod > 40 ? "passed" : "warning",
    severity: mod > 40 ? "minor" : "minor",
    details: { ogTitle: mod > 40, ogDescription: mod > 40, ogImage: mod > 60 },
    recommendation: "Add Open Graph tags for better social media sharing.",
  });

  checks.push({
    category: "seo",
    name: "Canonical URL",
    description: mod > 55 ? "Canonical URL is properly set." : "No canonical URL found — risk of duplicate content.",
    status: mod > 55 ? "passed" : "warning",
    severity: mod > 55 ? "minor" : "warning",
    details: { hasCanonical: mod > 55 },
    recommendation: 'Add a <link rel="canonical"> tag to prevent duplicate content issues.',
  });

  checks.push({
    category: "seo",
    name: "Heading Hierarchy",
    description: mod > 45 ? "Proper heading hierarchy with a single H1." : "Missing H1 tag or heading hierarchy is broken.",
    status: mod > 45 ? "passed" : "failed",
    severity: mod > 45 ? "minor" : "warning",
    details: { h1Count: mod > 45 ? 1 : 0 },
    recommendation: "Ensure there is exactly one <h1> tag per page and headings follow a logical hierarchy.",
  });

  return checks;
}

function buildMobileChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  checks.push({
    category: "mobile",
    name: "Viewport Meta Tag",
    description: mod > 20 ? "Viewport meta tag is correctly configured." : "Missing viewport meta tag.",
    status: mod > 20 ? "passed" : "failed",
    severity: mod > 20 ? "minor" : "critical",
    details: { hasViewport: mod > 20 },
    recommendation: mod > 20 ? '' : 'Add <meta name="viewport" content="width=device-width, initial-scale=1">.',
  });

  checks.push({
    category: "mobile",
    name: "Touch Target Size",
    description: mod > 50 ? "All interactive elements meet minimum 44x44px touch target." : "Some touch targets are smaller than the 44px minimum.",
    status: mod > 50 ? "passed" : "warning",
    severity: mod > 50 ? "minor" : "warning",
    details: { smallTargets: mod > 50 ? 0 : 4 },
    recommendation: "Increase touch target sizes to at least 44x44 pixels for mobile usability.",
  });

  checks.push({
    category: "mobile",
    name: "Mobile-Friendly Content",
    description: mod > 35 ? "Content is readable without horizontal scrolling." : "Content overflows the viewport on mobile devices.",
    status: mod > 35 ? "passed" : "warning",
    severity: mod > 35 ? "minor" : "warning",
    details: { overflowDetected: mod <= 35 },
    recommendation: "Use responsive layouts (flexbox/grid) and relative units (%, vw, rem) instead of fixed widths.",
  });

  return checks;
}

function buildAccessibilityChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  checks.push({
    category: "accessibility",
    name: "Image Alt Text",
    description: mod > 40 ? "All images have appropriate alt attributes." : "Some images are missing alt text.",
    status: mod > 40 ? "passed" : "warning",
    severity: mod > 40 ? "minor" : "warning",
    details: { imagesWithoutAlt: mod > 40 ? 0 : 5, totalImages: 12 },
    recommendation: 'Add descriptive alt text to all meaningful images. Use empty alt="" for decorative images.',
  });

  checks.push({
    category: "accessibility",
    name: "ARIA Labels",
    description: mod > 55 ? "Interactive elements have proper ARIA labels." : "Some interactive elements lack ARIA labels.",
    status: mod > 55 ? "passed" : "warning",
    severity: mod > 55 ? "minor" : "minor",
    details: { elementsWithoutLabel: mod > 55 ? 0 : 3 },
    recommendation: "Add aria-label or aria-labelledby attributes to interactive elements.",
  });

  checks.push({
    category: "accessibility",
    name: "Color Contrast",
    description: mod > 30 ? "Text color contrast meets WCAG AA standards." : "Some text elements fail WCAG AA contrast requirements.",
    status: mod > 30 ? "passed" : "failed",
    severity: mod > 30 ? "minor" : "warning",
    details: { failedElements: mod > 30 ? 0 : 2, ratio: mod > 30 ? 4.8 : 2.1 },
    recommendation: "Ensure text has a contrast ratio of at least 4.5:1 against its background.",
  });

  return checks;
}

function buildContentChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  checks.push({
    category: "content",
    name: "Broken Links",
    description: mod > 50 ? "No broken links detected." : "Found broken links returning 404 errors.",
    status: mod > 50 ? "passed" : "warning",
    severity: mod > 50 ? "minor" : "warning",
    details: { brokenLinks: mod > 50 ? 0 : 3, totalLinks: 24 },
    recommendation: "Fix or remove broken links. Set up regular link monitoring.",
  });

  checks.push({
    category: "content",
    name: "Page Content Length",
    description: mod > 35 ? "Page has sufficient content for SEO." : "Page content is thin — may hurt search rankings.",
    status: mod > 35 ? "passed" : "warning",
    severity: mod > 35 ? "minor" : "minor",
    details: { wordCount: mod > 35 ? 850 : 120, recommended: 300 },
    recommendation: "Add more detailed content to improve SEO and user engagement.",
  });

  return checks;
}

function buildAnalyticsChecks(hash: number): ScanCheckItem[] {
  const mod = hash % 100;
  const checks: ScanCheckItem[] = [];

  checks.push({
    category: "analytics",
    name: "Analytics Tracking",
    description: mod > 30 ? "Analytics tracking code is properly installed." : "No analytics tracking code detected.",
    status: mod > 30 ? "passed" : "warning",
    severity: mod > 30 ? "minor" : "warning",
    details: { hasAnalytics: mod > 30, provider: mod > 60 ? "Google Analytics 4" : "None" },
    recommendation: "Install a web analytics tool (Google Analytics, Plausible, etc.) to track visitor behavior.",
  });

  checks.push({
    category: "analytics",
    name: "Conversion Tracking",
    description: mod > 65 ? "E-commerce conversion tracking is configured." : "No e-commerce event tracking detected (add_to_cart, purchase, etc.).",
    status: mod > 65 ? "passed" : "warning",
    severity: mod > 65 ? "minor" : "minor",
    details: { trackedEvents: mod > 65 ? ["view_item", "add_to_cart", "purchase"] : [] },
    recommendation: "Implement e-commerce event tracking for key actions (product views, add to cart, checkout, purchase).",
  });

  return checks;
}

// ============================================================================
// Build Scan Summary
// ============================================================================

function buildSummary(checks: ScanCheckItem[]): ScanSummary {
  const summary: ScanSummary = {
    totalChecks: checks.length,
    passed: 0,
    warnings: 0,
    failed: 0,
    categories: {} as Record<ScanCheckCategory, CategorySummary>,
  };

  const allCategories: ScanCheckCategory[] = [
    "security", "performance", "seo", "accessibility",
    "mobile", "content", "analytics", "ssl",
  ];

  for (const cat of allCategories) {
    summary.categories[cat] = { total: 0, passed: 0, warnings: 0, failed: 0 };
  }

  for (const check of checks) {
    summary.totalChecks = checks.length;
    if (check.status === "passed") summary.passed++;
    else if (check.status === "warning") summary.warnings++;
    else if (check.status === "failed") summary.failed++;

    const catSummary = summary.categories[check.category]!;
    catSummary.total++;
    if (check.status === "passed") catSummary.passed++;
    else if (check.status === "warning") catSummary.warnings++;
    else if (check.status === "failed") catSummary.failed++;
  }

  return summary;
}

// ============================================================================
// Scanner Service
// ============================================================================

export interface IScannerService {
  /**
   * Scan a website URL and return a comprehensive result.
   *
   * @param url  - The HTTPS URL to scan.
   * @param categories - Optional subset of categories to check.
   *                         Defaults to SCAN_CONFIG.defaultCategories.
   * @throws ScannerError on invalid URL, blocked host, or timeout.
   */
  scanWebsite(
    url: string,
    categories?: ScanCheckCategory[],
  ): Promise<ScanResult>;
}

class ScannerServiceImpl implements IScannerService {
  private readonly timeoutMs: number;

  constructor(timeoutMs = SCAN_CONFIG.timeoutMs) {
    this.timeoutMs = timeoutMs;
  }

  async scanWebsite(
    url: string,
    categories: ScanCheckCategory[] = SCAN_CONFIG.defaultCategories,
  ): Promise<ScanResult> {
    // 1. Validate URL
    const parsed = validateUrl(url);
    const storeUrl = parsed.origin;
    const storeName = parsed.hostname.replace(/^www\./, "");

    // 2. Fetch with timeout (real HTTP request to verify the site exists)
    let response: Response;
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.timeoutMs);

      response = await fetch(storeUrl, {
        method: "GET",
        signal: controller.signal,
        redirect: "follow",
        headers: {
          "User-Agent": "StoreGuard/1.0 (Health Monitor; +https://storeguard.dev)",
          Accept: "text/html,application/xhtml+xml",
        },
      });

      clearTimeout(timer);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") {
        throw new ScannerError(
          `Scan timed out after ${this.timeoutMs / 1000}s.`,
          "TIMEOUT",
        );
      }
      throw new ScannerError(
        `Failed to fetch ${storeUrl}: ${err instanceof Error ? err.message : "Unknown error"}.`,
        "FETCH_FAILED",
      );
    }

    if (!response.ok) {
      throw new ScannerError(
        `Site returned HTTP ${response.status}. Expected a 2xx response.`,
        "FETCH_FAILED",
      );
    }

    const startTime = Date.now();

    // 3. Generate demo checks (deterministic based on URL)
    const checks = generateDemoChecks(storeUrl, categories);

    // 4. Build summary
    const summary = buildSummary(checks);

    // 5. Calculate health score
    const { score } = calculateHealthScore(checks);

    const durationMs = Date.now() - startTime;

    return {
      id: crypto.randomUUID(),
      storeUrl,
      storeName,
      scannedAt: new Date(),
      durationMs,
      checks,
      healthScore: score,
      summary,
    };
  }
}

// ============================================================================
// Singleton Export
// ============================================================================

export const scannerService: IScannerService = new ScannerServiceImpl();
