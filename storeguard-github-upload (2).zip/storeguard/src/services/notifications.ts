import type { ScanResult, Notification, NotificationPreference, NotificationChannel, Store } from '@/types';
import { supabase } from '@/services/supabase';
import { formatDate } from '@/lib/utils';

// ============================================================================
// Errors
// ============================================================================

export class NotificationError extends Error {
  constructor(
    message: string,
    public readonly code:
      | 'PREFERENCE_NOT_FOUND'
      | 'SEND_FAILED'
      | 'RATE_LIMITED'
      | 'INTERNAL',
  ) {
    super(message);
    this.name = 'NotificationError';
  }
}

// ============================================================================
// Interface
// ============================================================================

export interface INotificationService {
  /** Send a daily scan report summary to the user. */
  sendDailyReport(userId: string, stores: Array<{ store: Store; result: ScanResult | null }>): Promise<void>;

  /** Send an immediate alert for a critical issue. */
  sendCriticalAlert(userId: string, store: Store, scanResult: ScanResult): Promise<void>;

  /** Send a weekly performance summary. */
  sendWeeklySummary(userId: string, stores: Array<{ store: Store; results: ScanResult[] }>): Promise<void>;

  /** Save an in-app notification to the database. */
  saveNotification(notification: Omit<Notification, 'id' | 'createdAt' | 'isRead'>): Promise<Notification>;

  /** Get user notification preferences. */
  getPreferences(userId: string): Promise<NotificationPreference[]>;

  /** Update a user notification preference. */
  updatePreference(userId: string, channel: NotificationChannel, eventType: string, enabled: boolean): Promise<void>;
}

// ============================================================================
// Email Service Abstraction
// ============================================================================

/**
 * Abstraction for sending emails.
 * Swap the implementation when integrating Resend, SendGrid, etc.
 */
export interface IEmailService {
  send(params: EmailParams): Promise<void>;
}

export interface EmailParams {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

/**
 * No-op email service for development.
 * Logs email content instead of sending.
 */
class NoOpEmailService implements IEmailService {
 async send(params: EmailParams): Promise<void> {
    console.log(`
┌──────────────────────────────────────────────┐
│ 📧 EMAIL (no-op / development mode)          │
├──────────────────────────────────────────────┤
│ To:      ${params.to}
│ Subject: ${params.subject}
├──────────────────────────────────────────────┤
${params.text ?? params.html.split('<').join('\n  <')}
└──────────────────────────────────────────────┘
    `.trim());
  }
}

/**
 * Resend email service (for production).
 * Activated when RESEND_API_KEY is set.
 */
class ResendEmailService implements IEmailService {
  constructor() {
    // Server-side only: VITE_RESEND_API_KEY env var
    const apiKey = (import.meta.env as Record<string, string | undefined>).VITE_RESEND_API_KEY;
    if (!apiKey) {
      console.warn('[ResendEmailService] VITE_RESEND_API_KEY is not configured. Emails will be logged only.');
    }
  }

  async send(params: EmailParams): Promise<void> {
    // Placeholder: Resend SDK is not bundled in client code.
    // In production, this would dynamically import Resend and send the email.
    console.warn('[ResendEmailService] Resend SDK not available in client bundle. Falling back to no-op.');
    return new NoOpEmailService().send(params);
  }
}

// ============================================================================
// Email Service Factory
// ============================================================================

function createEmailService(): IEmailService {
  // Server-side only: VITE_RESEND_API_KEY env var
  if ((import.meta.env as Record<string, string | undefined>).VITE_RESEND_API_KEY) {
    return new ResendEmailService();
  }
  return new NoOpEmailService();
}

// ============================================================================
// Preference Helpers
// ============================================================================

/**
 * Check if a user has a specific notification enabled.
 * Falls back to `true` if no preference is stored (opt-out model).
 */
async function isNotificationEnabled(
  userId: string,
  channel: NotificationChannel,
  eventType: string,
  existingPreferences?: NotificationPreference[],
): Promise<boolean> {
  const prefs =
    existingPreferences ?? (await fetchPreferencesFromDb(userId));

  const match = prefs.find(
    (p) => p.channel === channel && p.eventType === eventType,
  );

  // Default to enabled if no explicit preference exists
  return match ? match.enabled : true;
}

async function fetchPreferencesFromDb(userId: string): Promise<NotificationPreference[]> {
  try {
    const { data, error } = await supabase
      .from('notification_preferences')
      .select('*')
      .eq('user_id', userId);

    if (error || !data) return [];

    return data.map((row) => ({
      id: row.id,
      userId: row.user_id,
      channel: row.channel,
      eventType: row.event_type,
      enabled: row.enabled,
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at),
    }));
  } catch {
    // If Supabase is not available (dev mode), return defaults
    return [];
  }
}

// ============================================================================
// Template Helpers
// ============================================================================

function buildDailyReportHtml(
  stores: Array<{ store: Store; result: ScanResult | null }>,
): string {
  const rows = stores
    .map(({ store, result }) => {
      const score = result?.healthScore ?? '—';
      const status = result ? '✅ Scanned' : '⚠️ Not scanned';
      const passed = result?.summary.passed ?? 0;
      const failed = result?.summary.failed ?? 0;
      const warnings = result?.summary.warnings ?? 0;

      return `
        <tr>
          <td style="padding: 8px 12px; border-bottom: 1px solid #e5e7eb;">${store.name}</td>
          <td style="padding: 8px 12px; border-bottom: 1px solid #e5e7eb; text-align: center; font-weight: 600;">${score}</td>
          <td style="padding: 8px 12px; border-bottom: 1px solid #e5e7eb;">${status}</td>
          <td style="padding: 8px 12px; border-bottom: 1px solid #e5e7eb; text-align: center;">✅ ${passed}  ⚠️ ${warnings}  ❌ ${failed}</td>
        </tr>
      `.trim();
    })
    .join('');

  const today = formatDate(new Date());

  return `
    <div style="font-family: system-ui, -apple-system, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #111827; font-size: 20px;">StoreGuard Daily Report</h1>
      <p style="color: #6b7280;">${today}</p>
      <table style="width: 100%; border-collapse: collapse; margin-top: 16px;">
        <thead>
          <tr style="background: #f9fafb;">
            <th style="padding: 8px 12px; text-align: left; border-bottom: 2px solid #e5e7eb;">Store</th>
            <th style="padding: 8px 12px; text-align: center; border-bottom: 2px solid #e5e7eb;">Score</th>
            <th style="padding: 8px 12px; text-align: left; border-bottom: 2px solid #e5e7eb;">Status</th>
            <th style="padding: 8px 12px; text-align: center; border-bottom: 2px solid #e5e7eb;">Results</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
      <p style="margin-top: 24px; color: #9ca3af; font-size: 12px;">You are receiving this because you have daily reports enabled in your notification preferences.</p>
    </div>
  `.trim();
}

function buildCriticalAlertHtml(store: Store, scanResult: ScanResult): string {
  const criticalChecks = scanResult.checks.filter(
    (c) => c.severity === 'critical' && c.status === 'failed',
  );

  const items = criticalChecks
    .map(
      (c) => `
      <li style="margin-bottom: 12px; padding: 12px; background: #fef2f2; border-left: 4px solid #ef4444; border-radius: 4px;">
        <strong style="color: #991b1b;">${c.name}</strong>
        <p style="color: #6b7280; margin: 4px 0;">${c.description}</p>
        <p style="color: #374151; font-size: 14px;"><em>Recommendation:</em> ${c.recommendation}</p>
      </li>
    `.trim(),
    )
    .join('');

  return `
    <div style="font-family: system-ui, -apple-system, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: #fef2f2; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
        <h1 style="color: #991b1b; font-size: 20px; margin: 0;">⚠️ Critical Issues Detected</h1>
        <p style="color: #b91c1c; margin: 4px 0 0;">${store.name} — Health Score: ${scanResult.healthScore}/100</p>
      </div>
      <p style="color: #374151;">${criticalChecks.length} critical issue${criticalChecks.length !== 1 ? 's were' : ' was'} found during the latest scan:</p>
      <ul style="list-style: none; padding: 0; margin: 16px 0;">${items}</ul>
      <p style="color: #6b7280; font-size: 14px;">We recommend addressing these issues immediately to protect your store and customers.</p>
    </div>
  `.trim();
}

function buildWeeklySummaryHtml(
  stores: Array<{ store: Store; results: ScanResult[] }>,
): string {
  const storeBlocks = stores
    .map(({ store, results }) => {
      if (results.length === 0) {
        return `
          <div style="margin-bottom: 24px;">
            <h3 style="color: #111827;">${store.name}</h3>
            <p style="color: #9ca3af;">No scans were performed this week.</p>
          </div>
        `.trim();
      }

      const scores = results.map((r) => r.healthScore);
      const avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
      const bestScore = Math.max(...scores);
      const worstScore = Math.min(...scores);

      return `
        <div style="margin-bottom: 24px;">
          <h3 style="color: #111827;">${store.name}</h3>
          <p style="color: #6b7280;">${results.length} scan${results.length !== 1 ? 's' : ''} this week</p>
          <div style="display: flex; gap: 16px; margin-top: 8px;">
            <div style="background: #f0fdf4; padding: 12px; border-radius: 6px; flex: 1; text-align: center;">
              <div style="font-size: 24px; font-weight: 700; color: #16a34a;">${avgScore}</div>
              <div style="color: #6b7280; font-size: 12px;">Avg Score</div>
            </div>
            <div style="background: #f0fdf4; padding: 12px; border-radius: 6px; flex: 1; text-align: center;">
              <div style="font-size: 24px; font-weight: 700; color: #16a34a;">${bestScore}</div>
              <div style="color: #6b7280; font-size: 12px;">Best</div>
            </div>
            <div style="background: ${worstScore < 60 ? '#fef2f2' : '#f0fdf4'}; padding: 12px; border-radius: 6px; flex: 1; text-align: center;">
              <div style="font-size: 24px; font-weight: 700; color: ${worstScore < 60 ? '#dc2626' : '#16a34a'};">${worstScore}</div>
              <div style="color: #6b7280; font-size: 12px;">Worst</div>
            </div>
          </div>
        </div>
      `.trim();
    })
    .join('');

  return `
    <div style="font-family: system-ui, -apple-system, sans-serif; max-width: 600px; margin: 0 auto;">
      <h1 style="color: #111827; font-size: 20px;">📊 Weekly Performance Summary</h1>
      <p style="color: #6b7280;">${formatDate(new Date())}</p>
      <div style="margin-top: 24px;">${storeBlocks}</div>
    </div>
  `.trim();
}

// ============================================================================
// Notification Service Implementation
// ============================================================================

class NotificationServiceImpl implements INotificationService {
  private readonly emailService: IEmailService;

  constructor(emailService?: IEmailService) {
    this.emailService = emailService ?? createEmailService();
  }

  // --------------------------------------------------------------------------
  // sendDailyReport
  // --------------------------------------------------------------------------

  async sendDailyReport(
    userId: string,
    stores: Array<{ store: Store; result: ScanResult | null }>,
  ): Promise<void> {
    const emailEnabled = await isNotificationEnabled(
      userId,
      'email',
      'scan_completed',
    );

    if (emailEnabled) {
      // Look up user email from Supabase (or pass it in)
      const { data: profile } = await supabase
        .from('profiles')
        .select('email')
        .eq('user_id', userId)
        .single();

      const toEmail = profile?.email;
      if (toEmail) {
        await this.emailService.send({
          to: toEmail,
          subject: `StoreGuard Daily Report — ${formatDate(new Date())}`,
          html: buildDailyReportHtml(stores),
          text: `Your StoreGuard daily report is ready. ${stores.length} store(s) monitored.`,
        });
      }
    }

    // Save in-app notification
    await this.saveNotification({
      userId,
      storeId: null,
      type: 'daily_report',
      title: 'Daily Report Ready',
      message: `Your daily scan report for ${stores.length} store(s) is available.`,
      actionUrl: '/dashboard',
      metadata: { storeCount: stores.length },
    });
  }

  // --------------------------------------------------------------------------
  // sendCriticalAlert
  // --------------------------------------------------------------------------

  async sendCriticalAlert(
    userId: string,
    store: Store,
    scanResult: ScanResult,
  ): Promise<void> {
    const emailEnabled = await isNotificationEnabled(
      userId,
      'email',
      'critical_issue_found',
    );

    if (emailEnabled) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('email')
        .eq('user_id', userId)
        .single();

      const toEmail = profile?.email;
      if (toEmail) {
        await this.emailService.send({
          to: toEmail,
          subject: `⚠️ Critical Issues: ${store.name} (Score: ${scanResult.healthScore})`,
          html: buildCriticalAlertHtml(store, scanResult),
          text: `Critical issues detected on ${store.name}. Health score: ${scanResult.healthScore}/100.`,
        });
      }
    }

    // Save in-app notification
    const criticalCount = scanResult.checks.filter(
      (c) => c.severity === 'critical' && c.status === 'failed',
    ).length;

    await this.saveNotification({
      userId,
      storeId: store.id,
      type: 'critical_alert',
      title: `Critical Issues: ${store.name}`,
      message: `${criticalCount} critical issue${criticalCount !== 1 ? 's' : ''} detected. Health score dropped to ${scanResult.healthScore}/100.`,
      actionUrl: `/stores/${store.id}`,
      metadata: {
        storeId: store.id,
        score: scanResult.healthScore,
        criticalCount,
      },
    });
  }

  // --------------------------------------------------------------------------
  // sendWeeklySummary
  // --------------------------------------------------------------------------

  async sendWeeklySummary(
    userId: string,
    stores: Array<{ store: Store; results: ScanResult[] }>,
  ): Promise<void> {
    const emailEnabled = await isNotificationEnabled(
      userId,
      'email',
      'weekly_summary',
    );

    if (emailEnabled) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('email')
        .eq('user_id', userId)
        .single();

      const toEmail = profile?.email;
      if (toEmail) {
        await this.emailService.send({
          to: toEmail,
          subject: `📊 Weekly Summary — ${formatDate(new Date())}`,
          html: buildWeeklySummaryHtml(stores),
          text: 'Your weekly StoreGuard performance summary is ready.',
        });
      }
    }

    // Save in-app notification
    await this.saveNotification({
      userId,
      storeId: null,
      type: 'weekly_summary',
      title: 'Weekly Summary Ready',
      message: `Your weekly performance summary for ${stores.length} store(s) is available.`,
      actionUrl: '/dashboard',
      metadata: { storeCount: stores.length },
    });
  }

  // --------------------------------------------------------------------------
  // saveNotification (in-app)
  // --------------------------------------------------------------------------

  async saveNotification(
    notification: Omit<Notification, 'id' | 'createdAt' | 'isRead'>,
  ): Promise<Notification> {
    const now = new Date();
    const id = crypto.randomUUID();

    try {
      await supabase.from('notifications').insert({
        id,
        user_id: notification.userId,
        store_id: notification.storeId,
        type: notification.type,
        title: notification.title,
        message: notification.message,
        is_read: false,
        action_url: notification.actionUrl,
        metadata: notification.metadata,
      });
    } catch {
      // If Supabase insert fails (dev mode), continue silently
      console.warn('[NotificationService] Failed to save notification to database.');
    }

    return {
      id,
      userId: notification.userId,
      storeId: notification.storeId,
      type: notification.type,
      title: notification.title,
      message: notification.message,
      isRead: false,
      actionUrl: notification.actionUrl,
      metadata: notification.metadata,
      createdAt: now,
    };
  }

  // --------------------------------------------------------------------------
  // getPreferences
  // --------------------------------------------------------------------------

  async getPreferences(userId: string): Promise<NotificationPreference[]> {
    return fetchPreferencesFromDb(userId);
  }

  // --------------------------------------------------------------------------
  // updatePreference
  // --------------------------------------------------------------------------

  async updatePreference(
    userId: string,
    channel: NotificationChannel,
    eventType: string,
    enabled: boolean,
  ): Promise<void> {
    try {
      // Upsert: update if exists, insert if not
      const { data: existing } = await supabase
        .from('notification_preferences')
        .select('id')
        .eq('user_id', userId)
        .eq('channel', channel)
        .eq('event_type', eventType)
        .single();

      if (existing) {
        await supabase
          .from('notification_preferences')
          .update({ enabled, updated_at: new Date().toISOString() })
          .eq('id', existing.id);
      } else {
        await supabase.from('notification_preferences').insert({
          user_id: userId,
          channel,
          event_type: eventType,
          enabled,
        });
      }
    } catch {
      console.warn('[NotificationService] Failed to update preference in database.');
    }
  }
}

// ============================================================================
// Singleton Export
// ============================================================================

export const notificationService: INotificationService =
  new NotificationServiceImpl();
