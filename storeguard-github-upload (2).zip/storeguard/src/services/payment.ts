import type { Payment, Subscription, SubscriptionPlan } from "@/types";
import { getPlanById } from "@/config/pricing";

// ============================================================================
// Errors
// ============================================================================

export class PaymentError extends Error {
  constructor(
    message: string,
    public readonly code:
      | "INVALID_PLAN"
      | "PAYMENT_FAILED"
      | "NOT_FOUND"
      | "ALREADY_ACTIVE"
      | "PROVIDER_ERROR"
      | "VERIFICATION_FAILED"
      | "INTERNAL",
  ) {
    super(message);
    this.name = "PaymentError";
  }
}

// ============================================================================
// Interface
// ============================================================================

export interface IPaymentService {
  /** Create a new payment intent / record. */
  createPayment(params: CreatePaymentParams): Promise<Payment>;

  /** Verify a payment (e.g., webhook from Stripe or manual code). */
  verifyPayment(params: VerifyPaymentParams): Promise<Payment>;

  /** Activate a subscription after successful payment. */
  activateSubscription(params: ActivateSubscriptionParams): Promise<Subscription>;
}

// ============================================================================
// Parameter Types
// ============================================================================

export interface CreatePaymentParams {
  userId: string;
  plan: SubscriptionPlan;
  provider?: "stripe" | "manual";
}

export interface VerifyPaymentParams {
  paymentId: string;
  /**
   * For Stripe: the webhook signature / event ID.
   * For manual: a verification code entered by an admin.
   */
  providerVerificationCode?: string;
}

export interface ActivateSubscriptionParams {
  userId: string;
  plan: SubscriptionPlan;
  paymentId: string;
}

// ============================================================================
// Period Helpers
// ============================================================================

function getPeriodEnd(plan: SubscriptionPlan, startDate: Date = new Date()): Date {
  const end = new Date(startDate);
  switch (plan) {
    case "daily":
      end.setDate(end.getDate() + 1);
      break;
    case "monthly":
      end.setMonth(end.getMonth() + 1);
      break;
    case "yearly":
      end.setFullYear(end.getFullYear() + 1);
      break;
  }
  return end;
}

// ============================================================================
// Payment Service Implementation (MVP — Manual / Stub)
// ============================================================================

/**
 * In-memory store for demo / MVP purposes.
 * In production, all state lives in Supabase / Stripe.
 */
const payments = new Map<string, Payment>();
const subscriptions = new Map<string, Subscription>();

/** Pending manual verification codes (code → paymentId). */
const pendingVerifications = new Map<string, string>();

class PaymentServiceImpl implements IPaymentService {
  // --------------------------------------------------------------------------
  // createPayment
  // --------------------------------------------------------------------------

  async createPayment(params: CreatePaymentParams): Promise<Payment> {
    const planConfig = getPlanById(params.plan);
    if (!planConfig) {
      throw new PaymentError(
        `Unknown plan: ${params.plan}`,
        "INVALID_PLAN",
      );
    }

    const provider = params.provider ?? "manual";
    const now = new Date();

    const payment: Payment = {
      id: crypto.randomUUID(),
      userId: params.userId,
      subscriptionId: null,
      amount: planConfig.priceCents / 100,
      currency: "USD",
      status: "pending",
      provider,
      providerPaymentId: provider === "stripe" ? `pi_demo_${crypto.randomUUID().slice(0, 8)}` : null,
      description: `${planConfig.name} plan (${planConfig.interval})`,
      metadata: { plan: params.plan },
      createdAt: now,
      updatedAt: now,
    };

    // For manual payments, generate a verification code
    if (provider === "manual") {
      const code = `SG-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
      pendingVerifications.set(code, payment.id);
      payment.metadata = { ...payment.metadata, verificationCode: code };
    }

    // TODO: In production, create a Stripe Checkout Session here
    // const session = await stripe.checkout.sessions.create({ ... });

    payments.set(payment.id, payment);
    return { ...payment };
  }

  // --------------------------------------------------------------------------
  // verifyPayment
  // --------------------------------------------------------------------------

  async verifyPayment(params: VerifyPaymentParams): Promise<Payment> {
    const existing = payments.get(params.paymentId);
    if (!existing) {
      throw new PaymentError(
        `Payment ${params.paymentId} not found`,
        "NOT_FOUND",
      );
    }

    if (existing.status === "completed") {
      return { ...existing };
    }

    const provider = existing.provider;

    if (provider === "manual") {
      // Manual verification: check the code
      if (!params.providerVerificationCode) {
        throw new PaymentError(
          "A verification code is required for manual payments",
          "VERIFICATION_FAILED",
        );
      }

      const matchedPaymentId = pendingVerifications.get(params.providerVerificationCode);
      if (matchedPaymentId !== existing.id) {
        throw new PaymentError(
          "Invalid verification code",
          "VERIFICATION_FAILED",
        );
      }

      pendingVerifications.delete(params.providerVerificationCode);
    }

    // TODO: For Stripe, verify the webhook signature here
    // const event = stripe.webhooks.constructEvent(body, sig, webhookSecret);

    const updated: Payment = {
      ...existing,
      status: "completed",
      updatedAt: new Date(),
    };

    payments.set(updated.id, updated);
    return { ...updated };
  }

  // --------------------------------------------------------------------------
  // activateSubscription
  // --------------------------------------------------------------------------

  async activateSubscription(
    params: ActivateSubscriptionParams,
  ): Promise<Subscription> {
    const planConfig = getPlanById(params.plan);
    if (!planConfig) {
      throw new PaymentError(
        `Unknown plan: ${params.plan}`,
        "INVALID_PLAN",
      );
    }

    // Verify payment was completed
    const payment = payments.get(params.paymentId);
    if (!payment || payment.status !== "completed") {
      throw new PaymentError(
        "Cannot activate subscription: payment not completed",
        "PAYMENT_FAILED",
      );
    }

    // Check for existing active subscription
    const existingSub = this.findActiveSubscription(params.userId);
    if (existingSub) {
      throw new PaymentError(
        `User already has an active ${existingSub.plan} subscription`,
        "ALREADY_ACTIVE",
      );
    }

    const now = new Date();
    const periodEnd = getPeriodEnd(params.plan, now);

    const subscription: Subscription = {
      id: crypto.randomUUID(),
      userId: params.userId,
      plan: params.plan,
      status: "active",
      currentPeriodStart: now,
      currentPeriodEnd: periodEnd,
      cancelAtPeriodEnd: false,
      stripeSubscriptionId: null, // Set by Stripe webhook in production
      createdAt: now,
      updatedAt: now,
    };

    // Link subscription to payment
    const updatedPayment: Payment = {
      ...payment,
      subscriptionId: subscription.id,
      updatedAt: now,
    };
    payments.set(updatedPayment.id, updatedPayment);

    subscriptions.set(subscription.id, subscription);
    return { ...subscription };
  }

  // --------------------------------------------------------------------------
  // Internal Helpers
  // --------------------------------------------------------------------------

  private findActiveSubscription(userId: string): Subscription | undefined {
    for (const sub of subscriptions.values()) {
      if (sub.userId === userId && sub.status === "active") {
        return sub;
      }
    }
    return undefined;
  }

  // --------------------------------------------------------------------------
  // Utility Methods (for admin / testing)
  // --------------------------------------------------------------------------

  /** Get a payment by ID (for admin review). */
  getPayment(paymentId: string): Payment | undefined {
    return payments.get(paymentId);
  }

  /** Get a subscription by user ID. */
  getSubscription(userId: string): Subscription | undefined {
    for (const sub of subscriptions.values()) {
      if (sub.userId === userId && sub.status === "active") {
        return sub;
      }
    }
    return undefined;
  }

  /** Get all payments for a user. */
  getUserPayments(userId: string): Payment[] {
    return Array.from(payments.values()).filter((p) => p.userId === userId);
  }

  /** Cancel a subscription at period end. */
  async cancelSubscription(
    subscriptionId: string,
  ): Promise<Subscription> {
    const sub = subscriptions.get(subscriptionId);
    if (!sub) {
      throw new PaymentError(
        `Subscription ${subscriptionId} not found`,
        "NOT_FOUND",
      );
    }

    if (sub.status !== "active") {
      throw new PaymentError(
        `Cannot cancel subscription in ${sub.status} status`,
        "INTERNAL",
      );
    }

    const updated: Subscription = {
      ...sub,
      cancelAtPeriodEnd: true,
      updatedAt: new Date(),
    };

    subscriptions.set(updated.id, updated);
    return { ...updated };
  }
}

// ============================================================================
// Singleton Export
// ============================================================================

export const paymentService: IPaymentService = new PaymentServiceImpl();
