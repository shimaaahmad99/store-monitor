import type { ScanResult, ScanCheckCategory, AIFeedback } from "@/types";
import { calculateHealthScore } from "@/lib/health-score";

// ============================================================================
// Error
// ============================================================================

export class AIAnalysisError extends Error {
  constructor(
    message: string,
    public readonly code: "API_KEY_MISSING" | "API_ERROR" | "PARSE_ERROR" | "FALLBACK",
  ) {
    super(message);
    this.name = "AIAnalysisError";
  }
}

// ============================================================================
// Interface
// ============================================================================

export interface IAIAnalysisService {
  /**
   * Generate AI-powered analysis and actionable feedback from a scan result.
   *
   * ⚠️  SERVER-SIDE ONLY — do not call from client components.
   *
   * When no AI API key is configured, a deterministic fallback analysis
   * is returned based on the scan data.
   */
  createAIAnalysis(scanResult: ScanResult): Promise<AIFeedback[]>;
}

// ============================================================================
// Deterministic Fallback Knowledge Base
// ============================================================================

interface FallbackTemplate {
  category: ScanCheckCategory;
  title: string;
  summary: string;
  priority: "high" | "medium" | "low";
  actionItems: string[];
  estimatedImpact: string;
  references: string[];
  triggerCheckNames: string[];
}

const FALLBACK_TEMPLATES: FallbackTemplate[] = [
  // --- Security ---
  {
    category: "security",
    title: "Strengthen Content Security Policy",
    summary:
      "Your store's Content Security Policy is missing or too permissive, leaving it vulnerable to XSS and code injection attacks.",
    priority: "high",
    actionItems: [
      "Add a Content-Security-Policy header with 'default-src \'self\'' as the baseline.",
      "Allow only trusted third-party domains (CDN, payment processor, analytics).",
      "Add 'upgrade-insecure-requests' to force HTTPS for all subresources.",
      "Test your CSP using the CSP Evaluator (https://csp-evaluator.withgoogle.com/).",
    ],
    estimatedImpact: "Reduces XSS attack surface by up to 80%. Prevents unauthorized script execution.",
    references: [
      "https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP",
      "https://web.dev/strict-csp/",
    ],
    triggerCheckNames: ["Content Security Policy"],
  },
  {
    category: "security",
    title: "Prevent Clickjacking with X-Frame-Options",
    summary:
      "Your store is missing the X-Frame-Options header, which allows attackers to embed your site in an iframe and trick users into performing unintended actions.",
    priority: "high",
    actionItems: [
      "Set X-Frame-Options to DENY or SAMEORIGIN in your server configuration.",
      "Also add frame-ancestors directive in your CSP for modern browser support.",
      "Verify the header using your browser's developer tools.",
    ],
    estimatedImpact: "Eliminates clickjacking risk. Protects customer sessions and payment flows.",
    references: [
      "https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Frame-Options",
    ],
    triggerCheckNames: ["X-Frame-Options Header"],
  },
  {
    category: "security",
    title: "Fix Mixed Content Issues",
    summary:
      "Your HTTPS site is loading some resources over HTTP, creating mixed content vulnerabilities and browser warnings.",
    priority: "medium",
    actionItems: [
      "Audit all <script>, <link>, <img>, and <iframe> tags for http:// URLs.",
      "Use protocol-relative URLs (//domain.com) or upgrade to https://.",
      "Add 'upgrade-insecure-requests' to your CSP header.",
      "Check third-party scripts and widgets for HTTP endpoints.",
    ],
    estimatedImpact: "Eliminates browser security warnings. Prevents man-in-the-middle attacks on subresources.",
    references: [
      "https://developer.mozilla.org/en-US/docs/Web/Security/Mixed_content",
    ],
    triggerCheckNames: ["Mixed Content Check"],
  },
  // --- SSL ---
  {
    category: "ssl",
    title: "Renew and Upgrade SSL Certificate",
    summary:
      "Your SSL certificate is expired or uses an outdated TLS version, putting customer data at risk and causing browser warnings.",
    priority: "high",
    actionItems: [
      "Renew your SSL certificate immediately using Let's Encrypt (free) or your CA.",
      "Set up automatic renewal with certbot or your hosting provider.",
      "Disable TLS 1.0 and 1.1. Require TLS 1.2+ on your server.",
      "Enable OCSP stapling for faster certificate verification.",
    ],
    estimatedImpact: "Restores secure connection. Eliminates 'Not Secure' browser warnings. Protects payment data.",
    references: [
      "https://letsencrypt.org/getting-started/",
      "https://ssl-config.mozilla.org/",
    ],
    triggerCheckNames: ["SSL Certificate Validity", "TLS Version"],
  },
  // --- Performance ---
  {
    category: "performance",
    title: "Optimize Largest Contentful Paint (LCP)",
    summary:
      "Your LCP is above the 2.5s threshold, meaning visitors see a blank screen for too long. This directly impacts conversions.",
    priority: "high",
    actionItems: [
      "Optimize your hero image: use WebP/AVIF format, compress, and set explicit dimensions.",
      "Serve images via a CDN with edge caching.",
      "Preload the LCP image resource: <link rel='preload' as='image'>.",
      "Reduce Time to First Byte (TTFB) by optimizing your server and database queries.",
    ],
    estimatedImpact: "Improves perceived load time by 40-60%. Each 100ms improvement in LCP can increase conversion by 0.7%.",
    references: [
      "https://web.dev/optimize-lcp/",
      "https://web.dev/lighthouse-largest-contentful-paint/",
    ],
    triggerCheckNames: ["Largest Contentful Paint (LCP)"],
  },
  {
    category: "performance",
    title: "Reduce Cumulative Layout Shift (CLS)",
    summary:
      "Your page has significant layout shifts, causing a jarring user experience and potentially leading to accidental clicks.",
    priority: "medium",
    actionItems: [
      "Add width and height attributes to all <img> and <video> elements.",
      "Reserve space for dynamic content (ads, widgets) using CSS aspect-ratio.",
      "Avoid inserting content above existing content after page load.",
      "Use font-display: optional or swap for web fonts to prevent FOIT/FOUT.",
    ],
    estimatedImpact: "Eliminates visual instability. Improves user trust and reduces accidental misclicks.",
    references: [
      "https://web.dev/optimize-cls/",
    ],
    triggerCheckNames: ["Cumulative Layout Shift (CLS)"],
  },
  {
    category: "performance",
    title: "Reduce Page Weight",
    summary:
      "Your page loads over 3 MB of data, which is excessive for e-commerce. This hurts mobile users and those on slow connections.",
    priority: "medium",
    actionItems: [
      "Compress all images using WebP/AVIF — target 70% size reduction.",
      "Enable Brotli or Gzip text compression on your server.",
      "Lazy-load images and iframes below the fold.",
      "Audit third-party scripts — each one adds weight and blocks rendering.",
    ],
    estimatedImpact: "Reduces page weight by 50-70%. Dramatically faster load on mobile and 3G connections.",
    references: [
      "https://web.dev/fast/#optimize-your-images",
    ],
    triggerCheckNames: ["Page Size"],
  },
  // --- SEO ---
  {
    category: "seo",
    title: "Improve Meta Tags for Search Visibility",
    summary:
      "Your store is missing critical meta tags (title, description, Open Graph), which reduces click-through rates from search results and social media.",
    priority: "medium",
    actionItems: [
      "Add a unique <title> tag (30-60 characters) for every page.",
      "Write compelling meta descriptions (120-160 characters) with CTAs.",
      "Add Open Graph tags (og:title, og:description, og:image) for social sharing.",
      "Add a <link rel='canonical'> tag to prevent duplicate content.",
    ],
    estimatedImpact: "Can improve organic CTR by 20-30%. Better social media preview appearance.",
    references: [
      "https://developers.google.com/search/docs/appearance/title-link",
      "https://ogp.me/",
    ],
    triggerCheckNames: [
      "Meta Title Tag",
      "Meta Description",
      "Open Graph Tags",
      "Canonical URL",
    ],
  },
  // --- Mobile ---
  {
    category: "mobile",
    title: "Fix Mobile Usability Issues",
    summary:
      "Your store has mobile usability problems (viewport, touch targets, content overflow) that frustrate mobile shoppers — who make up 60-70% of e-commerce traffic.",
    priority: "high",
    actionItems: [
      "Add <meta name='viewport' content='width=device-width, initial-scale=1'>.",
      "Ensure all buttons and links have a minimum touch target of 44x44px.",
      "Replace fixed-width layouts with responsive flexbox/grid.",
      "Test on real devices using BrowserStack or your physical devices.",
    ],
    estimatedImpact: "Mobile revenue can increase 20-40% after fixing usability issues. Google also uses mobile-first indexing.",
    references: [
      "https://developers.google.com/search/docs/appearance/mobile-friendly",
    ],
    triggerCheckNames: [
      "Viewport Meta Tag",
      "Touch Target Size",
      "Mobile-Friendly Content",
    ],
  },
  // --- Accessibility ---
  {
    category: "accessibility",
    title: "Improve Accessibility Compliance",
    summary:
      "Your store has accessibility gaps (missing alt text, low contrast, missing ARIA labels) that exclude users with disabilities and risk legal liability.",
    priority: "medium",
    actionItems: [
      "Add descriptive alt text to all images. Use empty alt='' for decorative images.",
      "Ensure text has at least 4.5:1 contrast ratio against its background.",
      "Add aria-label to interactive elements that lack visible text labels.",
      "Run an automated audit using Lighthouse or axe-core.",
    ],
    estimatedImpact: "Expands your customer base. Reduces legal risk under ADA/EAA. Improves SEO as a side benefit.",
    references: [
      "https://www.w3.org/WAI/WCAG21/quickref/",
      "https://developer.mozilla.org/en-US/docs/Web/Accessibility",
    ],
    triggerCheckNames: [
      "Image Alt Text",
      "Color Contrast",
      "ARIA Labels",
    ],
  },
  // --- Analytics ---
  {
    category: "analytics",
    title: "Set Up E-commerce Analytics",
    summary:
      "Without proper analytics and conversion tracking, you're flying blind on what's working and what's not in your store.",
    priority: "low",
    actionItems: [
      "Install Google Analytics 4 or a privacy-friendly alternative (Plausible, Fathom).",
      "Track key e-commerce events: view_item, add_to_cart, begin_checkout, purchase.",
      "Set up a conversion funnel report to identify drop-off points.",
      "Enable enhanced e-commerce tracking for product impressions and promotions.",
    ],
    estimatedImpact: "Data-driven decisions can increase revenue 15-25% by identifying and fixing conversion bottlenecks.",
    references: [
      "https://developers.google.com/analytics/devguides/collection/ga4/ecommerce",
    ],
    triggerCheckNames: [
      "Analytics Tracking",
      "Conversion Tracking",
    ],
  },
  // --- Content ---
  {
    category: "content",
    title: "Fix Broken Links and Thin Content",
    summary:
      "Broken links frustrate visitors and hurt SEO rankings. Thin content pages fail to rank and provide little value.",
    priority: "medium",
    actionItems: [
      "Run a link audit using Screaming Frog or Ahrefs to find all 404s.",
      "Redirect broken URLs to the most relevant live page (301 redirect).",
      "Expand thin content pages to at least 300 words with valuable information.",
      "Set up regular link monitoring to catch new 404s quickly.",
    ],
    estimatedImpact: "Fixing 404s can recover lost link equity and improve crawl efficiency. Thicker content improves rankings.",
    references: [
      "https://developers.google.com/search/docs/crawling-indexing/301-redirects",
    ],
    triggerCheckNames: ["Broken Links", "Page Content Length"],
  },
];

// ============================================================================
// Fallback Analysis Engine
// ============================================================================

function generateFallbackAnalysis(scanResult: ScanResult): AIFeedback[] {
  const feedback: AIFeedback[] = [];
  const failedCheckNames = new Set(
    scanResult.checks
      .filter((c) => c.status === "failed" || c.status === "warning")
      .map((c) => c.name),
  );

  for (const template of FALLBACK_TEMPLATES) {
    // Only include templates where at least one trigger check failed
    const hasTrigger = template.triggerCheckNames.some((name) =>
      failedCheckNames.has(name),
    );

    if (hasTrigger) {
      feedback.push({
        id: crypto.randomUUID(),
        category: template.category,
        title: template.title,
        summary: template.summary,
        priority: template.priority,
        actionItems: template.actionItems,
        estimatedImpact: template.estimatedImpact,
        references: template.references,
      });
    }
  }

  // Sort by priority: high → medium → low
  const priorityOrder = { high: 0, medium: 1, low: 2 };
  feedback.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

  // If the store is in great shape, add a positive summary
  if (feedback.length === 0) {
    const { score } = calculateHealthScore(scanResult.checks);
    feedback.push({
      id: crypto.randomUUID(),
      category: "security",
      title: "Store Health Looks Great",
      summary:
        `Your store scored ${score}/100 with no critical issues detected. Keep up the good work and maintain regular monitoring.`,
      priority: "low",
      actionItems: [
        "Continue regular scanning to catch regressions early.",
        "Consider upgrading your plan for AI-powered insights.",
        "Set up weekly digest emails for ongoing awareness.",
      ],
      estimatedImpact: "Ongoing monitoring prevents regression and maintains customer trust.",
      references: [],
    });
  }

  return feedback;
}

// ============================================================================
// AI Analysis Service
// ============================================================================

class AIAnalysisServiceImpl implements IAIAnalysisService {
  private readonly apiKey: string | undefined;
  private readonly apiUrl: string;

  constructor() {
    // Server-side only: AI_API_KEY and AI_API_URL env vars
    this.apiKey = (import.meta.env as Record<string, string | undefined>).VITE_AI_API_KEY;
    this.apiUrl =
      (import.meta.env as Record<string, string | undefined>).VITE_AI_API_URL ?? "https://api.openai.com/v1/chat/completions";
  }

  async createAIAnalysis(scanResult: ScanResult): Promise<AIFeedback[]> {
    // If no API key, use deterministic fallback
    if (!this.apiKey) {
      return generateFallbackAnalysis(scanResult);
    }

    try {
      return await this.callAI(scanResult);
    } catch (err) {
      // Gracefully fall back on any AI API error
      console.error("[AIAnalysisService] API call failed, using fallback:", err);
      return generateFallbackAnalysis(scanResult);
    }
  }

  /**
   * Call the AI API with the scan data.
   * Structured to be provider-agnostic — only the URL/headers differ.
   */
  private async callAI(scanResult: ScanResult): Promise<AIFeedback[]> {
    const failedChecks = scanResult.checks.filter(
      (c) => c.status !== "passed",
    );

    const prompt = this.buildPrompt(scanResult.storeUrl, failedChecks, scanResult.healthScore);

    const response = await fetch(this.apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        // Server-side only: AI_MODEL env var
        model: (import.meta.env as Record<string, string | undefined>).VITE_AI_MODEL ?? "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "You are an e-commerce health analyst. Provide actionable, specific feedback. Respond in JSON.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.3,
        response_format: { type: "json_object" },
      }),
      signal: AbortSignal.timeout(30_000),
    });

    if (!response.ok) {
      throw new AIAnalysisError(
        `AI API returned ${response.status}`,
        "API_ERROR",
      );
    }

    const data = (await response.json()) as {
      choices: Array<{ message: { content: string } }>;
    };

    const content = data.choices[0]?.message?.content;
    if (!content) {
      throw new AIAnalysisError("Empty response from AI API", "PARSE_ERROR");
    }

    return this.parseAIResponse(content);
  }

  private buildPrompt(
    storeUrl: string,
    failedChecks: ScanCheckItem[],
    healthScore: number,
  ): string {
    const checksList = failedChecks
      .map(
        (c) =>
          `- [${c.severity.toUpperCase()}] ${c.category}: ${c.name} — ${c.description}`,
      )
      .join("\n");

    return `
Analyze the following e-commerce store scan results for "${storeUrl}".
Overall health score: ${healthScore}/100

Failed/warning checks:
${checksList}

Respond with a JSON object containing a "feedback" array. Each item must have:
- "category": one of ${JSON.stringify([
      "security",
      "performance",
      "seo",
      "accessibility",
      "mobile",
      "content",
      "analytics",
      "ssl",
    ])}
- "title": short actionable title
- "summary": 1-2 sentence explanation
- "priority": "high", "medium", or "low"
- "actionItems": array of 3-5 specific action items
- "estimatedImpact": 1 sentence on expected improvement
- "references": array of 1-2 reference URLs
`.trim();
  }

  private parseAIResponse(content: string): AIFeedback[] {
    try {
      const parsed = JSON.parse(content) as {
        feedback: Array<{
          category: ScanCheckCategory;
          title: string;
          summary: string;
          priority: "high" | "medium" | "low";
          actionItems: string[];
          estimatedImpact: string;
          references: string[];
        }>;
      };

      if (!Array.isArray(parsed.feedback)) {
        throw new Error("Expected feedback array");
      }

      return parsed.feedback.map((item) => ({
        id: crypto.randomUUID(),
        category: item.category,
        title: item.title,
        summary: item.summary,
        priority: item.priority,
        actionItems: Array.isArray(item.actionItems) ? item.actionItems : [],
        estimatedImpact: item.estimatedImpact ?? "",
        references: Array.isArray(item.references) ? item.references : [],
      }));
    } catch {
      throw new AIAnalysisError(
        "Failed to parse AI response as JSON",
        "PARSE_ERROR",
      );
    }
  }
}

// ============================================================================
// Type needed internally
// ============================================================================

interface ScanCheckItem {
  category: ScanCheckCategory;
  name: string;
  description: string;
  status: "passed" | "failed" | "warning";
  severity: "critical" | "warning" | "minor";
  details: Record<string, unknown>;
  recommendation: string;
}

// ============================================================================
// Singleton Export
// ============================================================================

/**
 * AI Analysis Service singleton.
 *
 * ⚠️  SERVER-SIDE ONLY — contains API key logic.
 * Do not import or use this in client components.
 */
export const aiAnalysisService: IAIAnalysisService =
  new AIAnalysisServiceImpl();
