import type {
  ScanCheckItem,
  ScanCheckCategory,
  HealthScoreResult,
  HealthScoreBreakdown,
  HealthScoreDeduction,
} from "@/types";
import { clamp } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Starting score before any deductions. */
const BASE_SCORE = 100;

/** Deduction ranges by severity (minimum, maximum points). */
const SEVERITY_DEDUCTIONS: Record<
  string,
  { min: number; max: number }
> = {
  critical: { min: 10, max: 20 },
  warning: { min: 3, max: 8 },
  minor: { min: 1, max: 3 },
};

/** Default weight for each category when calculating per-category scores. */
const CATEGORY_WEIGHTS: Record<ScanCheckCategory, number> = {
  security: 1.5,
  performance: 1.2,
  seo: 1.0,
  accessibility: 0.8,
  mobile: 1.0,
  content: 0.7,
  analytics: 0.5,
  ssl: 1.3,
};

// ---------------------------------------------------------------------------
// Deduction Calculation
// ---------------------------------------------------------------------------

/**
 * Calculate the point deduction for a single failed check.
 *
 * Uses a deterministic hash of the check name + category to pick a value
 * within the severity range so results are reproducible for the same input.
 */
function calculateDeduction(check: ScanCheckItem): number {
  const range = SEVERITY_DEDUCTIONS[check.severity];
  if (!range) return 0;

  // Deterministic pseudo-random pick within [min, max]
  const hash = simpleDjb2Hash(`${check.category}:${check.name}`);
  const normalized = (hash % 1000) / 1000; // 0.000 – 0.999
  const deduction = range.min + normalized * (range.max - range.min);

  return Math.round(deduction * 10) / 10;
}

/** DJB2 hash — fast, deterministic, non-cryptographic. */
function simpleDjb2Hash(str: string): number {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) + hash + str.charCodeAt(i);
    hash = hash & hash; // Convert to 32-bit int
  }
  return Math.abs(hash);
}

// ---------------------------------------------------------------------------
// Grade & Label
// ---------------------------------------------------------------------------

function getGrade(score: number): "A" | "B" | "C" | "D" | "F" {
  if (score >= 90) return "A";
  if (score >= 75) return "B";
  if (score >= 60) return "C";
  if (score >= 40) return "D";
  return "F";
}

function getLabel(score: number): string {
  if (score >= 90) return "Excellent";
  if (score >= 75) return "Good";
  if (score >= 60) return "Fair";
  if (score >= 40) return "Poor";
  return "Critical";
}

// ---------------------------------------------------------------------------
// Per-Category Score
// ---------------------------------------------------------------------------

/**
 * Calculate a per-category sub-score (0-100) based on that category's
 * failed/warning checks only.
 */
function calculateCategoryScore(
  category: ScanCheckCategory,
  checks: ScanCheckItem[],
): number {
  const categoryChecks = checks.filter((c) => c.category === category);
  if (categoryChecks.length === 0) return 100;

  const failedChecks = categoryChecks.filter(
    (c) => c.status === "failed" || c.status === "warning",
  );

  if (failedChecks.length === 0) return 100;

  let categoryDeductions = 0;
  for (const check of failedChecks) {
    categoryDeductions += calculateDeduction(check);
  }

  return clamp(Math.round(100 - categoryDeductions), 0, 100);
}

// ---------------------------------------------------------------------------
// Main Export
// ---------------------------------------------------------------------------

/**
 * Calculate an overall health score (0–100) from an array of scan checks.
 *
 * Algorithm:
 * 1. Start at 100.
 * 2. For every failed or warning check, deduct points based on severity:
 *    - Critical: -10 to -20
 *    - Warning:  -3  to -8
 *    - Minor:    -1  to -3
 * 3. Clamp the final score between 0 and 100.
 * 4. Compute per-category breakdown scores.
 *
 * Returns a full `HealthScoreResult` with score, grade, label, breakdown,
 * and individual deduction details.
 */
export function calculateHealthScore(
  checks: ScanCheckItem[],
): HealthScoreResult {
  const deductions: HealthScoreDeduction[] = [];
  let totalDeductions = 0;

  for (const check of checks) {
    if (check.status === "passed") continue;

    const points = calculateDeduction(check);
    totalDeductions += points;

    deductions.push({
      category: check.category,
      checkName: check.name,
      severity: check.severity,
      points,
    });
  }

  const rawScore = BASE_SCORE - totalDeductions;
  const score = clamp(Math.round(rawScore), 0, 100);

  // Per-category breakdown
  const allCategories: ScanCheckCategory[] = [
    "security",
    "performance",
    "seo",
    "accessibility",
    "mobile",
    "content",
    "analytics",
    "ssl",
  ];

  const breakdown: HealthScoreBreakdown = {} as HealthScoreBreakdown;
  for (const category of allCategories) {
    breakdown[category] = calculateCategoryScore(category, checks);
  }

  return {
    score,
    grade: getGrade(score),
    label: getLabel(score),
    breakdown,
    deductions,
  };
}

// ---------------------------------------------------------------------------
// Convenience Exports (for use in UI or other modules)
// ---------------------------------------------------------------------------

export { getGrade, getLabel, SEVERITY_DEDUCTIONS, CATEGORY_WEIGHTS };
