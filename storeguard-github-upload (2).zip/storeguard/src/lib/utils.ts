import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import type { IssueSeverity } from "@/types";

// ---------------------------------------------------------------------------
// Tailwind Class Merging
// ---------------------------------------------------------------------------

/** Merge Tailwind CSS classes with clsx and tailwind-merge. */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

// ---------------------------------------------------------------------------
// Date Formatting
// ---------------------------------------------------------------------------

/** Format a date string or Date object into a human-readable string. */
export function formatDate(
  value: string | Date,
  options: Intl.DateTimeFormatOptions = {
    year: "numeric",
    month: "short",
    day: "numeric",
  },
  locale = "en-US",
): string {
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat(locale, options).format(date);
}

/** Format a date as a relative time string (e.g., "2 hours ago"). */
export function formatRelativeTime(value: string | Date): string {
  const date = typeof value === "string" ? new Date(value) : value;
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSeconds < 60) return "just now";
  if (diffMinutes < 60) return `${diffMinutes} minute${diffMinutes !== 1 ? "s" : ""} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`;

  return formatDate(date);
}

// ---------------------------------------------------------------------------
// Number Formatting
// ---------------------------------------------------------------------------

/** Format a number with locale-aware grouping and decimal places. */
export function formatNumber(
  value: number,
  options: Intl.NumberFormatOptions = {
    maximumFractionDigits: 1,
  },
  locale = "en-US",
): string {
  return new Intl.NumberFormat(locale, options).format(value);
}

/** Format a number as a percentage string. */
export function formatPercent(value: number, decimals = 1): string {
  return `${formatNumber(value, { maximumFractionDigits: decimals })}%`;
}

/** Format a number as currency. */
export function formatCurrency(
  amount: number,
  currency = "USD",
  locale = "en-US",
): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

// ---------------------------------------------------------------------------
// String Utilities
// ---------------------------------------------------------------------------

/** Truncate a string to a maximum length, appending an ellipsis. */
export function truncate(str: string, maxLength: number): string {
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength - 1).trimEnd() + "\u2026";
}

/** Generate initials from a name (e.g., "John Doe" -> "JD"). */
export function getInitials(name: string): string {
  const parts = name
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.charAt(0).toUpperCase();

  return (parts[0]!.charAt(0) + parts[parts.length - 1]!.charAt(0)).toUpperCase();
}

/** Capitalize the first letter of a string. */
export function capitalize(str: string): string {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/** Convert a snake_case or kebab-case string to Title Case. */
export function toTitleCase(str: string): string {
  return str
    .replace(/[-_]/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

// ---------------------------------------------------------------------------
// Score & Severity Visual Helpers
// ---------------------------------------------------------------------------

/** Get a Tailwind text-color class based on a health score (0-100). */
export function getScoreColor(score: number): string {
  if (score >= 90) return "text-emerald-600";
  if (score >= 75) return "text-green-600";
  if (score >= 60) return "text-yellow-600";
  if (score >= 40) return "text-orange-600";
  return "text-red-600";
}

/** Get a Tailwind background-color class based on a health score (0-100). */
export function getScoreBgColor(score: number): string {
  if (score >= 90) return "bg-emerald-500";
  if (score >= 75) return "bg-green-500";
  if (score >= 60) return "bg-yellow-500";
  if (score >= 40) return "bg-orange-500";
  return "bg-red-500";
}

/** Get a human-readable label for a health score range. */
export function getScoreLabel(score: number): string {
  if (score >= 90) return "Excellent";
  if (score >= 75) return "Good";
  if (score >= 60) return "Fair";
  if (score >= 40) return "Poor";
  return "Critical";
}

/** Get a letter grade for a health score. */
export function getScoreGrade(score: number): "A" | "B" | "C" | "D" | "F" {
  if (score >= 90) return "A";
  if (score >= 75) return "B";
  if (score >= 60) return "C";
  if (score >= 40) return "D";
  return "F";
}

/** Get a Tailwind color class for an issue severity level. */
export function getSeverityColor(severity: IssueSeverity): string {
  switch (severity) {
    case "critical":
      return "text-red-600 bg-red-50 border-red-200";
    case "warning":
      return "text-amber-600 bg-amber-50 border-amber-200";
    case "minor":
      return "text-blue-600 bg-blue-50 border-blue-200";
  }
}

/** Get a dot/badge color class for an issue severity level. */
export function getSeverityDotColor(severity: IssueSeverity): string {
  switch (severity) {
    case "critical":
      return "bg-red-500";
    case "warning":
      return "bg-amber-500";
    case "minor":
      return "bg-blue-500";
  }
}

/** Get a human-readable label for an issue severity level. */
export function getSeverityLabel(severity: IssueSeverity): string {
  switch (severity) {
    case "critical":
      return "Critical";
    case "warning":
      return "Warning";
    case "minor":
      return "Minor";
  }
}
// ---------------------------------------------------------------------------
// URL Utilities
// ---------------------------------------------------------------------------

/** Validate that a URL is a proper HTTPS URL. */
export function isValidHttpsUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:";
  } catch {
    return false;
  }
}

/** Extract the domain name from a URL. */
export function extractDomain(url: string): string {
  try {
    const parsed = new URL(url);
    return parsed.hostname;
  } catch {
    return url;
  }
}

// ---------------------------------------------------------------------------
// Misc Utilities
// ---------------------------------------------------------------------------

/** Generate a simple hash string from input (for non-crypto uses). */
export function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(36);
}

/** Sleep for a given number of milliseconds. */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Clamp a number between a minimum and maximum value. */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

/** Create a debounced version of a function. */
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number,
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}
