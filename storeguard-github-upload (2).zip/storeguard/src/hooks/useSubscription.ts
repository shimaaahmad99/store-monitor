import { useState, useEffect, useCallback } from "react";
import { supabase, isSupabaseConfigured } from "@/services/supabase";
import { useAuth } from "@/context/AuthContext";
import { demoSubscription, demoPayments } from "@/data/demo";
import { rowToSubscription, rowToPayment } from "@/types";
import { getPlanById } from "@/config/pricing";
import type {
  Subscription,
  Payment,
  SubscriptionRow,
  PaymentRow,
  SubscriptionPlan,
} from "@/types";

// ============================================================================
// Hook
// ============================================================================

export function useSubscription() {
  const { user, isDemoMode } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // -----------------------------------------------------------------------
  // Fetch subscription
  // -----------------------------------------------------------------------
  const fetchSubscription = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      if (isDemoMode || !isSupabaseConfigured() || !user) {
        setSubscription(demoSubscription);
        setLoading(false);
        return;
      }

      const { data, error: supabaseError } = await supabase
        .from("subscriptions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .single();

      if (supabaseError) {
        // No subscription found is not an error — it just means free tier
        if (supabaseError.code === "PGRST116") {
          setSubscription(null);
          setLoading(false);
          return;
        }
        throw new Error(supabaseError.message);
      }

      setSubscription(rowToSubscription(data as SubscriptionRow));
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : "Failed to fetch subscription.";
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [user, isDemoMode]);

  // -----------------------------------------------------------------------
  // Fetch payments
  // -----------------------------------------------------------------------
  const fetchPayments = useCallback(async () => {
    setError(null);

    try {
      if (isDemoMode || !isSupabaseConfigured() || !user) {
        setPayments(demoPayments);
        return;
      }

      const { data, error: supabaseError } = await supabase
        .from("payments")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (supabaseError) {
        throw new Error(supabaseError.message);
      }

      setPayments((data as PaymentRow[]).map(rowToPayment));
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to fetch payments.";
      setError(message);
    }
  }, [user, isDemoMode]);

  // -----------------------------------------------------------------------
  // Get current plan details
  // -----------------------------------------------------------------------
  const getCurrentPlan = useCallback((): SubscriptionPlan => {
    if (subscription && subscription.status === "active") {
      return subscription.plan;
    }
    // Default to monthly plan in demo mode
    if (isDemoMode) {
      return "monthly";
    }
    // Free tier has no plan — treat as daily
    return "daily";
  }, [subscription, isDemoMode]);

  // -----------------------------------------------------------------------
  // Get plan pricing details
  // -----------------------------------------------------------------------
  const getPricingPlan = useCallback(() => {
    const planId = getCurrentPlan();
    return getPlanById(planId);
  }, [getCurrentPlan]);

  // -----------------------------------------------------------------------
  // Check if subscription is active
  // -----------------------------------------------------------------------
  const isActive =
    subscription?.status === "active" &&
    !subscription.cancelAtPeriodEnd &&
    new Date(subscription.currentPeriodEnd) > new Date();

  // -----------------------------------------------------------------------
  // Days remaining in current period
  // -----------------------------------------------------------------------
  const daysRemaining = subscription
    ? Math.max(
        0,
        Math.ceil(
          (new Date(subscription.currentPeriodEnd).getTime() -
            Date.now()) /
            (1000 * 60 * 60 * 24),
        ),
      )
    : 0;

  // -----------------------------------------------------------------------
  // Initial fetch
  // -----------------------------------------------------------------------
  useEffect(() => {
    fetchSubscription();
    fetchPayments();
  }, [fetchSubscription, fetchPayments]);

  return {
    subscription,
    payments,
    loading,
    error,
    isActive,
    daysRemaining,
    currentPlan: getCurrentPlan(),
    pricingPlan: getPricingPlan(),
    fetchSubscription,
    fetchPayments,
    getCurrentPlan,
  };
}
