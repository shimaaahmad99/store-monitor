import { useState, useEffect, useCallback } from "react";
import { supabase, isSupabaseConfigured } from "@/services/supabase";
import { useAuth } from "@/context/AuthContext";
import { demoScans, demoChecks } from "@/data/demo";
import { scannerService } from "@/services/scanner";
import { rowToScan, rowToScanCheck } from "@/types";
import type { Scan, ScanCheck, ScanResult, ScanRow, ScanCheckRow } from "@/types";

// ============================================================================
// Hook
// ============================================================================

export function useScans(storeId?: string) {
  const { user, isDemoMode } = useAuth();
  const [scans, setScans] = useState<Scan[]>([]);
  const [currentScan, setCurrentScan] = useState<ScanCheck[]>([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // -----------------------------------------------------------------------
  // Fetch scans
  // -----------------------------------------------------------------------
  const fetchScans = useCallback(
    async (targetStoreId?: string) => {
      setLoading(true);
      setError(null);

      const sid = targetStoreId ?? storeId;

      try {
        if (isDemoMode || !isSupabaseConfigured() || !user) {
          const filtered = sid
            ? demoScans.filter((s) => s.storeId === sid)
            : demoScans;
          setScans(filtered);
          setLoading(false);
          return;
        }

        let query = supabase
          .from("scans")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });

        if (sid) {
          query = query.eq("store_id", sid);
        }

        const { data, error: supabaseError } = await query;

        if (supabaseError) {
          throw new Error(supabaseError.message);
        }

        setScans((data as ScanRow[]).map(rowToScan));
      } catch (err) {
        const message = err instanceof Error ? err.message : "Failed to fetch scans.";
        setError(message);
      } finally {
        setLoading(false);
      }
    },
    [user, isDemoMode, storeId],
  );

  // -----------------------------------------------------------------------
  // Fetch a single scan with its checks
  // -----------------------------------------------------------------------
  const fetchScanById = useCallback(
    async (scanId: string): Promise<ScanCheck[]> => {
      setError(null);

      try {
        if (isDemoMode || !isSupabaseConfigured() || !user) {
          const checks = demoChecks.filter((c) => c.scanId === scanId);
          setCurrentScan(checks);
          return checks;
        }

        const { data, error: supabaseError } = await supabase
          .from("scan_checks")
          .select("*")
          .eq("scan_id", scanId)
          .order("created_at", { ascending: true });

        if (supabaseError) {
          throw new Error(supabaseError.message);
        }

        const checks = (data as ScanCheckRow[]).map(rowToScanCheck);
        setCurrentScan(checks);
        return checks;
      } catch (err) {
        const message = err instanceof Error ? err.message : "Failed to fetch scan checks.";
        setError(message);
        return [];
      }
    },
    [user, isDemoMode],
  );

  // -----------------------------------------------------------------------
  // Trigger a new scan
  // -----------------------------------------------------------------------
  const triggerScan = useCallback(
    async (storeUrl: string): Promise<{
      result?: ScanResult;
      error: string | null;
    }> => {
      setScanning(true);
      setError(null);

      try {
        // Always use the scannerService (it handles demo data internally)
        const result = await scannerService.scanWebsite(storeUrl);

        if (isDemoMode || !isSupabaseConfigured() || !user) {
          // Create a local Scan record for demo mode
          const newScan: Scan = {
            id: result.id,
            storeId: storeId ?? "demo",
            userId: "demo",
            status: "completed",
            startedAt: new Date(result.scannedAt.getTime() - result.durationMs),
            completedAt: result.scannedAt,
            healthScore: result.healthScore,
            totalChecks: result.summary.totalChecks,
            passedChecks: result.summary.passed,
            failedChecks: result.summary.failed,
            warningChecks: result.summary.warnings,
            errorMessage: null,
            createdAt: new Date(result.scannedAt.getTime() - result.durationMs),
          };

          setScans((prev) => [newScan, ...prev]);

          // Also create local ScanCheck records
          const newChecks: ScanCheck[] = result.checks.map((check, idx) => ({
            id: `check-${result.id}-${idx}`,
            scanId: result.id,
            category: check.category,
            name: check.name,
            description: check.description,
            status: check.status,
            severity: check.severity,
            details: check.details,
            createdAt: result.scannedAt,
          }));
          setCurrentScan(newChecks);

          setScanning(false);
          return { result, error: null };
        }

        // Real Supabase path: save scan and checks to DB
        const now = new Date().toISOString();
        const scanRow = {
          store_id: storeId,
          user_id: user.id,
          status: "completed" as const,
          started_at: new Date(result.scannedAt.getTime() - result.durationMs).toISOString(),
          completed_at: result.scannedAt.toISOString(),
          health_score: result.healthScore,
          total_checks: result.summary.totalChecks,
          passed_checks: result.summary.passed,
          failed_checks: result.summary.failed,
          warning_checks: result.summary.warnings,
          error_message: null,
          created_at: now,
        };

        const { data: savedScan, error: scanError } = await supabase
          .from("scans")
          .insert(scanRow)
          .select()
          .single();

        if (scanError) {
          throw new Error(scanError.message);
        }

        // Save checks
        const checkRows = result.checks.map((check, _idx) => ({
          scan_id: savedScan.id,
          category: check.category,
          name: check.name,
          description: check.description,
          status: check.status,
          severity: check.severity,
          details: check.details,
          created_at: now,
        }));

        if (checkRows.length > 0) {
          const { error: checksError } = await supabase
            .from("scan_checks")
            .insert(checkRows);

          if (checksError) {
            console.error("Failed to save scan checks:", checksError.message);
          }
        }

        const scan = rowToScan(savedScan as ScanRow);
        setScans((prev) => [scan, ...prev]);
        setScanning(false);
        return { result, error: null };
      } catch (err) {
        const message = err instanceof Error ? err.message : "Failed to run scan.";
        setError(message);
        setScanning(false);
        return { error: message };
      }
    },
    [user, isDemoMode, storeId],
  );

  // -----------------------------------------------------------------------
  // Get the latest scan for a store
  // -----------------------------------------------------------------------
  const getLatestScan = useCallback(
    (targetStoreId?: string): Scan | undefined => {
      const sid = targetStoreId ?? storeId;
      if (!sid) return undefined;
      return scans.find((s) => s.storeId === sid && s.status === "completed");
    },
    [scans, storeId],
  );

  // -----------------------------------------------------------------------
  // Initial fetch
  // -----------------------------------------------------------------------
  useEffect(() => {
    fetchScans();
  }, [fetchScans]);

  return {
    scans,
    currentScan,
    loading,
    scanning,
    error,
    fetchScans,
    fetchScanById,
    triggerScan,
    getLatestScan,
  };
}
