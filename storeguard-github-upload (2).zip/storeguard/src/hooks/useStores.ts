import { useState, useEffect, useCallback } from "react";
import { supabase, isSupabaseConfigured } from "@/services/supabase";
import { useAuth } from "@/context/AuthContext";
import { demoStores } from "@/data/demo";
import { rowToStore } from "@/types";
import type { Store, StoreRow, StorePlatform } from "@/types";

// ============================================================================
// Hook
// ============================================================================

export function useStores() {
  const { user, isDemoMode } = useAuth();
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // -----------------------------------------------------------------------
  // Fetch stores
  // -----------------------------------------------------------------------
  const fetchStores = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      if (isDemoMode || !isSupabaseConfigured() || !user) {
        // Return demo data in demo mode or when there's no user
        setStores(demoStores);
        setLoading(false);
        return;
      }

      const { data, error: supabaseError } = await supabase
        .from("stores")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (supabaseError) {
        throw new Error(supabaseError.message);
      }

      setStores((data as StoreRow[]).map(rowToStore));
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to fetch stores.";
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [user, isDemoMode]);

  // -----------------------------------------------------------------------
  // Create store
  // -----------------------------------------------------------------------
  const createStore = useCallback(
    async (input: {
      name: string;
      url: string;
      platform: StorePlatform;
    }): Promise<{ store?: Store; error: string | null }> => {
      setError(null);

      try {
        if (isDemoMode || !isSupabaseConfigured() || !user) {
          // In demo mode, simulate creating a store
          const newStore: Store = {
            id: `demo-store-${Date.now()}`,
            userId: "demo",
            name: input.name,
            url: input.url,
            platform: input.platform,
            isActive: true,
            lastScanAt: null,
            healthScore: null,
            metadata: null,
            createdAt: new Date(),
            updatedAt: new Date(),
          };
          setStores((prev) => [newStore, ...prev]);
          return { store: newStore, error: null };
        }

        const now = new Date().toISOString();
        const row = {
          user_id: user.id,
          name: input.name,
          url: input.url,
          platform: input.platform,
          is_active: true,
          last_scan_at: null,
          health_score: null,
          metadata: null,
          created_at: now,
          updated_at: now,
        };

        const { data, error: supabaseError } = await supabase
          .from("stores")
          .insert(row)
          .select()
          .single();

        if (supabaseError) {
          throw new Error(supabaseError.message);
        }

        const store = rowToStore(data as StoreRow);
        setStores((prev) => [store, ...prev]);
        return { store, error: null };
      } catch (err) {
        const message = err instanceof Error ? err.message : "Failed to create store.";
        setError(message);
        return { error: message };
      }
    },
    [user, isDemoMode],
  );

  // -----------------------------------------------------------------------
  // Delete store
  // -----------------------------------------------------------------------
  const deleteStore = useCallback(
    async (storeId: string): Promise<{ error: string | null }> => {
      setError(null);

      try {
        if (isDemoMode || !isSupabaseConfigured() || !user) {
          setStores((prev) => prev.filter((s) => s.id !== storeId));
          return { error: null };
        }

        const { error: supabaseError } = await supabase
          .from("stores")
          .delete()
          .eq("id", storeId)
          .eq("user_id", user.id);

        if (supabaseError) {
          throw new Error(supabaseError.message);
        }

        setStores((prev) => prev.filter((s) => s.id !== storeId));
        return { error: null };
      } catch (err) {
        const message = err instanceof Error ? err.message : "Failed to delete store.";
        setError(message);
        return { error: message };
      }
    },
    [user, isDemoMode],
  );

  // -----------------------------------------------------------------------
  // Update store
  // -----------------------------------------------------------------------
  const updateStore = useCallback(
    async (
      storeId: string,
      data: Partial<Pick<Store, "name" | "url" | "platform" | "isActive">>,
    ): Promise<{ store?: Store; error: string | null }> => {
      setError(null);

      try {
        if (isDemoMode || !isSupabaseConfigured() || !user) {
          setStores((prev) =>
            prev.map((s) =>
              s.id === storeId
                ? { ...s, ...data, updatedAt: new Date() }
                : s,
            ),
          );
          const updated = stores.find((s) => s.id === storeId);
          return { store: updated, error: null };
        }

        const row: Record<string, unknown> = { updated_at: new Date().toISOString() };
        if (data.name !== undefined) row.name = data.name;
        if (data.url !== undefined) row.url = data.url;
        if (data.platform !== undefined) row.platform = data.platform;
        if (data.isActive !== undefined) row.is_active = data.isActive;

        const { data: updatedRow, error: supabaseError } = await supabase
          .from("stores")
          .update(row)
          .eq("id", storeId)
          .eq("user_id", user.id)
          .select()
          .single();

        if (supabaseError) {
          throw new Error(supabaseError.message);
        }

        const store = rowToStore(updatedRow as StoreRow);
        setStores((prev) => prev.map((s) => (s.id === storeId ? store : s)));
        return { store, error: null };
      } catch (err) {
        const message = err instanceof Error ? err.message : "Failed to update store.";
        setError(message);
        return { error: message };
      }
    },
    [user, isDemoMode, stores],
  );

  // -----------------------------------------------------------------------
  // Initial fetch
  // -----------------------------------------------------------------------
  useEffect(() => {
    fetchStores();
  }, [fetchStores]);

  return {
    stores,
    loading,
    error,
    fetchStores,
    createStore,
    deleteStore,
    updateStore,
  };
}
