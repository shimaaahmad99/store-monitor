import { useState, useEffect, useCallback } from "react";
import { supabase, isSupabaseConfigured } from "@/services/supabase";
import { useAuth } from "@/context/AuthContext";
import { demoIssues } from "@/data/demo";
import { rowToIssue } from "@/types";
import type {
  Issue,
  IssueStatus,
  IssueSeverity,
  IssueRow,
  ScanCheckCategory,
} from "@/types";

// ---------------------------------------------------------------------------
// Filter options
// ---------------------------------------------------------------------------

export interface IssueFilters {
  storeId?: string;
  severity?: IssueSeverity | "all";
  status?: IssueStatus | "all";
  category?: ScanCheckCategory | "all";
  search?: string;
}

// ============================================================================
// Hook
// ============================================================================

export function useIssues(initialFilters?: IssueFilters) {
  const { user, isDemoMode } = useAuth();
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<IssueFilters>(initialFilters ?? {});

  // -----------------------------------------------------------------------
  // Apply filters to a list of issues
  // -----------------------------------------------------------------------
  const applyFilters = useCallback(
    (list: Issue[], f: IssueFilters): Issue[] => {
      let filtered = list;

      if (f.storeId) {
        filtered = filtered.filter((i) => i.storeId === f.storeId);
      }
      if (f.severity && f.severity !== "all") {
        filtered = filtered.filter((i) => i.severity === f.severity);
      }
      if (f.status && f.status !== "all") {
        filtered = filtered.filter((i) => i.status === f.status);
      }
      if (f.category && f.category !== "all") {
        filtered = filtered.filter((i) => i.category === f.category);
      }
      if (f.search) {
        const q = f.search.toLowerCase();
        filtered = filtered.filter(
          (i) =>
            i.title.toLowerCase().includes(q) ||
            i.description.toLowerCase().includes(q),
        );
      }

      return filtered;
    },
    [],
  );

  // -----------------------------------------------------------------------
  // Fetch issues
  // -----------------------------------------------------------------------
  const fetchIssues = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      if (isDemoMode || !isSupabaseConfigured() || !user) {
        setIssues(demoIssues);
        setLoading(false);
        return;
      }

      let query = supabase
        .from("issues")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (filters.storeId) {
        query = query.eq("store_id", filters.storeId);
      }
      if (filters.severity && filters.severity !== "all") {
        query = query.eq("severity", filters.severity);
      }
      if (filters.status && filters.status !== "all") {
        query = query.eq("status", filters.status);
      }
      if (filters.category && filters.category !== "all") {
        query = query.eq("category", filters.category);
      }

      const { data, error: supabaseError } = await query;

      if (supabaseError) {
        throw new Error(supabaseError.message);
      }

      setIssues((data as IssueRow[]).map(rowToIssue));
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to fetch issues.";
      setError(message);
    } finally {
      setLoading(false);
    }
  }, [user, isDemoMode, filters.storeId, filters.severity, filters.status, filters.category]);

  // -----------------------------------------------------------------------
  // Filter issues (client-side for demo, server query above for real)
  // -----------------------------------------------------------------------
  const filterIssues = useCallback(
    (newFilters: IssueFilters): Issue[] => {
      setFilters((prev) => ({ ...prev, ...newFilters }));

      if (isDemoMode || !isSupabaseConfigured() || !user) {
        return applyFilters(demoIssues, { ...filters, ...newFilters });
      }

      // For real Supabase, return filtered from current state (will refetch)
      return applyFilters(issues, { ...filters, ...newFilters });
    },
    [user, isDemoMode, filters, issues, applyFilters],
  );

  // -----------------------------------------------------------------------
  // Update issue status
  // -----------------------------------------------------------------------
  const updateIssueStatus = useCallback(
    async (
      issueId: string,
      newStatus: IssueStatus,
    ): Promise<{ error: string | null }> => {
      setError(null);

      try {
        if (isDemoMode || !isSupabaseConfigured() || !user) {
          const now = new Date();
          setIssues((prev) =>
            prev.map((issue) => {
              if (issue.id !== issueId) return issue;
              return {
                ...issue,
                status: newStatus,
                resolvedAt:
                  newStatus === "resolved" ? now : issue.resolvedAt,
                dismissedAt:
                  newStatus === "dismissed" ? now : issue.dismissedAt,
                updatedAt: now,
              };
            }),
          );
          return { error: null };
        }

        const updates: Record<string, unknown> = {
          status: newStatus,
          updated_at: new Date().toISOString(),
        };

        if (newStatus === "resolved") {
          updates.resolved_at = new Date().toISOString();
        }
        if (newStatus === "dismissed") {
          updates.dismissed_at = new Date().toISOString();
        }

        const { error: supabaseError } = await supabase
          .from("issues")
          .update(updates)
          .eq("id", issueId)
          .eq("user_id", user.id);

        if (supabaseError) {
          throw new Error(supabaseError.message);
        }

        // Update local state
        setIssues((prev) =>
          prev.map((issue) => {
            if (issue.id !== issueId) return issue;
            return {
              ...issue,
              status: newStatus,
              resolvedAt:
                newStatus === "resolved" ? new Date() : issue.resolvedAt,
              dismissedAt:
                newStatus === "dismissed" ? new Date() : issue.dismissedAt,
              updatedAt: new Date(),
            };
          }),
        );

        return { error: null };
      } catch (err) {
        const message =
          err instanceof Error ? err.message : "Failed to update issue status.";
        setError(message);
        return { error: message };
      }
    },
    [user, isDemoMode],
  );

  // -----------------------------------------------------------------------
  // Filtered issues (computed)
  // -----------------------------------------------------------------------
  const filteredIssues = applyFilters(issues, filters);

  // -----------------------------------------------------------------------
  // Initial fetch
  // -----------------------------------------------------------------------
  useEffect(() => {
    fetchIssues();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters.storeId]);

  return {
    issues: filteredIssues,
    allIssues: issues,
    loading,
    error,
    filters,
    setFilters,
    fetchIssues,
    filterIssues,
    updateIssueStatus,
  };
}
