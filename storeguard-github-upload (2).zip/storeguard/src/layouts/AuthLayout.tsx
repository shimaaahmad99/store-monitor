import React from "react";
import { Shield } from "lucide-react";
import { cn } from "@/lib/utils";

interface AuthLayoutProps {
  children: React.ReactNode;
}

export default function AuthLayout({ children }: AuthLayoutProps) {
  return (
    <div
      className={cn(
        "relative flex min-h-screen flex-col items-center justify-center",
        "bg-[#0a0a0f] px-4 py-8 sm:px-6",
      )}
    >
      {/* Subtle radial gradient background */}
      <div
        className={cn(
          "pointer-events-none absolute inset-0 overflow-hidden",
        )}
        aria-hidden="true"
      >
        <div className="absolute -top-1/2 left-1/2 h-full w-full -translate-x-1/2 rounded-full bg-[#6366f1]/[0.04] blur-[120px]" />
        <div className="absolute -bottom-1/4 right-0 h-2/3 w-2/3 rounded-full bg-[#06b6d4]/[0.03] blur-[100px]" />
      </div>

      {/* Dot pattern overlay */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.015]"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle, #f0f0f5 1px, transparent 1px)",
          backgroundSize: "24px 24px",
        }}
      />

      {/* Content container */}
      <div className="relative z-10 flex w-full max-w-md flex-col items-center gap-8">
        {/* Logo */}
        <div className="flex flex-col items-center gap-2">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#6366f1]/10">
              <Shield className="h-5 w-5 text-[#6366f1]" />
            </div>
            <span className="text-xl font-bold tracking-tight text-[#f0f0f5]">
              StoreGuard
            </span>
          </div>
          <p className="text-center text-sm text-[#8888a0]">
            Protect &amp; monitor your online store
          </p>
        </div>

        {/* Card wrapper for auth forms */}
        <div
          className={cn(
            "w-full rounded-2xl border border-[#1e1e2e] bg-[#111118] p-6 shadow-2xl",
            "sm:p-8",
          )}
        >
          {children}
        </div>

        {/* Bottom text */}
        <p className="text-center text-xs text-[#55556a]">
          &copy; {new Date().getFullYear()} StoreGuard. All rights reserved.
        </p>
      </div>
    </div>
  );
}
