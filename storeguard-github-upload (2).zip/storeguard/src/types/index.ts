// ============================================================================
// StoreGuard - Complete TypeScript Type Definitions
// ============================================================================

// ---------------------------------------------------------------------------
// Enums & Literal Unions
// ---------------------------------------------------------------------------

export type StorePlatform =
  | "shopify"
  | "woocommerce"
  | "magento"
  | "bigcommerce"
  | "squarespace"
  | "wix"
  | "custom";

export type ScanCheckCategory =
  | "security"
  | "performance"
  | "seo"
  | "accessibility"
  | "mobile"
  | "content"
  | "analytics"
  | "ssl";

export type IssueSeverity = "critical" | "warning" | "minor";

export type IssueStatus =
  | "open"
  | "in_progress"
  | "resolved"
  | "dismissed";

export type PaymentStatus =
  | "pending"
  | "processing"
  | "completed"
  | "failed"
  | "refunded"
  | "cancelled";

export type SubscriptionPlan = "daily" | "monthly" | "yearly";

export type NotificationChannel = "email" | "in_app" | "webhook";

// ---------------------------------------------------------------------------
// Database Row Types (Supabase table rows)
// ---------------------------------------------------------------------------

export interface ProfileRow {
  id: string;
  user_id: string;
  full_name: string | null;
  avatar_url: string | null;
  email: string;
  phone: string | null;
  company: string | null;
  role: "owner" | "admin" | "member";
  created_at: string;
  updated_at: string;
}

export interface StoreRow {
  id: string;
  user_id: string;
  name: string;
  url: string;
  platform: StorePlatform;
  is_active: boolean;
  last_scan_at: string | null;
  health_score: number | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}

export interface ScanRow {
  id: string;
  store_id: string;
  user_id: string;
  status: "queued" | "running" | "completed" | "failed";
  started_at: string | null;
  completed_at: string | null;
  health_score: number | null;
  total_checks: number;
  passed_checks: number;
  failed_checks: number;
  warning_checks: number;
  error_message: string | null;
  created_at: string;
}

export interface ScanCheckRow {
  id: string;
  scan_id: string;
  category: ScanCheckCategory;
  name: string;
  description: string;
  status: "passed" | "failed" | "warning" | "skipped";
  severity: IssueSeverity | null;
  details: Record<string, unknown> | null;
  created_at: string;
}

export interface IssueRow {
  id: string;
  store_id: string;
  scan_id: string;
  check_id: string | null;
  title: string;
  description: string;
  severity: IssueSeverity;
  status: IssueStatus;
  category: ScanCheckCategory;
  recommendation: string | null;
  resolved_at: string | null;
  dismissed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface NotificationRow {
  id: string;
  user_id: string;
  store_id: string | null;
  type: string;
  title: string;
  message: string;
  is_read: boolean;
  action_url: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export interface NotificationPreferenceRow {
  id: string;
  user_id: string;
  channel: NotificationChannel;
  event_type: string;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionRow {
  id: string;
  user_id: string;
  plan: SubscriptionPlan;
  status: "active" | "paused" | "cancelled" | "expired";
  current_period_start: string;
  current_period_end: string;
  cancel_at_period_end: boolean;
  stripe_subscription_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface PaymentRow {
  id: string;
  user_id: string;
  subscription_id: string | null;
  amount: number;
  currency: string;
  status: PaymentStatus;
  provider: "stripe" | "manual" | "other";
  provider_payment_id: string | null;
  description: string;
  metadata: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}

// ---------------------------------------------------------------------------
// Application Types
// ---------------------------------------------------------------------------

export interface Profile {
  id: string;
  userId: string;
  fullName: string | null;
  avatarUrl: string | null;
  email: string;
  phone: string | null;
  company: string | null;
  role: "owner" | "admin" | "member";
  createdAt: Date;
  updatedAt: Date;
}

export interface Store {
  id: string;
  userId: string;
  name: string;
  url: string;
  platform: StorePlatform;
  isActive: boolean;
  lastScanAt: Date | null;
  healthScore: number | null;
  metadata: Record<string, unknown> | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Scan {
  id: string;
  storeId: string;
  userId: string;
  status: "queued" | "running" | "completed" | "failed";
  startedAt: Date | null;
  completedAt: Date | null;
  healthScore: number | null;
  totalChecks: number;
  passedChecks: number;
  failedChecks: number;
  warningChecks: number;
  errorMessage: string | null;
  createdAt: Date;
}

export interface ScanCheck {
  id: string;
  scanId: string;
  category: ScanCheckCategory;
  name: string;
  description: string;
  status: "passed" | "failed" | "warning" | "skipped";
  severity: IssueSeverity | null;
  details: Record<string, unknown> | null;
  createdAt: Date;
}

export interface Issue {
  id: string;
  storeId: string;
  scanId: string;
  checkId: string | null;
  title: string;
  description: string;
  severity: IssueSeverity;
  status: IssueStatus;
  category: ScanCheckCategory;
  recommendation: string | null;
  resolvedAt: Date | null;
  dismissedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  storeId: string | null;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  actionUrl: string | null;
  metadata: Record<string, unknown> | null;
  createdAt: Date;
}

export interface NotificationPreference {
  id: string;
  userId: string;
  channel: NotificationChannel;
  eventType: string;
  enabled: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Subscription {
  id: string;
  userId: string;
  plan: SubscriptionPlan;
  status: "active" | "paused" | "cancelled" | "expired";
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  cancelAtPeriodEnd: boolean;
  stripeSubscriptionId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Payment {
  id: string;
  userId: string;
  subscriptionId: string | null;
  amount: number;
  currency: string;
  status: PaymentStatus;
  provider: "stripe" | "manual" | "other";
  providerPaymentId: string | null;
  description: string;
  metadata: Record<string, unknown> | null;
  createdAt: Date;
  updatedAt: Date;
}

// ---------------------------------------------------------------------------
// Non-DB / Service Types
// ---------------------------------------------------------------------------

export interface ScanResult {
  id: string;
  storeUrl: string;
  storeName: string;
  scannedAt: Date;
  durationMs: number;
  checks: ScanCheckItem[];
  healthScore: number;
  summary: ScanSummary;
}

export interface ScanCheckItem {
  category: ScanCheckCategory;
  name: string;
  description: string;
  status: "passed" | "failed" | "warning";
  severity: IssueSeverity;
  details: Record<string, unknown>;
  recommendation: string;
}

export interface ScanSummary {
  totalChecks: number;
  passed: number;
  warnings: number;
  failed: number;
  categories: Record<ScanCheckCategory, CategorySummary>;
}

export interface CategorySummary {
  total: number;
  passed: number;
  warnings: number;
  failed: number;
}

export interface HealthScoreResult {
  score: number;
  grade: "A" | "B" | "C" | "D" | "F";
  label: string;
  breakdown: HealthScoreBreakdown;
  deductions: HealthScoreDeduction[];
}

export interface HealthScoreBreakdown {
  security: number;
  performance: number;
  seo: number;
  accessibility: number;
  mobile: number;
  content: number;
  analytics: number;
  ssl: number;
}

export interface HealthScoreDeduction {
  category: ScanCheckCategory;
  checkName: string;
  severity: IssueSeverity;
  points: number;
}

export interface AIFeedback {
  id: string;
  category: ScanCheckCategory;
  title: string;
  summary: string;
  priority: "high" | "medium" | "low";
  actionItems: string[];
  estimatedImpact: string;
  references: string[];
}

// ---------------------------------------------------------------------------
// Feature Gate Types
// ---------------------------------------------------------------------------

export interface UserPlanFeatures {
  maxStores: number;
  maxScansPerDay: number;
  scanCategories: ScanCheckCategory[];
  aiAnalysisEnabled: boolean;
  notificationsEnabled: boolean;
  apiAccessEnabled: boolean;
  customBranding: boolean;
  teamMembers: number;
  dataRetentionDays: number;
  prioritySupport: boolean;
  webhooksEnabled: boolean;
  exportEnabled: boolean;
  historicalComparison: boolean;
}

// ---------------------------------------------------------------------------
// Discriminated Union Types
// ---------------------------------------------------------------------------

export type ScanStatusEvent =
  | { type: "queued"; scanId: string; queuedAt: Date }
  | { type: "started"; scanId: string; startedAt: Date }
  | { type: "progress"; scanId: string; progress: number; currentCheck: string }
  | { type: "completed"; scanId: string; result: ScanResult; completedAt: Date }
  | { type: "failed"; scanId: string; error: string; failedAt: Date };

export type PaymentEvent =
  | { type: "created"; paymentId: string; amount: number; currency: string }
  | { type: "succeeded"; paymentId: string; providerPaymentId: string }
  | { type: "failed"; paymentId: string; reason: string }
  | { type: "refunded"; paymentId: string; amount: number };

export type SubscriptionEvent =
  | { type: "activated"; subscriptionId: string; plan: SubscriptionPlan }
  | { type: "renewed"; subscriptionId: string; newPeriodEnd: Date }
  | { type: "cancelled"; subscriptionId: string; cancelAtPeriodEnd: boolean }
  | { type: "expired"; subscriptionId: string }
  | { type: "plan_changed"; subscriptionId: string; fromPlan: SubscriptionPlan; toPlan: SubscriptionPlan };

// ---------------------------------------------------------------------------
// API / Request-Response Types
// ---------------------------------------------------------------------------

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: { code: string; message: string; details?: unknown };
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface ScanRequest {
  storeUrl: string;
  categories?: ScanCheckCategory[];
}

export interface CreatePaymentRequest {
  plan: SubscriptionPlan;
  provider?: "stripe" | "manual";
}

export interface VerifyPaymentRequest {
  paymentId: string;
  providerVerificationCode?: string;
}

// ---------------------------------------------------------------------------
// Row-to-App Type Mappers
// ---------------------------------------------------------------------------

export function rowToProfile(row: ProfileRow): Profile {
  return {
    id: row.id,
    userId: row.user_id,
    fullName: row.full_name,
    avatarUrl: row.avatar_url,
    email: row.email,
    phone: row.phone,
    company: row.company,
    role: row.role,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  };
}

export function rowToStore(row: StoreRow): Store {
  return {
    id: row.id,
    userId: row.user_id,
    name: row.name,
    url: row.url,
    platform: row.platform,
    isActive: row.is_active,
    lastScanAt: row.last_scan_at ? new Date(row.last_scan_at) : null,
    healthScore: row.health_score,
    metadata: row.metadata,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  };
}

export function rowToScan(row: ScanRow): Scan {
  return {
    id: row.id,
    storeId: row.store_id,
    userId: row.user_id,
    status: row.status,
    startedAt: row.started_at ? new Date(row.started_at) : null,
    completedAt: row.completed_at ? new Date(row.completed_at) : null,
    healthScore: row.health_score,
    totalChecks: row.total_checks,
    passedChecks: row.passed_checks,
    failedChecks: row.failed_checks,
    warningChecks: row.warning_checks,
    errorMessage: row.error_message,
    createdAt: new Date(row.created_at),
  };
}

export function rowToScanCheck(row: ScanCheckRow): ScanCheck {
  return {
    id: row.id,
    scanId: row.scan_id,
    category: row.category,
    name: row.name,
    description: row.description,
    status: row.status,
    severity: row.severity,
    details: row.details,
    createdAt: new Date(row.created_at),
  };
}

export function rowToIssue(row: IssueRow): Issue {
  return {
    id: row.id,
    storeId: row.store_id,
    scanId: row.scan_id,
    checkId: row.check_id,
    title: row.title,
    description: row.description,
    severity: row.severity,
    status: row.status,
    category: row.category,
    recommendation: row.recommendation,
    resolvedAt: row.resolved_at ? new Date(row.resolved_at) : null,
    dismissedAt: row.dismissed_at ? new Date(row.dismissed_at) : null,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  };
}

export function rowToSubscription(row: SubscriptionRow): Subscription {
  return {
    id: row.id,
    userId: row.user_id,
    plan: row.plan,
    status: row.status,
    currentPeriodStart: new Date(row.current_period_start),
    currentPeriodEnd: new Date(row.current_period_end),
    cancelAtPeriodEnd: row.cancel_at_period_end,
    stripeSubscriptionId: row.stripe_subscription_id,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  };
}

export function rowToPayment(row: PaymentRow): Payment {
  return {
    id: row.id,
    userId: row.user_id,
    subscriptionId: row.subscription_id,
    amount: row.amount,
    currency: row.currency,
    status: row.status,
    provider: row.provider,
    providerPaymentId: row.provider_payment_id,
    description: row.description,
    metadata: row.metadata,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  };
}
